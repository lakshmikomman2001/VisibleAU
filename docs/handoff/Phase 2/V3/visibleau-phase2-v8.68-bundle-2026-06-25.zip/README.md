# VisibleAU — Phase 2 Bundle (v8.68 — latest canon)
Assembled 25 Jun 2026. Contains the latest Phase 2 design canon: the 7-layer LLD (v8.68), the Phase 2
prototype, all 9 sprint prompts, and the handoff/contents docs.

---

## ⚠️ NOTE ON CONTENTS
- **ChatGPT research is NOT included** — no such file was available this session (not in the v8.68
  delivery, not uploaded separately). See `05-research/README-research-not-included.md`. Add it there
  and re-zip if you have it.
- **The LLD here (`visibleau-7layer-lld.md`) is the 7-layer LLD shared across phases** — it IS the
  Phase 2 LLD at canonical version v8.68. (Phase 1 had no separate LLD; this same file serves both.)

---

## FOLDER MAP

### `01-lld/` — the canonical Phase 2 LLD
- `visibleau-7layer-lld.md` — **LLD v8.68** (the canonical Phase 2 low-level design, ~9,365 lines /
  650KB). This is THE source of truth for Phase 2; LLD wins over prototype on any conflict.

### `02-prototype/` — Phase 2 prototype
- `visibleau-prototype-phase2.jsx` — Phase 2 UI prototype (Figma-style, fully-specified styles —
  "FIX 16" canonical). Phase 2 prototypes are intentionally fully-styled so Claude Code doesn't miss
  styling (a Phase 1 lesson).

### `03-sprint-prompts/` — all 9 Phase 2 sprint prompts
- `visibleau-p2-sprint-1-prompt.md` … `visibleau-p2-sprint-9-prompt.md`
- All 9 authored and **Gate-3 cross-audited (PASS-WITH-FIXES, all fixes applied)**. Versions at last
  audit: S1 v1.5 · S2 v1.5 · S3 v1.5 · S4 v1.4 · S5 v1.5 · S6 v1.4 · S7 v1.3 · S8 v1.4 · S9 v1.3.

### `04-handoff-and-contents/` — orientation docs
- `visibleau-NEW-CHAT-HANDOFF-v8.68.md` — the original Phase 2 new-chat handoff.
- `VISIBLEAU-PHASE2-v8.68-CONTENTS.txt` — contents manifest of the v8.68 delivery.
- `visibleau-PHASE2-HANDOFF-v8_68.md` — standalone Phase 2 handoff (from uploads).

### `05-research/` — placeholder (research not included — see note above)

---

## PHASE 2 STATUS (as of 25 Jun 2026)
- **Design COMPLETE and Gate-3 audited.** Canonical version: **LLD v8.68 / prototype FIX 16.**
- All 9 sprint prompts complete + cross-audited, ready to build.
- **Phase 2 is build-pending** (Phase 1 Sprints 1–10 are built; Phase 1 Sprint 10 = Stripe billing was
  built & verified end-to-end on 25 Jun). Phase 2 build had not started as of this date.

## KEY v8.68 INVARIANTS / FIXES (carried in the LLD)
- 37 tables · 16 GAPs · serve()=25/25 · 'ATTRIBUTION CORRECTION' ×3.
- Platform-wide explainability contract `{ rationale, confidence_label, confidence_note, top_action }`
  (G3-01, fixed in S3+S5 prompts).
- `assertBrandAccess()` is the canonical brand-isolation gate (S8b-01); RBAC matrix has role-ceiling
  rows (S8b-02); audit_trail action enum additions (S8b-03).
- HealthCheck reconciled to 4 cross-layer dims (S9-02).
- Deliberate deferral: OQ-1 `local_seo_results` — NO DDL until a dedicated local-SEO pass; S6's
  `local_ai_trust_score` stays NULL by design (S6b-02).
- Forward build rules: RM-02 (aria-live) + responsive breakpoints.

## STACK (same as Phase 1, locked)
Next.js 15 App Router · Supabase/Postgres + RLS · Drizzle · Better Auth (Clerk retired — residual
"Clerk" strings are documented drift C-04) · Inngest · Vercel AI SDK (central model-selector) · Stripe ·
Resend · Sentry · PostHog. Tiers: Free/Starter/Growth/Agency/Agency Pro (AUD).

## CRITICAL LOCKED FACTS (apply to Phase 2 too)
- `audits.status` = `'complete'` (NO -d); `workflow_runs.status` = `'completed'`; webhook/analytics
  EVENT names use `*_completed` (correct). NEVER unify — a blind find-replace breaks Stripe + PostHog.
- PAGE routes `[brandId]`, API routes `[id]`. `regionEnum` lowercase country, default 'au'.
  `primaryRegions` text[] in `STATE:Suburb` format.
- runs-per-prompt env-configurable (`lib/llm/tier-engines.ts`); Free = 3 runs, paid = 5.
- Inngest local endpoint `/api/webhooks/inngest`; Stripe webhook `/api/webhooks/stripe`.
- Better Auth users must be created via the auth layer, not raw INSERT.

---
*For Phase 1 (built) see the separate `visibleau-phase1-complete-bundle-2026-06-25.zip`. For the overall
project handoff see `VisibleAU-HANDOFF.md`.*
