# VisibleAU — Phase 1 Complete Bundle (latest canon + all fix prompts)
Assembled 25 Jun 2026. This bundle gathers the latest Phase 1 design canon plus EVERY fix/validation
prompt produced across the build (original build, prior review session, and the 25 Jun session that
took Sprints 6–10 through validation + the Stripe billing build/test).

---

## ⚠️ TWO IMPORTANT CLARIFICATIONS (read first)

1. **There is NO Phase-1-specific LLD.** You asked for "latest LLD of Phase 1." The only LLD in the
   project is the **7-layer LLD** (`02-lld-7layer/visibleau-7layer-lld.md`), which is **shared with
   Phase 2** — it is not a separate Phase 1 document. Phase 1's actual foundational/design canon is in
   `01-foundational/`: the **PRD (v1.15)**, **Foundations (v1.12)**, and **Architecture (v1.6)**. Those
   three are the real Phase 1 "what/why/how" spec. The 7-layer LLD is included for completeness but is
   cross-phase.

2. **Fix prompts span THREE eras**, kept in separate folders so you know provenance:
   - `05-fixes-original/` — fixes from the original Phase 1 build.
   - `06-fixes-prior-session/` — fixes from the earlier review/validation session (agency surfaces,
     PDF builder, drift indicator, classification backfill, etc.).
   - `07-fixes-this-session/` — fixes/runbooks/investigations from the **25 Jun 2026** session
     (Sprints 6–10 validation finishing touches + the entire Stripe billing build & test).

---

## FOLDER MAP

### `01-foundational/` — Phase 1 design canon (the real spec)
- `visibleau-prd-v1.15.md` — Product Requirements (latest, v1.15)
- `visibleau-foundations-v1.12.md` — Foundations: schema, enums, conventions (latest, v1.12)
- `visibleau-architecture-overview-v1.6.md` — Architecture overview (latest, v1.6)
- `CLAUDE.md` — build conventions / stack notes

### `02-lld-7layer/` — the 7-layer LLD (SHARED with Phase 2, not Phase-1-only)
- `visibleau-7layer-lld.md`

### `03-prototype/` — Phase 1 prototype
- `visibleau-prototype.jsx` — the Phase 1 UI prototype (latest)

### `04-sprint-prompts/` — all 12 Phase 1 sprint prompts + index
- `sri-visibleau-sprint-1-prompt.md` … `sri-visibleau-sprint-12-prompt.md`
- `sri-visibleau-sprint-prompts-index.md` — the master index
- NOTE: Sprint 10 = Stripe billing + onboarding (validated & tested 25 Jun). Sprints 11–12 are
  build-pending (12 = launch/prod).
- NOTE: the Sprint 12 prompt has a known `'completed'`→`'complete'` audit-status fix to APPLY before
  building S12 — see `07-fixes-this-session/visibleau-sprint12-completed-status-fix.md`.

### `05-fixes-original/` — original-build fix prompts (14)
UI/data fixes from the initial Phase 1 build (action center, brand/brands pages, audit results,
breadcrumbs, vertical packs, zero-engines audit, run-audit UUID error, etc.).

### `06-fixes-prior-session/` — prior review-session fix prompts (21)
Agency surfaces (dashboard nav, workspace switcher, bulk CSV export, branding preview, notification
toggles), the multi-step PDF white-label builder fixes, Sprint 8 FM5 drift indicator, Smart Prompt
Pack classification backfill, local-SEO GMB card, html-lang/a11y checks, diagnostics.

### `07-fixes-this-session/` — 25 Jun 2026 session (31) — see sprint mapping below

---

## WHICH FIXES MAP TO WHICH SPRINT (your Sprints 6–10 request)

**Sprint 6/7 (Smart Prompt Pack, technical infra) — mostly in `06-fixes-prior-session/`:**
- `visibleau-classification-backfill.md` (Smart Prompt Pack classification — Inngest fn never triggered)
- `visibleau-ui-fix-audit-results-sprint6.md` (in `05-fixes-original/`)
- (Sprint 7 technical sub-pages were validated; no new fix files needed beyond prior session)

**Sprint 8 (UI: GMB card, FM5 drift) — `06-fixes-prior-session/`:**
- `visibleau-sprint8-FM5-drift-indicator-fix.md`
- `visibleau-local-seo-GMB-card-fix.md`

**Sprint 9 (agency surfaces) — `06-fixes-prior-session/`:**
- `visibleau-agency-surface-audit.md`, `visibleau-agency-gaps-root-cause.md`,
  `visibleau-agency-dashboard-cards-nav.md`, `visibleau-agency-dashboard-ambiguous-id-fix.md`,
  `visibleau-agency-dashboard-context.md`, `visibleau-GH2-workspace-switcher-nav.md`,
  `visibleau-workspace-switcher-404-fix.md`, `visibleau-bulk-csv-export-fix.md`,
  `visibleau-branding-preview-placeholder-fix.md`, `visibleau-notification-toggles-fix.md`,
  the PDF white-label builder set (`visibleau-pdf-*`).
- Scheduling (Manage Schedules) — THIS session: `07-fixes-this-session/visibleau-agency-manage-schedules-page.md`,
  `visibleau-per-brand-schedule-page-build.md`.

**Sprint 10 (Stripe billing + onboarding) — `07-fixes-this-session/` (the bulk of today):**
Wizard/onboarding UI:
- `visibleau-wizard-ui-fixes.md`, `visibleau-wizard-suburb-state-fix.md` (real data-integrity bug:
  suburbs hardcoded NSW: regardless of state — fixed + DB-verified), `visibleau-step-indicator-spacing.md`,
  `visibleau-confirm-screen-copy-derive.md`, `visibleau-confirm-copy-investigate-and-fix.md`.
Runs-per-prompt config:
- `visibleau-runs-per-prompt-investigation.md`, `visibleau-runs-per-prompt-config-fix.md`,
  `visibleau-tier-runs-free-3.md` (Free tier = 3 runs decision).
Stripe billing setup + test:
- `visibleau-stripe-config-investigation.md`, `visibleau-tier-prices-lookup.md`,
  `visibleau-stripe-env-keys-setup.md`, `visibleau-stripe-price-ids-env.md`,
  `visibleau-stripe-cli-install-windows.md`, `visibleau-stripe-create-prices.md`,
  `visibleau-sprint10-test-runbook.md`.
Stripe webhook BUGS found & fixed during end-to-end test (the high-value catches):
- `visibleau-stripe-webhook-400-fix.md` (STRIPE_WEBHOOK_SECRET was never set → every webhook 400'd)
- `visibleau-webhook-timeout-fix.md` (connection-pool DEADLOCK: max:1 + handlers using global db inside
  a tx → 30s hangs; tier never updated)
- `visibleau-webhook-transactional-hardening.md` (make handlers atomic + idempotent, deadlock-proof)
- `visibleau-verify-webhook-no-db-leak.md` (read-only verification — PASS)
- `visibleau-test-webhook-atomicity-rollback.md` + `visibleau-remove-atomicity-test-throw.md`
  (proved atomicity by fault injection, then removed the test throw)
Test-user seeding (per tier):
- `visibleau-seed-test-users-per-tier.md`, `visibleau-reseed-test-users-correct-tiers.md`
  (root cause: an unscoped UPDATE in an e2e script blasted all tiers to agency).
Data-integrity footgun fix (found via the above):
- `visibleau-fix-e2e-tier-footgun.md` (no-WHERE `UPDATE organizations SET tier='agency'` — fixed in
  e2e-real-audit-test.ts AND START-PROD.bat, a prod landmine; codebase scan found no siblings).

**Cross-cutting / launch-prep (not a single sprint):**
- `visibleau-cron-fires-schedule-runbook.md` (verify scheduling RUNTIME half — launch prep)
- `visibleau-inngest-batch-file.md` (local dev Inngest launcher; endpoint /api/webhooks/inngest)
- `visibleau-schedule-time-of-day-enhancement-RECONCILED.md` (+ earlier draft) — DEFERRED post-S12
- `visibleau-sprint12-completed-status-fix.md` — APPLY to the Sprint 12 prompt before building S12

---

## CANONICAL VERSIONS (Phase 1, as of 25 Jun 2026)
- PRD v1.15 · Foundations v1.12 · Architecture v1.6 · Prototype: visibleau-prototype.jsx
- Sprints 1–10 built & validated; 11–12 build-pending.
- Stack: Next.js 15 App Router, Supabase/Postgres + RLS, Drizzle, Better Auth (Clerk retired), Inngest,
  Vercel AI SDK, Stripe, Resend, Sentry, PostHog. Tiers: Free/Starter/Growth/Agency/Agency Pro (AUD).

## KEY LOCKED FACTS (carried in canon)
- `audits.status` = `'complete'` (NO -d). `workflow_runs.status`='completed'. Stripe/PostHog event names
  use `*_completed` (correct). Never unify these.
- Free tier = 3 runs/prompt (env TIER_RUNS_FREE=3); paid = 5. Set in .env.dev; PROD Vercel var still TODO.
- Stripe billing verified end-to-end 25 Jun (upgrade, cancel, portal, atomicity-on-failure proven).
