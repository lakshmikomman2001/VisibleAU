# VisibleAU — START HERE (Handoff to a new chat)

> **READ THIS WHOLE FILE FIRST, then read the canonical files in this bundle BEFORE doing
> anything** — no writing code, editing the LLD, touching a prototype, or designing sprint
> prompts until you've read the relevant files. Skipping the reads causes drift (wrong enums,
> wrong tiers, wrong routes, duplicated tables), which is exactly what this project spends most
> of its effort preventing.

---

## 0. IMPORTANT — how this bundle reached you, and where the files are

A previous chat created all of VisibleAU's documents in **its own** container at
`/mnt/user-data/outputs/`. **That filesystem does NOT carry over between chats** — each Claude
chat starts with a fresh, empty container. So a new chat cannot see files from a prior chat on
disk; they must be **uploaded**.

This bundle (`visibleau-canonical-bundle.zip`) is how the files travel between chats. If you are
reading this, Sri has uploaded the zip to you. The files will be at **`/mnt/user-data/uploads/`**
(possibly still zipped). To use them:

```bash
ls -la /mnt/user-data/uploads/
# If a zip is present, extract it into your working dir:
mkdir -p /tmp/visibleau && unzip -o /mnt/user-data/uploads/visibleau-canonical-bundle.zip -d /tmp/visibleau
find /tmp/visibleau -type f | sort
```

Then read the files from wherever they extracted (e.g. `/tmp/visibleau/visibleau-canonical-bundle/...`).
Do **not** assume `/mnt/user-data/outputs/` already contains them — verify on disk first
(the prior new chat correctly caught this; keep that habit).

**For ongoing multi-session work, the better home is a Claude Project:** put this bundle's files
into the Project's knowledge, and start every VisibleAU chat inside that project so the context
travels with you. For large files Claude must read with tools (the LLD is ~590 KB), uploading
the zip per chat is still the most reliable way to get them onto disk.

---

## 1. Who you're working with and how to respond

- **Sri** — Sydney-based solo full-stack developer (16+ yrs), full-time job in financial
  services, building VisibleAU as a side project at weekend pace (~8 hrs/week), with a
  full-time developer hired for the build.
- **Bilingual responses are mandatory.** Every response: **English first, then the same content
  in Telugu.** Code and technical terms stay in English even inside the Telugu portion.
- **Non-negotiable first-class concerns for ALL work:** Performance, Security, Scalability, UX
  Design — optimised DB queries, proper indexing, RLS, no N+1s, secure auth patterns, accessible
  + mobile-responsive UI, loading states, error boundaries, production-grade code. No corner-cutting.
- **Execution principle:** "do it first and get it right the first time." For Phase 2 sprint
  prompts/prototypes, execute completely and correctly on the first attempt — no pushback,
  stalling, or deferral.
- **Prototype fidelity:** Phase 2 prototypes must be fully Figma-style with completely specified
  UI styles (NexusBook approach) so Claude Code does not miss styling.

---

## 2. What VisibleAU is, and where the project stands

**VisibleAU** — an AI-search-visibility auditing SaaS for the Australian market: audits how
brands appear across AI engines (ChatGPT, Claude, Gemini, Perplexity), scores visibility, detects
hallucinations, tracks citations, and (Phase 2) adds a 7-layer intelligence platform.

**Architecture (locked):** Next.js 15+ App Router (server components for DB reads, client for
interactivity) · Supabase Postgres + RLS + Drizzle ORM · Better Auth (migrated from Clerk in
Phase 1) · Inngest for background jobs · Vercel AI SDK with a central model selector
(`lib/llm/model-selector.ts` — never hardcode model strings). Tiers: **Free / Starter / Growth /
Agency / Agency Pro** (pricing A$99 / A$299).

**Phase 1 (built product):** 12 sprints. Sprints 1–6 built with UI-fix passes applied. Sprints
7–12 not yet built (per-sprint UI-review cadence). The live app runs and is being debugged
screen-by-screen (Section 6).

**Phase 2 (designed, not built):** a 7-layer intelligence platform in the LLD, hardened through
36 conflict-audit passes, with a 14-screen prototype. Phase 2 build = 9 sprints, ~34 weeks at
weekend pace; Sprint 1 (Platform Foundation) is a hard prerequisite and cannot be reordered.

---

## 3. WHAT'S IN THIS BUNDLE (the canonical files — read these)

Folders inside `visibleau-canonical-bundle/`:

**`01-foundational/` — read first, in this order**
- `visibleau-prd-v1.15.md` — Product Requirements Document (what/why; tiers, features, pricing,
  scoring model). Large.
- `visibleau-foundations-v1.12.md` — canonical Foundations (schema conventions, shared types,
  auth/RLS patterns).
- `CLAUDE.md` — build design doc / engineering rules Claude Code follows.
- `visibleau-architecture-overview-v1.6.md` — architecture overview.

**`02-phase2-lld/` — the primary Phase 2 design artifact**
- `visibleau-7layer-lld.md` — **Phase 2 7-layer Low-Level Design, v8.55.** 37 `CREATE TABLE`s,
  16 GAPs, 25 Inngest functions; 36 conflict-audit passes. **Read the changelog block at the top
  first** — it records every fix and decision already made. Very large (~8,600 lines).

**`03-prototypes/`**
- `visibleau-prototype.jsx` — **Phase 1 prototype (canonical).** Phase 1 screen designs
  (includes the `AuditRunning` progress screen, audit results, brand detail, action center,
  billing, etc.).
- `visibleau-prototype-phase2.jsx` — **Phase 2 prototype, 14 screens.** Aligned to the LLD;
  header comment lists prototype FIX 1–4.

**`04-sprint-prompts/` — the 12 Phase 1 Claude Code sprint prompts (canonical)**
- `sri-visibleau-sprint-1-prompt.md` … `sri-visibleau-sprint-12-prompt.md`
- `sri-visibleau-sprint-prompts-index.md` — index/overview.

**`05-ui-fix-prompts/` — Phase 1 screen-by-screen UI corrections (Sprints 1–6)**
- brand-detail, audit-results-sprint6, brands-list, action-center, action-detail,
  vertical-packs, vertical-pack-detail, overview-minor, audit-detail-minor, audit-breadcrumb,
  billing-breadcrumb, brands-server-error.

**`06-bug-fix-prompts/` — most recent live-app fixes**
- `fix-run-audit-new-uuid-error.md` — Run audit → `audits.id = 'new'` UUID crash. **RESOLVED.**
- `fix-audit-zero-engines.md` — "0 engines / 0 LLM calls" tier→engine resolution. **OPEN — pending.**

**`07-supporting/` — read when relevant**
- `visibleau-local-stack-guide.md` + `…-conflict-audit.md` (PostgreSQL 18, no Docker)
- `visibleau-better-auth-setup.md` + `…-conflict-audit-v3.md` (Better Auth, replaced Clerk)
- `visibleau-external-services-guide.md`, `visibleau-citation-diagnosis-spec.md`,
  `visibleau-claude-code-reading-order.md`.

> Note: the prior chat's outputs folder also held hundreds of dated `-vN.NN` drafts. This bundle
> deliberately contains only the **canonical, current** files. If Sri uploads a folder of drafts
> instead, use only the unversioned canonical filenames listed above.

---

## 4. The conflict-audit methodology (the core ongoing activity)

Most sessions are **conflict-audit passes** on the Phase 2 LLD and prototype. Follow exactly:

1. Read the Phase 1 sprint prompts, CLAUDE.md, Foundations, the **current LLD**, and the **Phase 2
   prototype**.
2. Pick a **genuinely fresh angle** each pass (don't repeat a prior angle — the LLD changelog
   lists what's been checked).
3. Find conflicts. **For each, FIRST assess which document is authoritative** (LLD schema = canonical
   for data shapes/enums; prototype = canonical for UI/UX layout; Phase 1 sprint prompts = canonical
   for already-built behavior). **Then fix it in the correct document** — LLD or prototype.
4. **Version-bump the LLD** (e.g. v8.55 → v8.56) with a detailed changelog entry: the conflict, the
   authoritative-document assessment, the fix, and what was confirmed clean. Update the prototype's
   header fix-note when the prototype is edited.
5. **Verify before presenting:** 37 `CREATE TABLE`s, all 16 GAPs, `serve()` = 25/25 Inngest
   functions, no cron collisions, prototype braces/parens balance (global `{`==`}` and `(`==`)`;
   the naive scanner false-negatives on braces inside strings/JSX, so check edited regions too).
6. `present_files` the changed document(s). **Then Sri must download them and re-upload to the next
   chat** (or keep them in the Project) — outputs do not persist across chats (Section 0).

**Gotcha:** when a changelog/fix-note *describes* a corrupted string you just fixed, do NOT
reproduce the corrupted literal in the note — it re-introduces the string future greps look for.
Describe the change in prose.

---

## 5. Key locked facts (don't re-litigate settled decisions)

- 37 tables, 16 GAPs, 25 Inngest functions (serve() = 25/25) — invariants.
- **Tiers & gates:** Journeys = Agency+ (regated from Growth+ in v8.19). Competitors: Growth=1,
  Agency=3, Agency Pro=unlimited. Engines: Free = 2 (ChatGPT + Perplexity), all paid = 4
  (`TIER_ENGINES` in `lib/llm/tier-engines.ts` is the single source of truth — never hardcode 4).
- **agent_readiness_scores:** 5 dimensions (Technical Accessibility, Entity Clarity, Claim
  Verifiability, Category Authority, Task-Fit Signals) × /20 = /100; append-only. Distinct from
  Phase 1 `technical_audits` (8 sub-scores /18,/16…). Do not conflate.
- **Route params:** PAGE routes use `[brandId]`; API routes use `[id]` — separate route trees,
  must NOT be unified (RP-01).
- **Status enums:** `remediation_tasks.status` = open|in_progress|ready_for_review|complete|wont_fix
  (NOT 'done'). `workflow_runs.status` = scheduled|running|completed|failed ('-ed'). `audits.status`
  = 'complete'. TEXT enums have NO CHECK — validation is app-layer Zod; CHECK only for RLS.
- **Report status is UI-derived** (no column): `pdf_url` NULL → generating; set + `email_sent_at`
  NULL → ready; `email_sent_at` set → published.
- **Inngest events:** internal = slash (`audit/complete`); external webhooks = dots
  (`audit.completed`). Internal slash events must NOT appear in VALID_EVENTS.
- **Retention:** `audit-data-retention.ts` (Sunday cron) — audits (12mo) + `crawler_visit_logs`
  (90d) + `brand_web_mentions` (180d), the latter two added during Phase 2 Sprints 6/5.

---

## 6. Most recent activity (live Phase 1 app debugging)

The last turns moved from doc-auditing to **debugging the running app**. Two Run-audit bugs:

1. **`audits.id = 'new'` crash (RESOLVED).** Run audit hit the audit-detail page with
   `auditId = "new"`; Postgres rejected the non-UUID. Fix: `06-bug-fix-prompts/fix-run-audit-new-uuid-error.md`
   (create-then-redirect to the returned `auditId` + UUID guard → `notFound()`). Button now
   navigates correctly to the progress page.
2. **"0 engines / 0 LLM calls" (OPEN — pending application).** On an Agency-tier brand the
   progress page shows "Querying 0 engines × 10 prompts × 5 runs = 0 LLM calls" at 0%. Root cause:
   tier→engine resolution returns an **empty** list (not even Free's 2), so the job has nothing to
   iterate. The progress screen itself is correct per the Phase 1 prototype's `AuditRunning` — it's
   truthfully rendering a row created with 0 engines. Fix: `06-bug-fix-prompts/fix-audit-zero-engines.md`
   (investigate tier value vs `TIER_ENGINES` keys / org-join / empty default; fix at source; never
   let an empty engine list reach the row; also fixes a cosmetic "10prompts" missing-space). **Likely
   the next thing Sri picks up.**

For any new live-app bug: diagnose from the actual error text, cross-check the relevant sprint
prompt + prototype for intended behavior, decide built-code-bug vs spec-gap, and (when asked) write
a Claude Code fix prompt that tells Claude Code to **investigate the real files first** and verify
with typecheck + lint + the relevant test + the manual flow.

---

## 7. How to start your first response

1. Verify the bundle on disk (Section 0), extract it, and confirm which canonical files you've loaded.
2. Ask Sri what's next (continue Phase 2 LLD/prototype conflict audits? apply the open
   `fix-audit-zero-engines.md`? begin Phase 2 sprint-prompt design? fix another live screen?).
3. Respond English then Telugu; hold the Performance / Security / Scalability / UX non-negotiables.
