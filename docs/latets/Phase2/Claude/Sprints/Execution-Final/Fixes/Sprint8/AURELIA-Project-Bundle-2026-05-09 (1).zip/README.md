# AURELIA Project Bundle — May 2026

## How to use this bundle

If you are a new Claude session being onboarded onto this project: **read `AURELIA-Handoff-To-Next-Claude.docx` first.** It explains everything else.

If you are the operator (Sri) using this for a different Claude or different LLM:
1. Upload `AURELIA-Handoff-To-Next-Claude.docx` plus 4-6 other priority files from the handoff §8 list
2. Tell the new session: "Read the handoff document first, then ask me what to work on"
3. Do not upload all 27 files at once unless the new session asks — the handoff specifies which are priority

## What's in this bundle

27 files. All are current canonical AURELIA + KAIROS architecture documents as of 9 May 2026.

### Entry point (read first)
- `AURELIA-Handoff-To-Next-Claude.docx` — onboarding briefing for new Claude session

### Current PRD
- `AURELIA-PRD-v3-7.docx` — current Product Requirements Document (supersedes v1, v2, v3, v3.1-3.6)

### Audit reports (find the broken parts here)
- `AURELIA-PRD-v3-5-Clean-Audit.docx` — 14 conflicts including CRITICAL A10 cross-project memory; STILL UNRESOLVED as of bundle creation
- `AURELIA-PRD-v3-2-Gap-Verification.docx` — verified 4 claimed gaps; 2 were partial confabulations
- `AURELIA-PRD-v2-Clean-Audit.docx` — 15 conflicts in PRD v2; mostly applied to v3.5; P2 and P6 carryovers pending
- `AURELIA-Audit-Reconciliation-v6.docx` — 21 conflicts catalogued, 0 fixes applied (drainage sprint pending)

### Core canonical specs
- `AURELIA-Memory-Spec.docx` — two-tier memory; flagged STALE per audit (7-cat enum still active; cause_by_chain missing; project_id NOT NULL drives A10)
- `AURELIA-Production-Readiness.docx` — orchestrator behavior; flagged STALE (AgentOutputBase missing source_quality_score)
- `AURELIA-Differentiation-Strategy.docx` — 9 dimensions of differentiation vs MetaGPT/Khoj/CrewAI
- `AURELIA-Key-Features.docx` — feature priority breakdown
- `AURELIA-Market-Analysis-v2.docx` — Path A vs B economics with substrate ownership
- `AURELIA-Substrate-Features-Analysis-v2.docx` — primary-source GitHub verification of competitors

### Per-agent specs (read when relevant)
- `AURELIA-Researcher-Spec.docx`
- `AURELIA-Analyst-Spec.docx`
- `AURELIA-Architect-Spec.docx`
- `AURELIA-Planner-Spec.docx`
- `AURELIA-Design-Develop-Spec.docx`
- `AURELIA-Critic-Spec.docx`
- `AURELIA-Prototyper-Spec.docx`
- `AURELIA-Watcher-Spec.docx`
- `AURELIA-Task-Supervision-Spec.docx`
- `AURELIA-Interop-Spec.docx`

### Build pipeline and integration specs
- `AURELIA-Build-Pipeline-Closure-Spec-v2.docx` — Capabilities A/B/C
- `AURELIA-Build-Pipeline-Closure-Phase-2-Intent.docx` — 5 deferred gaps

### Future-work intent docs
- `AURELIA-Founder-Intelligence-Spec-v2.docx` — Sprint 9 in current PRD
- `AURELIA-Trainer-Intent.docx` — Sprint 18+ deferred

### KAIROS integration
- `KAIROS-Personal-Agent-Spec-v2.docx` — personal-life assistant agent; flagged in audit A13 because PRD references event types not documented in this spec

## What is NOT in this bundle

Deliberately excluded:
- Superseded PRD versions (v1, v2, v3, v3.1, v3.2, v3.3, v3.4, v3.5, v3.6) — only current v3.7 included
- Older Audit Reconciliation versions (v1-v5) — only v6 included
- Older v1 specs that have v2 replacements (KAIROS v1, BPC Spec v1, Founder Intelligence v1, Substrate Features v1)
- Working files (prompts log, older session handoffs)
- Personal/unrelated documents from operator's session history

## Bundle creation context

Created 9 May 2026 by the previous Claude session as final deliverable before handoff to new Claude or human reviewer. The previous Claude has not been an independent reviewer — fresh-eyes review is the recommended next step per `AURELIA-Handoff-To-Next-Claude.docx` §0 and `AURELIA-Audit-Reconciliation-v6.docx` §6.

## Bundle integrity

All 27 files have been validated as well-formed docx. None are placeholder stubs. Total bundle size approximately 700 KB unzipped.
