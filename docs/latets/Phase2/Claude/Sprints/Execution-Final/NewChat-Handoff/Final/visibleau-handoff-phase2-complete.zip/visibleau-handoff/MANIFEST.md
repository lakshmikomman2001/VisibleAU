# VisibleAU Handoff Bundle — Manifest

Generated at Phase 2 completion (Sprint 9 + Gate 3 + drizzle-kit infra fix).

## Start here
- **HANDOFF-READ-ME-FIRST.md** — the master handoff. Method, canon, findings, open items, house style.

## Phase 1 (12 sprints, complete)
- phase-1/lld/                — 7-layer LLD
- phase-1/sprint-prompts/     — sprints 1–12 + index
- phase-1/fixes/              — 50 fix prompts
- phase-1/prototype/          — prototype JSX

## Phase 2 (9 sprints, complete)
- phase-2/lld/                — LLD v8.70 (CANON)
- phase-2/sprint-prompts/     — sprints 1–9
- phase-2/prototype/          — FIX17 (the ONLY canonical prototype; 4 cross-layer Health Check dims)
- phase-2/fixes-and-test-track/  — S1–S8 fixes + full 5-section test tracks
- phase-2/sprint9-and-gate3/  — THIS SESSION: S9 walk, S9 test track, all of Gate 3, drizzle-kit fix, G-3 dedup sequence

## Canon counts (corrected this session)
- 71 tables (34 P1 + 37 P2)
- 40 Inngest functions (source of truth: scripts/qa/inngest-serve-manifest.txt — do not hard-code)
- 16 GAPs

## Two DBs (both must receive every migration)
- visibleau       (dev, empty)
- visibleau_prod  (the app's real DB — 19 audits, 3,405 citations)
