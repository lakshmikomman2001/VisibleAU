# BREAK-PROOF S9-HIGH-08 (F28) — prove the tier gate ACTUALLY enforces (not just that the string exists)

## Why this is needed
The F28 report offered this as the break-proof:
> *"Source-level grep test: all 6 route files must contain `assertTier`, `TierInsufficientError`, and
> `"Growth plan required"` — removing any one causes RED."*

**That is a grep, not a break-proof.** It asserts the *string* `assertTier` appears in the file. It
stays **green** for every one of these:
```ts
if (false) await assertTier(orgId, "growth");            // string present · gate dead
await assertTier(orgId, "free");                          // string present · gate useless
try { await assertTier(orgId, "growth"); } catch {}       // string present · gate swallowed
const assertTier = async () => {};                        // string present · gate stubbed
```
All four ship a **broken paywall past a green test**.

**F28 exists precisely because a control LOOKED present and enforced nothing.** Closing it with a test
that checks whether the control *looks* present repeats the same mistake one layer up. The gate must
be proven by **behaviour**: disable it → the test must go RED **with leaked data**.

READ-ONLY except for a temporary, reverted edit.

---

## TASK — the behavioural break-proof

### 1 — Disable the gate in ONE route
```bash
cd c:/startup/VisibleAU/src
```
In **`app/api/brands/[brandId]/latest-audit/route.ts`**, comment out the tier check:
```ts
// await assertTier(organizationId, "growth");   // ← TEMPORARILY DISABLED (break-proof)
```
Leave everything else untouched (`assertBrandAccess` stays — we're testing the TIER gate, not
ownership).

### 2 — Run the free-tier test
```bash
npx vitest run tests/phase2/sprint9/integration/ -t "tier"
```

**EXPECTED: RED.** The free-tier request must now return **200 with the audit payload** instead of
403. The failure message should show the leak — something like:
```
× free tier → /latest-audit returns 403
  AssertionError: expected 200 to be 403
  Received body: { audit: { scoreSentimentNumeric: 100, ... }, actionItems: [...] }
```

⚠️ **This is the whole point: the test must fail BECAUSE DATA CAME BACK.** A failure that merely says
"expected 403, got 500" or "route not found" proves nothing — it means the test isn't actually
exercising the data path.

**⚠️ IF IT STAYS GREEN → the gate is NOT enforcing.** Then one of these is true, and it's a
**finding**, not a test problem:
- the test is asserting on a mock, not on the route's real response
- the free-tier fixture isn't actually free tier (check `subscriptions.tier` for that org — and
  whether a subscription row exists at all)
- the route is being short-circuited earlier (by `assertBrandAccess`, or auth) so the tier path never
  runs — meaning the 403 you saw came from somewhere else entirely
**Diagnose which and report it.**

### 3 — Revert and confirm green
```bash
git checkout app/api/brands/[brandId]/latest-audit/route.ts
npx vitest run tests/phase2/sprint9/integration/ -t "tier"
```
→ back to green.

### 4 — Repeat for ONE more route (a different shape)
Do the same for **`app/api/brands/[brandId]/tasks/route.ts`** — it has **both GET and POST**.
- Disable the tier check on the **POST** handler only → the free-tier POST test must go **RED**.
- ⚠️ If the POST handler has **no** tier check at all (only the GET does), **that's a live finding** —
  a free user could *create* a remediation task. Report it.

### 5 — The XHR-level assertion (the wire, not the DOM)
The Playwright §5.5 test currently asserts the lock renders. **The DOM was never the problem — the
wire was.** Strengthen it:
```ts
const responses: any[] = [];
page.on('response', async (r) => {
  if (r.url().includes('/api/brands/')) {
    responses.push({ url: r.url(), status: r.status(), body: await r.text().catch(() => '') });
  }
});
// ... load /brands/{id}/health-check as a FREE-tier user ...

// Every brand API call must be 403 — and NO body may contain score data:
for (const r of responses) {
  expect(r.status).toBe(403);
  expect(r.body).not.toMatch(/scoreSentimentNumeric|scoreFrequency|scoreComposite/);
}
// And the DOM must not contain the numbers either:
await expect(page.locator('body')).not.toContainText('100');   // Metropolitan's real sentiment
```
⚠️ **Assert on the RESPONSE BODY, not just the status.** A 403 that still returns the payload in its
body would pass a status-only check.

---

## CONSTRAINTS
- The edit is **temporary** — `git checkout` it after. Do not leave the gate disabled.
- **Do not "fix" the test to make it red.** If it stays green with the gate disabled, that is the
  finding — report it honestly rather than adjusting the assertion until it fails.
- Do not touch `assertBrandAccess` — ownership and tier are orthogonal controls; we're proving the
  tier one.

## REPORT BACK (paste inline)
1. **The RED output** from step 2 — and confirm the failure is *"got 200 with the audit payload"*,
   **not** a 500/404/route-not-found.
2. Green again after revert.
3. **The `tasks` POST result** — does the POST handler have a tier check at all? (If not: a free user
   can create tasks — **a live finding.**)
4. The XHR-body assertion result: does a free-tier page load leak **any** score data on the wire?
5. If any step stayed green when it should have gone red → **say so plainly.** That's a finding, not a
   formality.
