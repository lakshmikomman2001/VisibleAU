# DIAGNOSE — Health Check 404 (the route RAN and threw; it's not missing)

## The key signal
```
GET /brands/{id}/health-check 404 in 378ms (application-code: 361ms)
```
⚠️ **A genuinely missing route 404s in ~5ms** — Next.js checks its route table and bails. **This spent
361ms in application code before returning 404.** That means **the route EXISTS and RAN** — something
inside the page threw (or a query returned null), and the code called **`notFound()`**, converting a
data/runtime failure into a 404.

⚠️ **This is almost certainly a regression from the last hour.** The Health Check page reads the two
tables we just changed: **`technical_audits`** (10 rows deleted, phantom writer removed) and
**`brand_entity_scores`** (`0011` added a unique index + CASCADE). A query that assumed the old shape,
or an import from the deleted `technical-audit-run.ts`, would produce exactly this.

**READ-ONLY diagnosis. Change nothing yet — find the cause first.**

---

## STEP 1 — Confirm the route exists and find the `notFound()` trigger
```bash
cd c:/startup/VisibleAU/src
# Does the page file exist?
find app -path "*brands*health-check*" -name "page.tsx"
# Where does it call notFound() / throw / redirect — the branch being hit:
grep -n "notFound\|throw\|redirect\|return null" app/(auth)/brands/[brandId]/health-check/page.tsx
```
⚠️ **Report the `notFound()` condition.** What has to be null/false for the page to 404? That condition
is what's now failing.

## STEP 2 — What does the page QUERY, and does it throw?
```bash
# Read the page's data fetching — what does it load, from which tables/routes?
cat app/(auth)/brands/[brandId]/health-check/page.tsx
# If it calls an API route or a lib function, find that too:
grep -rn "health-check\|healthCheck\|buildHealthCheck\|getHealthCheck" lib/ app/api --include=*.ts | head
```
Identify the exact query behind the page. Then ⚠️ **check its imports for casualties of today's
removal:**
```bash
# Does the page (or its data layer) import anything from the DELETED phantom writer?
grep -rn "technical-audit-run\|technicalAuditRun" app/(auth)/brands/[brandId]/health-check/ lib/ --include=*.ts --include=*.tsx
# Anything importing a symbol that moved when we ported the emit to run-technical-audit-inline?
grep -rn "orchestrateTechnicalAudit\|technical-audit" app/(auth)/brands/[brandId]/health-check/ --include=*.tsx
```
⚠️ **If ANY import resolves to the deleted file or a moved symbol → that's the break.** A broken import
makes the module fail to load → the route effectively 404s. **Report every import the page makes that
touches technical-audit anything.**

## STEP 3 — ⚠️ SURFACE THE REAL EXCEPTION (the terminal, not the browser)
`notFound()` swallows the underlying error. Get the actual throw:
```bash
# Run the page's DB query directly against prod and see if it errors:
```
- Take the query the page runs (from Step 2) and **execute it against `visibleau_prod`** for
  Metropolitan (`418f321f-2489-4560-aaa9-895728580465`).
- ⚠️ **Does it throw, return null, or return unexpected rows?**
- Specifically: if the query **joins `technical_audits`** and expected ONE row per audit but the code
  does `.then(r => r[0])` or similar — after our dedup there's still one row, so that's fine — **but if
  it expected the PHANTOM's shape** (e.g. `findings: {}` handling, or a `robots=100` value), the real
  row's different shape could break it.
- If it reads **`brand_entity_scores`** — did the new unique index or a column the query references
  change?

**Also — read the SERVER TERMINAL when hitting the page:**
```bash
# With the dev server running, hit /health-check and capture the terminal (NOT the browser console).
# The real stack trace prints there — notFound() hides it from the browser but the throw logs server-side.
```
⚠️ **Paste the server-side stack trace.** That names the exact line and error.

## STEP 4 — Rule out the cheap causes first
```bash
# Stale build? (we hit this as F18 — a stale .next manifest)
ls -la .next/server/app/\(auth\)/brands 2>/dev/null | grep -i health
# Does the route compile at all?
npx tsc --noEmit 2>&1 | grep -i "health-check"
```
⚠️ **If `tsc` reports an error in the health-check page → it's a compile break** (likely a dangling
import from Step 2), and the fix is there. If `tsc` is clean → it's a runtime/data throw (Step 3).

---

## THE VERDICT — which is it?
| Finding | Cause | Fix location |
|---|---|---|
| Page imports the deleted `technical-audit-run` / a moved symbol | **Compile break** from the phantom removal | fix the import |
| Query throws / returns null against prod | **Data-shape regression** from the dedup or `0011` | fix the query's assumption |
| `tsc` clean, query fine, only 404s in a stale `.next` | **Stale build** (F18 class) | `rm -rf .next && npm run dev` |
| `notFound()` fires because a row the page requires is now gone | **The dedup deleted something the page depended on** | ⚠️ restore from `prod_backup_pre0011.sql` if needed, fix the query |

## CONSTRAINTS
- **READ-ONLY** until the cause is known. Do not edit the page or re-run migrations blindly.
- ⚠️ **If the cause is the dedup deleting a needed row** — we have `prod_backup_pre0011.sql`. **Report
  before restoring**; don't act unilaterally.
- The real error is in the **server terminal**, not the browser console — capture it there.
- Don't "fix" it by removing the `notFound()` — that would hide a real error behind a broken page.

## REPORT BACK (paste inline)
1. **Does the page file exist?** What condition triggers its `notFound()`?
2. ⚠️ **Does the page import anything from the deleted `technical-audit-run.ts` or a moved symbol?**
3. **The page's query run against prod** — throws, null, or unexpected rows?
4. ⚠️ **The server-terminal stack trace** when hitting `/health-check` — the actual error + line.
5. **`tsc` on the health-check page** — clean or erroring?
6. ⚠️ **THE VERDICT** — compile break / data regression / stale build / deleted-row dependency?
