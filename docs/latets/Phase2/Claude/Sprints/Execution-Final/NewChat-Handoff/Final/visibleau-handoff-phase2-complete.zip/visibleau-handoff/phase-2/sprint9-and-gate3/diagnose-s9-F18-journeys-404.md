# DIAGNOSE S9-F18 — `/discovery/journeys` 404s even though `page.tsx` EXISTS (read-only)

## Why this is NOT dismissible
The F16/F18 report concluded *"F18 is NOT a real bug — both pages exist"* and attributed the 404 to
*"a tier-gate 403 rendered as a locked state"* or *"a transient dev-server issue."* Neither fits the
evidence:

1. **The screenshot is a full-page Next.js not-found** — big "404", "Couldn't find that page.",
   "← Back to dashboard". **A tier-gate 403 does not render as a 404** — it renders the locked/upgrade
   state (the TierGate pattern used throughout this app).
2. **"Transient" is speculation, not evidence.** The user hit it on a real click.
3. **A `page.tsx` existing does NOT mean the route resolves.** That is the exact assumption this
   sprint has repeatedly disproven (F12: a component that existed and was never mounted). The
   dead-link guard proves an href matches a FILE PATH — it does **not** prove the route RENDERS.

**Real explanations that fit the evidence:**
- The page calls **`notFound()`** internally — e.g. a brand-access or tier check that 404s rather than
  403s. **S9 canon explicitly specifies `cross-org → 404`**, so 404-on-denial is a DELIBERATE pattern
  here. A mis-scoped check would 404 a legitimate user.
- The **Agency tier gate** (the report says the card uses `tier: "Agency"`) misfires.
- A server-side fetch inside the page **throws**, and Next renders not-found.

Each is a real bug a customer would hit. READ-ONLY — diagnose, don't fix.

## Task

### 1 — Reproduce it (the empirical question the report skipped)
Ask Sri to click the link again (or navigate directly) and report:
- Does `/brands/0f531803-b529-4d09-9fd6-b6272b5baba8/discovery/journeys` **404 consistently**, or was
  it a one-off?
- **The terminal output during that request** — this is decisive:
  - a `GET /brands/.../discovery/journeys 404` → the route itself returns not-found
  - a `200` with a client-side 404 → the page renders and then calls notFound()
  - a 500/exception → a throw, rendered as not-found
  - a compile message → the "dev server hadn't compiled it" theory (then it should work on retry)

### 2 — What does the page DO before it renders?
```bash
cd c:/startup/VisibleAU/src
sed -n '1,80p' "app/(auth)/brands/[brandId]/discovery/journeys/page.tsx"
grep -n "notFound()\|redirect(\|404\|assertBrandAccess\|tier\|GROWTH\|AGENCY\|throw\|error" \
  "app/(auth)/brands/[brandId]/discovery/journeys/page.tsx"
```
Look for:
- **`notFound()`** — under what condition? (a failed brand-access check? a missing record? an empty
  result set?) **If the page calls `notFound()` when there are ZERO journeys, that's the bug** — an
  empty result must render an empty state, NOT a 404. And Bondi has 0 journeys (F16 showed the count
  as 0 on its card), which would explain the 404 EXACTLY.
- **A tier gate** — which tier does it require? Your org is **Agency** tier, so an Agency gate should
  pass. If it requires something else (or reads the tier from the wrong source — `organizations.tier`
  instead of `subscriptions.tier`, the S8 footgun), it would deny.
- **`assertBrandAccess`** — canon says cross-org → 404. If it's mis-scoped, a legitimate brand 404s.

### 3 — The prime suspect: does it 404 on an EMPTY result?
This fits the evidence perfectly:
- **Bondi's Discovery card shows `0 journeys`** (F16 — and its DB count may genuinely be 0)
- You clicked "View →" on **Bondi** → **404**

If `journeys/page.tsx` does something like `if (!journeys.length) notFound()` — or fetches a single
journey by id and 404s when absent — then **an empty result renders as "page doesn't exist"** rather
than "no journeys yet". That is a real, reproducible bug affecting every brand with no journeys.
```bash
grep -n "length\|!journeys\|journeys\[0\]\|notFound" \
  "app/(auth)/brands/[brandId]/discovery/journeys/page.tsx"
```

### 4 — Does METROPOLITAN's journeys link 404 too?
Metropolitan showed **16 comparisons** (so it has S7 discovery data) but **0 journeys**.
- Test `/brands/418f321f-2489-4560-aaa9-895728580465/discovery/journeys`
- And test its **Competitor Comparisons "View →"** (`/discovery/comparisons`) — that card has 16
  results.
**If comparisons (16 results) loads but journeys (0 results) 404s on BOTH brands → the empty-result
404 hypothesis is confirmed.** That's the cleanest possible A/B.

## Report back (paste inline)
1. **Does it 404 consistently?** (Bondi + Metropolitan) — and does `/discovery/comparisons` load?
2. **The terminal during the request** — 404 / 200 / 500 / compiling?
3. What the page does before rendering: does it call `notFound()`, and **under what condition**?
4. The tier gate: which tier, read from which source (`subscriptions.tier`, per S8 canon)?
5. **VERDICT:** is F18 (a) an empty-result-404 bug, (b) a tier/access mis-gate, (c) a throw, or
   (d) genuinely transient (it consistently works on retry)?

## Constraints
- READ-ONLY. Diagnose only.
- Do NOT close F18 on "the file exists" — that is not evidence the route resolves. The user saw a
  404; explain it or reproduce its absence.
- If it IS transient (works reliably now, terminal shows a compile on first hit), say so with the
  evidence — that's a legitimate outcome, but it needs proof, not a hypothesis.
