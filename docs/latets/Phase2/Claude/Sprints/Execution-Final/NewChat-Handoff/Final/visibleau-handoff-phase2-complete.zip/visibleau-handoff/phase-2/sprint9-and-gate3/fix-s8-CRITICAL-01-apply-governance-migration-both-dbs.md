# FIX S8-CRITICAL-01 — Apply the Sprint 8 governance migration to BOTH databases (org_members / audit_trail / data_residency_log / org_feature_flags missing on prod)

## Severity: CRITICAL (brand-page outage across all 44 S1–S7 brand routes)

## Symptom (from the real server terminal — the app running against `visibleau_prod`)
Every `/api/brands/[brandId]/…` request 500s:
```
Error: Failed query: select "role", "brand_access" from "org_members" where (...)
  at getMemberRecord (lib/governance/access-control.ts:56)
  at assertBrandAccess (lib/governance/access-control.ts:80)
  at GET (app/api/brands/[brandId]/visibility/route.ts:22)
[cause]: PostgresError: relation "org_members" does not exist  (code 42P01)
→ GET /api/brands/.../visibility 500
```

## Root cause
The Sprint 8 migration (`db/migrations/*sprint8_governance.sql`) that creates the four
governance tables was NOT applied to `visibleau_prod` (the DB the app runs against). The S8b-01
retrofit correctly added `assertBrandAccess` (→ `getMemberRecord` → `SELECT … FROM org_members`)
to all 44 brand routes as a pre-flight gate, so with the table absent, EVERY brand-scoped route
throws 42P01 → 500. This is the recurring dev-applied/prod-missing gap (S5 trust tables, S5
citation cols, S6 brand_token, S7 seed). The §12 greps passed because they read the migration
SQL file on disk, never whether it was applied to a DB.

## The two databases (per project canon)
- `visibleau` — dev (tests run here; `LLM_MODE=mock`)
- `visibleau_prod` — LOCAL prod (**the app runs against this one**)
Migrations + seeds MUST be on BOTH. The migration is MI-01 idempotent (`CREATE TABLE IF NOT
EXISTS`, `DROP POLICY IF EXISTS` before each `CREATE POLICY`), so re-applying to a DB that already
has the tables is a safe no-op — apply to both regardless of current state.

## Task

### Step 1 — Identify the exact migration file and the app's DB connection
```bash
cd c:/startup/VisibleAU/src
ls db/migrations/*sprint8_governance.sql          # note the exact filename (00NN_phase2_sprint8_governance.sql)
# Confirm which connection string the RUNNING app uses (the one that 500s):
grep -RнE "DATABASE_URL|visibleau_prod" .env .env.local .env.production.local 2>/dev/null
```
Use the project's real connection strings from the env files below; the examples here assume
`postgresql://postgres:postgres@localhost:5432/<db>` — REPLACE if the project differs.

### Step 2 — Apply the migration to BOTH DBs
Prefer the project's own migration runner if one exists (check `package.json` scripts for
`db:migrate`, `db:push`, `drizzle-kit migrate`). If the runner targets only one DB, run it once
per DB by pointing `DATABASE_URL` at each. Otherwise apply the SQL file directly:

```bash
# DEV
psql "postgresql://postgres:postgres@localhost:5432/visibleau" \
  -f db/migrations/00NN_phase2_sprint8_governance.sql
# PROD (the one that is currently broken)
psql "postgresql://postgres:postgres@localhost:5432/visibleau_prod" \
  -f db/migrations/00NN_phase2_sprint8_governance.sql
```

### Step 3 — VERIFY the tables exist on BOTH DBs (do NOT trust "it ran" — this is the standing lesson)
```bash
for DB in visibleau visibleau_prod; do
  echo "=== $DB ==="
  psql "postgresql://postgres:postgres@localhost:5432/$DB" -c "\dt public.audit_trail" \
    -c "\dt public.org_members" -c "\dt public.data_residency_log" -c "\dt public.org_feature_flags"
done
```
EXPECT: all four tables listed for BOTH databases. If any is missing on either DB, the apply
failed — STOP and report, do not proceed.

### Step 4 — VERIFY the four columns the failing query needs actually exist on org_members
The query selects `role`, `brand_access`, filters on `organization_id`, `user_id`, `is_active`:
```bash
psql "postgresql://postgres:postgres@localhost:5432/visibleau_prod" -c "\d public.org_members"
```
EXPECT columns incl: `organization_id`, `user_id`, `role`, `brand_access` (jsonb),
`is_active` (bool NOT NULL DEFAULT true), `invitation_token` (unique). Confirm
`UNIQUE(organization_id, user_id)` is present.

### Step 5 — VERIFY RLS is enabled on the four tables (MI-01 policies applied), on BOTH DBs
```bash
psql "postgresql://postgres:postgres@localhost:5432/visibleau_prod" -c "
  SELECT tablename, rowsecurity FROM pg_tables
  WHERE tablename IN ('audit_trail','org_members','data_residency_log','org_feature_flags')
  ORDER BY tablename;"
```
EXPECT `rowsecurity = t` for all four.

### Step 6 — Run the DR-01 residency writer against prod and confirm it wrote the canonical rows
The residency page is empty until `record-data-residency.ts` UPSERTs. Canon (LLD 8733–8743) is
**7 rows** per org: audit_data, evidence_snapshots, pdf_reports, llm_cache, crawler_logs,
llm_processing_openai, llm_processing_anthropic — NOT 5. Invoke the writer on provisioning path
for the validation org, or run its idempotent entrypoint, then:
```bash
psql "postgresql://postgres:postgres@localhost:5432/visibleau_prod" -c "
  SELECT data_type, storage_region, provider, retention_period
  FROM data_residency_log
  WHERE organization_id = 'da1071de-6dbd-4e08-8f43-29f76c123be9'
  ORDER BY data_type;"
```
EXPECT 7 rows for the Metropolitan Plumbing org. If only 5 appear, the RESIDENCY map is missing
the two `llm_processing_*` entries — that is a SEPARATE finding (writer incomplete), report it.

### Step 7 — Confirm the brand routes recover
Reload a brand page and hit the visibility API:
```bash
# From the app, load /brands/418f321f-2489-4560-aaa9-895728580465 and watch the terminal.
```
EXPECT: `GET /api/brands/.../visibility 200` (no 42P01). The 500s must be gone.

## Constraints
- Do NOT edit the migration SQL to "fix" anything — the file is correct; it just wasn't applied.
  The only change here is APPLYING it + verifying. If Step 3/4/5 reveal the SQL itself is wrong,
  report back before altering canon-derived DDL.
- Do NOT weaken or remove `assertBrandAccess` from the brand routes to "unblock" — the gate is
  correct per LLD 8635–8646; the fix is the table, not the gate.
- subscriptions.tier remains the sole tier source (unchanged here).

## Recommended: a db:migrate:all / seed:all convenience (prevents the 6th recurrence)
If not already present, add package.json scripts that apply migrations AND run the residency
writer against BOTH `visibleau` and `visibleau_prod` in one command, so future sprints cannot
apply-to-dev-only. This is the standing recommendation from the handoff (the dev/prod gap has
bitten 5+ times). Scope this as a follow-up if it risks touching unrelated migration wiring.

## Report back
Paste inline: the Step 3 `\dt` output for BOTH DBs, the Step 4 `\d org_members`, the Step 5 RLS
query, the Step 6 residency row dump, and one Step 7 `…/visibility 200` terminal line.
