# FIX S8-MISC — invite-form label a11y (F24) + weak empty-state guard (4.7) + TierGate canon flag

Three items surfaced by Section 4's own honesty. One real defect (F24), one weak-guard upgrade
(4.7), one canon flag (TierGate). Grouped because each is small.

---

## F24 — LOW — invite-form labels not programmatically associated (accessibility)
Section 4 found the invite-form labels lack `htmlFor`, so the 4.3 test had to WORK AROUND it
(`getByPlaceholderText` / `getAllByRole` instead of `getByLabelText`). That workaround is the
signal: the labels are not associated with their inputs, so a screen-reader user tabbing to the
email / role / brand-access controls hears no label. Accessibility is a first-class standard on
this project — fix the gap rather than let the test accommodate it.

### Fix
In `invite-form.tsx`, associate each label with its input:
- Give each input an `id`; give each `<label>` a matching `htmlFor` (email, role select,
  brand_access picker). React uses `htmlFor`.
- If a control is a custom component (the brand_access picker), ensure it exposes an `id`/labels its
  trigger (aria-labelledby or an associated label) so it's not an unlabeled combobox.
- Keep the visible label text unchanged; this is purely the programmatic association.

### Then upgrade the 4.3 test to use the accessible query
Once labels are associated, change the 4.3 assertions from `getByPlaceholderText(...)` /
`getAllByRole("combobox")[n]` to **`getByLabelText(...)`** — the accessible query that only passes
when the label↔input association is correct. This makes the test ALSO guard the a11y association
(regression-proof: if someone removes `htmlFor` again, `getByLabelText` fails).

Re-break: remove one `htmlFor` → the corresponding `getByLabelText` assertion FAILS. Revert.

---

## 4.7 — LOW — empty-state tests render inline markup, not the real component (weak guard, F23 class)
The 4.7 tests assert the canon copy ("No activity yet") against **inline markup the test itself
renders**, not the actual page/EmptyState component. So they'd stay green if the real audit-trail
page's empty state changed — the same self-referential weakness as F23 (the §2 self-seeding test).
This is the THIRD "test doesn't exercise the real thing" this sprint — worth closing the pattern.

### Fix
Point the 4.7 empty-state tests at the REAL component:
- Import the actual `EmptyState` component (and/or the audit-trail page's empty branch) and render
  IT with the empty/no-rows props, then assert it renders "No activity yet" — so the guard breaks if
  the real component's copy or render changes.
- If the page component can't render in isolation (needs data-fetch/context), at minimum import the
  shared `EmptyState` component the page uses and assert the copy flows through it; do NOT assert a
  string the test itself hardcoded into inline JSX.
- Same for the team empty (solo-owner → owner row only) and residency empty: render the real
  component, not a stand-in.

Re-break: change the real EmptyState/page empty copy → 4.7 FAILS (currently it wouldn't). Revert.

---

## TierGate — CANON FLAG (no code change)
Section 4 found `TierGate`'s actual API is `{ requiredTier, locked, children }` — simpler than the
prototype (700–738), which shows `{ requiredTier, currentTier, feature }`. The build's API is the
one in use and it's the cleaner pattern (a `locked` overlay wrapping `children`, vs passing
display strings) — and it's what F18's fix used and we render-verified on both Agency and Growth.

Resolution: **the build's API is correct; the PROTOTYPE is outdated for TierGate.** No code change.
- [LLD/prototype flag for Sri] Update the prototype's TierGate signature to
  `{ requiredTier, locked, children }` (or note the FIX17 version is superseded), so TierGate isn't
  treated as prototype-authoritative later. The "Agency plan required" copy + Upgrade→billing are
  correct as built.
- Section 4's TierGate tests (4.6) are correctly written against the real API — leave them.

---

## Constraints
- F24: real source fix (add htmlFor/id) + upgrade the 4.3 test to getByLabelText. Keep visible
  labels unchanged.
- 4.7: import + render the REAL EmptyState/page component; no self-hardcoded copy strings.
- TierGate: flag only, no code change.
- Assert canon; re-break each fixed guard to prove it now bites.

## Report back (paste inline)
1. F24: the invite-form label association added; 4.3 now uses getByLabelText; re-break RED on
   removing an htmlFor.
2. 4.7: the empty-state tests now import the real component; re-break RED on changing the real copy.
3. TierGate: confirmed flagged for canon (no code change).
4. Final green after reverts (+ any change to the test count).
