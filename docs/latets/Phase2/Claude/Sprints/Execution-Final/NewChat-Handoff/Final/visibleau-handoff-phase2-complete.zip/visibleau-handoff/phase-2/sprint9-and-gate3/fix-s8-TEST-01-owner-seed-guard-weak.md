# FIX S8-TEST-01 (F23) — Owner-seed provisioning guard is weak (false-pass + self-seeding)

## Severity: MEDIUM (a weak guard on a HIGH finding — F6 owner-not-seeded could recur undetected)
The Section-2 harness verify surfaced that the owner-seed provisioning guard doesn't actually guard
F6. Two weaknesses:

1. **False-pass source assertion.** `s8-route-guards` asserts `authSrc.toContain('role: "owner"')`
   — but `role: "owner"` ALSO appears in the `users`-table insert (server.ts:~69), so this passes
   even if the `orgMembers` owner insert is deleted. The re-break only went RED because the
   `brandAccess`/`acceptedAt` assertions (unique to the orgMembers insert) failed alongside it —
   the `role` assertion itself is hollow.
2. **Self-seeding DB test.** The 2.8 integration test inserts its OWN `orgMembers` row
   (`testDb.insert(orgMembers).values(...)`) and reads it back — it never calls
   `afterCreateOrganization`. It proves the table shape, NOT that provisioning runs the insert. It
   would stay green if the provisioning hook were deleted entirely — i.e. it cannot detect F6, the
   very bug it's meant to guard.

## Task — make the guard actually catch F6

### Fix 1 — scope the source assertion to the orgMembers insert (kill the false-pass)
In `tests/unit/governance/s8-route-guards.test.ts`, replace the ambiguous
`authSrc.toContain('role: "owner"')` with an assertion that matches the owner ROLE **within the
orgMembers insert specifically**, not anywhere in the file. Options (pick the robust one):
- Assert the full owner-seed pattern in one contiguous match, e.g. a regex that requires
  `insert(orgMembers)` … `role: "owner"` … `brandAccess: null` in the same `.values({...})` block:
  ```
  expect(authSrc).toMatch(/insert\(\s*orgMembers\s*\)[\s\S]{0,400}role:\s*["']owner["'][\s\S]{0,200}brandAccess:\s*null/);
  ```
  (tune the window; the point is `role:"owner"` must be INSIDE the orgMembers insert, so deleting
  that insert makes it fail even though the users-table `role:"owner"` still exists).
- Keep the `brandAccess`/`acceptedAt`/`isActive` assertions (those are already orgMembers-scoped and
  correctly failed) — but the `role` assertion must no longer be satisfiable by the users insert.
Verify: deleting ONLY the orgMembers insert now fails the role assertion too (not just brandAccess).

### Fix 2 — make the provisioning DB test call the REAL provisioning path (not self-seed)
In `tests/integration/governance/s8-governance-db.integration.test.ts`, the 2.8 provisioning test
must exercise the actual hook, so it fails if provisioning stops seeding the owner:
- Instead of `testDb.insert(orgMembers).values(...)` then read-back, **invoke
  `afterCreateOrganization` (or the provisioning entry point that server.ts calls on org create)**
  with a freshly-created test org, then assert the owner `org_members` row EXISTS with
  `role='owner'`, `brand_access=null`, `is_active=true` — WITHOUT the test having inserted it.
- If `afterCreateOrganization` is not directly importable/callable in a test (side effects, auth
  context), the acceptable fallback is to drive it through the same code path the app uses (the
  org-create service), still WITHOUT the test pre-seeding the owner row. The invariant: the row must
  appear because PROVISIONING put it there, not because the test did.
- Same applies to the **residency writer** in 2.8 (F2): the residency rows must appear because
  provisioning called `recordDataResidency`, not because the test called it directly. Assert the
  7 rows exist post-provisioning without the test seeding them.

> If it turns out `afterCreateOrganization` genuinely cannot be invoked in the integration harness
> (hard auth/session coupling), REPORT that — then the guard belongs in the E2E section (section 5)
> as a real org-create flow, and the integration test should at minimum assert the provisioning
> SOURCE contains the full `.insert(orgMembers).values({... role:"owner" ...})` +
> `recordDataResidency(` call (a scoped source assertion, better than self-seeding). Say which
> path you took.

### Re-break proof (the real one this time)
After the fixes, delete the owner-seed insert in `afterCreateOrganization` (source) and run:
- Fix 1: the scoped `role`-in-orgMembers assertion FAILS (not just brandAccess).
- Fix 2: the provisioning DB test FAILS because the owner row is absent (since the test no longer
  self-seeds). Revert; confirm green.
Then delete the `recordDataResidency` call at provisioning → the 7-rows provisioning assertion FAILS.
Revert; confirm green.
This is the proof the guard now catches F6/F2 for real (the previous version could not).

## Constraints
- Test-only changes (+ the temporary source re-breaks, reverted). Do NOT modify server.ts /
  provisioning source except the throwaway re-break deletions.
- The provisioning test must NOT pre-seed the owner row or call the residency writer itself — the
  rows must appear via the provisioning path, or the test proves nothing.
- Keep the scoped-DELETE-by-testOrgId cleanup (confirmed SAFE — do not switch to TRUNCATE).
- Assert canon values (role='owner', brand_access=null, is_active=true; 7 residency rows).

## Report back (paste inline)
1. Fix 1: the new scoped assertion; confirmation deleting only the orgMembers insert now fails the
   role assertion (no longer a false-pass).
2. Fix 2: whether afterCreateOrganization is invoked directly or driven via the org-create service
   (or, if impossible, the fallback taken); confirmation the provisioning test now fails when the
   owner-seed / residency call is removed (the real re-break).
3. Final green after reverts.
