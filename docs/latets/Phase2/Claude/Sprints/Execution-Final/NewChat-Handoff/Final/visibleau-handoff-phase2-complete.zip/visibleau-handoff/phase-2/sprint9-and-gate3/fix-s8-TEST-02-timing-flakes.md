# FIX S8-TEST-02 — test-timing fixes: 5.1.2 residency-render flake + 4.7 skeleton timeout bump

## Both are TEST-ONLY. No product code changes.
Two confirmed flakes, both from timing against a single-threaded dev server / heavy import chain —
the product code is correct in both cases (the residency page HAS the §6U.4 graceful loading state;
the team page imports fine, just slowly). These fixes make the tests robust so they stop producing
false-reds (which train people to ignore red — the thing to avoid).

---

## Fix A — 5.1.2 (data-residency render): wait through the loading state before asserting the table
Confirmed FLAKE: the page renders skeletons, then "Residency information loading…" (§6U.4), then the
`<table>` once the two sequential fetches (`/api/auth/me` → `…/data-residency`) resolve with rows.
5.1.2's `toBeVisible` on `<table>` can expire during the graceful loading state under dev-server
load on a cold, just-provisioned org. The product is correct; the test just needs to wait for the
data, not race it.

In `tests/e2e/sprint8/s8-governance-e2e.spec.ts` (the "provisioned org's data-residency page renders
the 7 rows" test, ~line 318), make the wait robust. Preferred: wait for the loading state to clear,
THEN assert the table — and give the table a longer timeout (this is a cold provisioned org, two
sequential fetches):
```ts
await page.goto("/settings/data-residency");
await expect(page.getByRole("heading", { name: /Data Residency/i })).toBeVisible({ timeout: 10_000 });

// Wait through the §6U.4 graceful states (skeletons → "Residency information loading…") until the
// data resolves. The table only materializes after /api/auth/me → …/data-residency both return
// AND rows are present — on a cold, just-provisioned org this can take longer than 10s under load.
const loadingMsg = page.getByText(/Residency information loading/i);
await loadingMsg.waitFor({ state: "hidden", timeout: 30_000 }).catch(() => {}); // ok if it never showed
const table = page.locator("table");
await expect(table).toBeVisible({ timeout: 30_000 });
await expect(page.locator("tbody tr")).toHaveCount(7, { timeout: 30_000 });
```
(Alternatively, wait for the residency API response explicitly:
`await page.waitForResponse(r => r.url().includes("/data-residency") && r.ok())` before the table
assertion — even more deterministic. Use whichever matches the harness's style; the point is wait
for the data, not a fixed race window.)

Rationale: this asserts the REAL behavior (the 7 rows DO render, just after the graceful loading
state) without a brittle fixed timeout. It still fails for real if the table never renders (a true
regression) — it just no longer fails because the fetch was slow.

---

## Fix B — 4.7 (team page loading skeletons): bump the describe-block timeout 5s → 10s
Confirmed FLAKE: the team-page module import chain (team/page.tsx → TierGate → isTierAtLeast →
TIER_SEAT_LIMITS) takes ~4.9s to dynamically import, which exceeds vitest's default 5s under load.
Not a logic problem — a heavy import. Bump the timeout for that describe block (or the specific
test) so it stops false-redding.

In `tests/unit/governance/s8-governance-components.test.tsx`, for the 4.7 EmptyState/loading
describe block (the "team page loading → 3 skeleton rows" test), set the timeout to 10s:
```ts
// team page has a heavy dynamic-import chain (~4.9s); 5s default is too tight under load
describe("4.7 — EmptyState + loading skeletons (real component imports)", () => {
  // ...
  it("team page loading → 3 skeleton rows", async () => {
    // ...
  }, 10_000); // per-test timeout override
});
```
(Or set it at the describe level via `describe(..., () => {...})` + `vi.setConfig({ testTimeout: 10_000 })`
inside a `beforeAll`, whichever matches the repo's vitest style. A per-test `, 10_000` arg is the
simplest and most targeted.)

Rationale: targets only the slow-import test; doesn't loosen timeouts globally (a global bump would
hide genuinely-slow regressions elsewhere).

---

## Verify
```bash
cd c:/startup/VisibleAU/src
# 4.7 no longer flakes — run the unit file a few times:
npx vitest run tests/unit/governance/s8-governance-components.test.tsx
# 5.1.2 — run the provisioning E2E (single worker for determinism):
npx playwright test tests/e2e/sprint8/s8-governance-e2e.spec.ts --workers=1
```
EXPECT: 4.7 green reliably (no 5s timeout); 5.1.2 green (waits through the loading state, asserts the
7 rows). The 5.1 DB proof (test 1) still green.

## Constraints
- TEST-ONLY — no changes to `page.tsx`, `residency-table.tsx`, or any product code (both are
  confirmed correct; the §6U.4 loading state stays as-is).
- Don't loosen timeouts globally — target the two specific tests.
- 5.1.2 must still fail for a REAL regression (table never renders) — the fix waits for data, it
  doesn't blindly pass.

## Report back (paste inline)
1. Fix A: the 5.1.2 wait change; 5.1.2 green on a --workers=1 run (+ the 7-rows assertion holds).
2. Fix B: the 4.7 timeout override; 4.7 green across repeated runs.
3. Confirmation no product files changed (git diff shows only the two test files).
