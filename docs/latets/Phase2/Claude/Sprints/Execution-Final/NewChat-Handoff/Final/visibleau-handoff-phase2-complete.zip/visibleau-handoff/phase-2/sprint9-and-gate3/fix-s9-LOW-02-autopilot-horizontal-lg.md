# FIX S9-LOW-02 — Autopilot loop is vertical-only; §6U.2 requires horizontal on ≥lg (F5)

## Severity: LOW (spec'd responsive layout not implemented — the loop reads as a list, not a loop)

## The finding
`autopilot-loop.tsx:238-251` uses `max-w-[640px] mx-auto` with `LoopStepCard` at `flex gap-5 mb-6` —
a **vertical timeline at every breakpoint**. There is no horizontal mode.

§6U.2 binds: **"RESPONSIVE: the 5-step timeline is horizontal on `≥lg`, vertical (stacked step cards)
on `<lg`."**

Why it matters beyond pixel-compliance: the Autopilot LOOP is the sprint's primary story
(Monitor→Explain→Prioritize→Execute→**Measure**). A horizontal 5-step timeline on desktop reads as a
*cycle/pipeline* — the "aha" the sprint exists to create. A vertical stack reads as a to-do list. The
LLD calls this loop "the aha moment for every Growth user"; the desktop layout is where that lands.

## Task
In `autopilot-loop.tsx` (and `loop-step-card.tsx` if the card owns its own layout):
- **`<lg`** → keep the current vertical stacked timeline (it's correct — don't regress it).
- **`≥lg`** → horizontal 5-step timeline: steps laid left→right with the connectors running
  horizontally between them (the stepper look). Practically: switch the container from a fixed
  `max-w-[640px]` column to a responsive layout, e.g. `flex-col lg:flex-row` (with the connector
  element rotating/reflowing accordingly), and let the row use the available width on desktop rather
  than being clamped to 640px.
- The step **detail block** (the "current" step's expanded content — e.g. the step-5 pending copy) must
  remain readable in the horizontal layout: either render it BELOW the horizontal stepper (a common
  stepper pattern: the rail on top, the active step's detail beneath), or keep the active card
  expanded within the row if width allows. Do not truncate/hide the pending copy — that's the
  honesty-rule text (§6U.2), it must stay visible.
- Preserve the presentational step states (`done|current|pending`) and their styling in both layouts.

## Verify
- **`≥lg` (wide window):** the 5 steps run left→right as a horizontal timeline; the current step's
  detail (incl. "Validation audit scheduled — pending") is visible.
- **`<lg` (narrow window):** the steps stack vertically as they do now.
- Reduced-motion safe (RM-02) — no new motion introduced by the layout switch.

## Constraints
- Don't regress the vertical `<lg` layout (it currently works).
- The step-5 pending copy must remain visible in BOTH layouts (honesty rule text).
- Token-driven; no hex-alpha-from-var; no new chart/animation lib.
- Presentational step states unchanged (`done|current|pending` — never the DB enum).

## Report back (paste inline)
1. The layout change (the responsive container/connector approach).
2. **Screenshot at `≥lg`** — the horizontal 5-step timeline with the current step's detail visible.
3. **Screenshot at `<lg`** — the vertical stack still correct.
