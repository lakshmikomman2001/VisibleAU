# FIX S9-LOW-05 (F7) — Retire the vestigial org-scoped `WorkCompletedCard`

## Severity: LOW-MED — two unlabeled work-completed cards on the same dashboard, with different scopes, can show contradictory numbers.

## The finding (confirmed on screen)
`app/(auth)/dashboard/page.tsx` renders BOTH:
1. **`ActionProgressTracker`** (S9, ~§6U.4) — **brand-scoped** (the org's first brand):
   "0 / 1 gaps closed this month" + "Validation audit scheduled — measured impact pending"
2. **`WorkCompletedCard`** (Phase-2 Sprint 2, `components/domain/workflow/work-completed-card.tsx`,
   dashboard/page.tsx:276-285) — **org-scoped** via `getOrgProgressSummary(orgId)`:
   "No completed work yet this month"

Both report "work completed." **Neither is scope-labeled.** They currently agree by coincidence (both
effectively zero), but on a multi-brand org they diverge — the earlier diagnosis showed
`sri@visibleau.local` would see the org card say **"2 gaps closed"** directly above the S9 tracker
saying **"No gaps closed yet this month"** (because its first brand, Canva, has no tasks). A customer
has no way to know one is org-wide and one is brand-scoped.

**Canon:** LLD 9060 specifies **one** Action Progress Tracker ("the single most important retention
surface — it must be prominent, not buried"). Two competing cards buries it.

## Task — remove the vestigial card

### 1 — Remove it from the dashboard
`app/(auth)/dashboard/page.tsx` (~276-285):
- Delete the `<WorkCompletedCard />` render.
- Remove its import.
- Remove the `getOrgProgressSummary(orgId)` call **if nothing else uses it** (check first — it may be
  used elsewhere, e.g. the agency dashboard).

```bash
cd c:/startup/VisibleAU/src
grep -rn "WorkCompletedCard\|getOrgProgressSummary" app/ components/ lib/ | grep -v "dashboard/page.tsx"
```
- If `getOrgProgressSummary` is used ONLY by this card → it can stay in `lib/workflow/` (unused
  helpers are fine) but note it; do NOT delete the lib function unless clearly dead (the S9 tracker
  uses `getProgressSummary`, the brand-scoped sibling — don't confuse the two).
- If `WorkCompletedCard` is rendered ANYWHERE ELSE (e.g. an agency view), **do not delete the
  component** — only remove it from the dashboard. Report where else it lives.

### 2 — Keep the S9 tracker prominent
The `ActionProgressTracker` stays exactly as-is (it's verified: correct canonical query, correct
pending state). With the vestigial card gone it becomes the single, unambiguous work-completed
surface — which is what canon asks for.

### 3 — Check nothing else on the dashboard duplicates it
```bash
grep -n "Work Completed\|workCompleted\|gaps closed\|completed this month" \
  "app/(auth)/dashboard/page.tsx" components/domain/**/*.tsx | head
```
Confirm there's now exactly ONE work-completed surface on the dashboard.

## Verify
**Screenshot `/dashboard`** — scroll the full page:
- The S9 **Action Progress Tracker** (Work Completed + Measured Impact) is present.
- The old **"Work Completed / No completed work yet this month"** card is **GONE**.
- Nothing else on the page reports "work completed."
- The rest of the dashboard (Share of Voice, Recent audits, Agency Command Centre, Health Check
  banner) is unaffected.

## Constraints
- Remove the card from the DASHBOARD only. If `WorkCompletedCard` is used elsewhere, leave the
  component file intact and report where.
- Do NOT touch the S9 `ActionProgressTracker` (verified working — don't regress it).
- Do NOT delete `getProgressSummary` (the brand-scoped helper the S9 tracker depends on) — only the
  ORG-scoped `getOrgProgressSummary` is potentially now unused, and even that can stay.
- Don't disturb the other dashboard sections.

## Report back (paste inline)
1. What you removed (the render + import), and whether `getOrgProgressSummary` /
   `WorkCompletedCard` are used anywhere else.
2. **Screenshot `/dashboard`** (full scroll) — one tracker, no duplicate card.
3. Confirmation the S9 tracker still renders correctly (Work Completed + "Validation audit
   scheduled — measured impact pending").
