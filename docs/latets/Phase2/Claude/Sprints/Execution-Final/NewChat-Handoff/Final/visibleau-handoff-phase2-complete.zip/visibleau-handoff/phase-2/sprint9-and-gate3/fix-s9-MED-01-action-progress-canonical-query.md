# FIX S9-MED-01 — Action Progress Tracker: use the canonical `progress-summary.ts` helper (fixes F1+F2+F3+F4 at once)

## Severity: MEDIUM — the route re-implements the tracker query WRONGLY, while a correct canonical helper already exists and is unused.

## The root cause (F3) — everything else is a symptom
`lib/workflow/progress-summary.ts` (Sprint 2/3) ALREADY implements the LLD-canonical tracker query
correctly:
- `gte(remediationTasks.completedAt, monthStart)` — the right column ✓
- `isNotNull(remediationTasks.scoreAfter)` — the honesty filter ✓
- `sql\`date_trunc('month', now())\`` — UTC at the DB level ✓

`app/api/brands/[brandId]/action-progress/route.ts` **does not call it**. It rolls its own query, and
in doing so introduces three defects:

| # | Defect | Where | Why it's wrong |
|---|---|---|---|
| **F1** | uses `updatedAt` not `completedAt` | route.ts:48 | A task completed in MAY but merely EDITED this month counts as "closed this month" → inflates the count. The LLD's canonical query (7895, v8.26/v8.32) uses `completed_at`; the route followed the STALE Sprint-9-plan wording (LLD 9162 `updated_at`). The later canonical query governs. |
| **F2** | month boundary = JS **local time** | route.ts:41-43 (`new Date(); setDate(1); setHours(0,0,0,0)`) | LLD 7917 binds **UTC** `date_trunc('month', now())` — explicitly "identical to Phase 1 quota-check.ts so 'this month' matches the billing month" and "Do not switch to AEST here." A local-time boundary drifts from the quota month for AEST users. |
| **F4** | MEASURED IMPACT = `visibility_trends` citation-rate delta, **not** `SUM(lift_achieved) FILTER (score_after IS NOT NULL)` | tracker:217-239 / route | **This is the important one (upgraded from INFO → MEDIUM).** See below. |

## Why F4 is MEDIUM, not INFO
The LLD defines **MEASURED IMPACT** as the sum of **verified, per-task** lift:
`COALESCE(SUM(lift_achieved) FILTER (WHERE score_after IS NOT NULL AND <month>), 0)`.
The route instead renders the **overall brand `visibility_trends` citation-rate delta**. Two problems:

1. **Over-attribution.** Placing "3 gaps closed this month" beside "Citation rate ↑X%" invites the
   customer to read a causal link the data does not support — the trend moves for ANY reason
   (competitor changes, seasonality, an unrelated audit). §6U.2 warns of exactly this: the per-fix
   claim must be `lift_achieved`, "NOT the overall visibility_trends change attributed to one fix
   (that would over-attribute)." The Autopilot step 5 gets this RIGHT; the tracker gets it wrong.
2. **The pending-trigger is the wrong condition.** LLD: show "Validation audit scheduled — measured
   impact pending" when **`score_after IS NULL`** (no re-audit yet). The route shows pending when
   **`visibility_trends` has <2 rows** — an unrelated condition. So a brand with trend data but ZERO
   re-audits (exactly the current prod state: `score_after` NULL on every task) sees a **citation-rate
   number where the LLD says it must see "pending."** The honesty rule's trigger has been swapped for
   a look-alike.

## Task

### Step 1 — Read the canonical helper's signature + return shape
```bash
cd c:/startup/VisibleAU/src
sed -n '1,80p' lib/workflow/progress-summary.ts
grep -n "export\|function\|return\|interface\|type " lib/workflow/progress-summary.ts | head
```
Confirm what `getProgressSummary()` (or whatever it exports) takes (brandId? scope?) and returns
(the count + the lift sum?). If it returns exactly the two canonical numbers, the route becomes a thin
caller. If its shape is close but not identical, EXTEND the helper (don't fork it) — one canonical
implementation, per §F3.

### Step 2 — Rewrite the route to call the helper
`app/api/brands/[brandId]/action-progress/route.ts`:
- Delete the hand-rolled `COUNT(*) FILTER (... updatedAt >= periodStart)` and the JS
  `periodStart` date math.
- Call the canonical helper (which already has `completedAt` + `isNotNull(scoreAfter)` + UTC
  `date_trunc`).
- Return BOTH canonical numbers: **workCompleted** (the count) and **measuredImpact** (the
  `SUM(lift_achieved)` over `score_after IS NOT NULL` tasks) — plus whatever the UI needs to
  distinguish the pending state (e.g. a `hasMeasuredImpact` boolean, or just measuredImpact===null
  vs a number; make the PENDING case explicit, not a 0).
- Keep session + `setRlsContext` + **`assertBrandAccess`** exactly as they are (S8b-01 — do not
  regress the brand gate).

### Step 3 — Fix the tracker's MEASURED IMPACT rendering (the honesty-critical half)
`action-progress-tracker.tsx` (~217–239):
- The right-hand card must render **MEASURED IMPACT** per the LLD two-state rule (v8.32):
  - **`score_after IS NULL` on all tasks (no re-audit yet)** → **"Validation audit scheduled —
    measured impact pending"** — NOT a zero, NOT a blank, and NOT the citation-rate delta.
  - **Once measured** → the real `SUM(lift_achieved)` (e.g. "Citation rate ↑8%"), including flat /
    negative handled honestly.
- **The citation-rate trend delta is NOT deleted — it is RE-LABELLED and SEPARATED.** §6U.2 says a
  real week-over-week `visibility_trends` delta (with an up/down arrow) is legitimate *as its own
  metric*. Keep it if you want — but it must NOT occupy the "measured impact of your completed work"
  slot. Either (a) drop it from the tracker, or (b) show it as a clearly distinct third element
  labelled as an overall trend (not as the result of the completed work). Do not let the layout imply
  the completed tasks caused it.

### Step 4 — Confirm the current prod state renders correctly after the fix
With `score_after` NULL on every remediation_task (the real state):
- WORK COMPLETED → the real count of `status='complete'` tasks **completed_at** this UTC month.
- MEASURED IMPACT → **"Validation audit scheduled — measured impact pending"**.

## Verify
```bash
grep -n "getProgressSummary\|progress-summary\|completedAt\|updatedAt\|scoreAfter\|liftAchieved\|date_trunc\|setHours" \
  "app/api/brands/[brandId]/action-progress/route.ts" components/**/action-progress-tracker.tsx
```
EXPECT: the route imports the helper; NO `updatedAt`, NO JS `setHours` month math; the tracker renders
the pending copy when there's no measured lift.
**On screen (`/dashboard`):** Work Completed = the real count; Measured Impact = "Validation audit
scheduled — measured impact pending" (NOT a citation-rate % in that slot).

## Constraints
- ONE canonical implementation — the route calls `progress-summary.ts`; do not fork/duplicate the
  query (that duplication IS the root cause).
- Do not regress: session, `setRlsContext`, **`assertBrandAccess`** stay on the route.
- The pending state must be explicit copy, never a `0` or a blank (LLD v8.32).
- The per-fix lift is `lift_achieved` — never the `visibility_trends` delta (over-attribution).
- If `getProgressSummary()`'s shape doesn't fit, EXTEND it (one implementation), don't fork.

## Report back (paste inline)
1. The helper's signature/return shape + how the route now calls it.
2. The route diff: `updatedAt`→`completedAt`, JS-date→UTC `date_trunc`, and measuredImpact now from
   `SUM(lift_achieved) FILTER (score_after IS NOT NULL)`.
3. The tracker's MEASURED IMPACT rendering: the pending copy (and what you did with the citation-rate
   delta — dropped, or re-labelled as a separate overall-trend element).
4. **Screenshot `/dashboard`** showing Work Completed (real count) + "Validation audit scheduled —
   measured impact pending".
5. Confirmation assertBrandAccess/RLS untouched.
