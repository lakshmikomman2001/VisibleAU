# FIX S9-MED-04 (F16) — Discovery page: `Array.isArray` on a WRAPPED envelope → always 0 journeys (+ close the class)

## Severity: MEDIUM — the discovery page silently reports zero journeys for every brand. Third instance of the same bug class (F11 health-check, F15 autopilot, F16 discovery).

## The finding
`app/(auth)/brands/[brandId]/discovery/page.tsx` fetches `/api/brands/{brandId}/journeys`, which
returns **`{ journeys: [...], templates: [...] }`** — an object. The page then does:
```ts
Array.isArray(rawResponse)   // ← an OBJECT is never an array → ALWAYS false
```
…so it falls through to an empty array and renders **0 journeys**, for every brand, always.

**Same signature as F11/F15:** no crash, no 500, no failed test. The page renders a perfectly
plausible "nothing here" state while real data sits unread in the response.

## The real problem (worth naming)
Three files, one class. The root cause is a **systemic inconsistency in route return shapes**:
- some routes return a **bare array** (`[...]`)
- some wrap in a **named envelope** (`{ journeys: [...] }`, `{ audit: {...} }`, `{ brand: {...} }`)
- some wrap with **siblings** (`{ audit, actionItems, priorAudit, engineStats }`)

…and pages *guess* which. `Array.isArray()` fallbacks (used on `/topical-gaps`, `/tasks`, `/drafts`)
were written to tolerate BOTH shapes — which works, but it means a wrapped-object route silently
yields an empty array instead of failing loudly. **The tolerance IS the bug**: it converts a wiring
error into a plausible empty state.

## Task

### 1 — Fix the discovery page
```bash
cd c:/startup/VisibleAU/src
sed -n '1,80p' "app/(auth)/brands/[brandId]/discovery/page.tsx"
grep -n "return NextResponse\|json(" "app/api/brands/[brandId]/journeys/route.ts"
```
Unwrap correctly (defensively, so a missing key → honest empty, not a crash):
```ts
const data = res.ok ? await res.json() : null;
const journeys = data?.journeys ?? [];
const templates = data?.templates ?? [];
```
**Also check the rest of the discovery page** — it may fetch comparisons/other routes with the same
pattern. Check EVERY fetch's envelope against its route (the F15 lesson).

### 2 — Verify on screen
`/brands/{brandId}/discovery` → journeys now render (Metropolitan has S7 discovery data). Compare the
count against the DB:
```bash
psql "$PROD" -c "
  SELECT COUNT(*) FROM conversational_journeys
  WHERE brand_id='418f321f-2489-4560-aaa9-895728580465';"
```
The rendered count must MATCH. (The F11 discipline — a rendering page is not proof of correct data.)

### 3 — Close the class (so a 4th instance can't ship silently)
Two complementary guards — do BOTH:

**(a) A lint/test guard for unwrapped `.json()`:**
Assert no page/component reads `await res.json()` directly into a value whose route returns a wrapped
envelope. Practical implementation: a test that greps `app/(auth)/` + `components/` for
`await *.json()` NOT followed by `?.<key>` or `).<key>`, and cross-checks the called route's return
shape. Where a bare-array route is legitimately read directly, allow it via a documented waiver.
```bash
grep -rn "await .*\.json()" app/\(auth\)/ components/ | grep -viE "\.json\(\)\)\?\.|\.json\(\)\)\." 
```
Every hit must be either (i) a bare-array route, or (ii) fixed.

**(b) The stronger, structural fix — make the shapes CONSISTENT:**
The durable answer is that routes shouldn't be a coin-flip. Either:
- **standardise on the envelope** (`{ data: ... }` or a named key everywhere) and delete the
  `Array.isArray` tolerance, so a mis-read fails loudly; **or**
- at minimum, **document the convention** and make the guard enforce it.
Report which routes return bare arrays vs envelopes (the inventory) so Sri can decide. **Do not
refactor all routes unprompted** — report the inventory + recommend, and fix only discovery in this
prompt.

## Constraints
- Fix discovery; do NOT refactor every route unilaterally (report the inventory instead).
- Defensive unwrap (`?.journeys ?? []`) — missing key → honest empty, not a crash.
- Verify the rendered journey count against the DB (not just "it renders").
- The guard must catch the NEXT instance without editing the test.

## Report back (paste inline)
1. The discovery unwrap diff + every envelope on that page.
2. **Screenshot** `/brands/{metropolitanId}/discovery` — journeys rendering + the DB count → do they
   MATCH?
3. The unwrapped-`.json()` sweep: any remaining hits?
4. **The route shape inventory** — which routes return bare arrays, which wrap, which wrap with
   siblings. + your recommendation on standardising.
5. The guard + its re-break.
