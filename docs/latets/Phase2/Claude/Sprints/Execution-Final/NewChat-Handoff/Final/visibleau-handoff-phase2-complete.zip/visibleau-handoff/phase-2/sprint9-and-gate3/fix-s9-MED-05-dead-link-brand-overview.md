# FIX S9-MED-05 (F19) — "View brand overview" CTA 404s + the dead-link guard MISSED it

## Severity: MEDIUM — a prominent full-width CTA on the sprint's flagship screen leads to a 404. And the guard built to prevent exactly this passed anyway.

## The finding
The Autopilot Loop page (`/brands/{brandId}/autopilot`) renders a full-width gradient CTA:
**"✨ View brand overview →"** → it points at **`/brands/{brandId}/overview`** → **404 · "Couldn't find
that page."**

**Canon check (all three sources):**
- **S9 prompt:** the only "overview" is the **dashboard** `overview/page.tsx` (§6U.6 — persona
  personalisation of the ORG dashboard). No brand-scoped `/overview` route exists in the spec.
- **LLD (S9 regions):** no `/brands/[id]/overview` anywhere.
- **§6U.2 (Autopilot Loop spec):** does **not** ask for a "View brand overview" CTA at all. The only
  CTA canon binds on the loop is the **1-click approve** at step 4 (re-using S2's approve action).

**So this button was invented by the build, points at a non-existent route, and 404s.**

## The likely intent
The brand **detail page** — **`/brands/{brandId}`** (no suffix) — already exists and IS the brand's
overview (the tile grid: Health Check · Autopilot · Workflow · Visibility · Technical Audit · …). The
href almost certainly just has a spurious `/overview` appended.

## ⚠️ SECONDARY FINDING — the dead-link guard FAILED
The F16/F18 work added `dead-link-guard.test.ts` and the report claimed:
> *"the dead-link guard confirms all brand-scoped hrefs resolve"*

**It does not.** This href was live on the autopilot page the entire time and 404s on click. So the
guard is broken in one of these ways — find out which:
- it doesn't scan `components/domain/autopilot/*` (or wherever the CTA lives)
- it doesn't resolve template-literal hrefs like `` `/brands/${brandId}/overview` ``
- its waiver list silently swallowed it
- it only checks hrefs it can statically match, and skipped this one

**A guard that passes while the bug it was built for ships is itself a finding.** Fix the guard, not
just the link — otherwise the next dead link ships the same way.

## Task

### 1 — Fix the CTA
```bash
cd c:/startup/VisibleAU/src
grep -rn "View brand overview\|/overview\|brand overview" \
  components/domain/autopilot/*.tsx "app/(auth)/brands/[brandId]/autopilot/page.tsx" | head
```
Decide (report which you chose):
- **(a) Point it at the brand detail page** → `/brands/${brandId}` — the page that actually exists and
  serves this purpose. **Recommended.** Relabel if needed ("View brand" / "Back to brand").
- **(b) Remove the CTA entirely** — canon doesn't ask for it. Also defensible; the loop already has
  "View full loop" entry points elsewhere and the sidebar/breadcrumb provide navigation.
Do **NOT** create a new `/brands/[brandId]/overview` page to satisfy a link canon never asked for.

### 2 — Fix the DEAD-LINK GUARD (the important half)
```bash
cat tests/**/dead-link-guard.test.ts 2>/dev/null || find . -name "dead-link-guard.test.ts"
```
Diagnose why it missed `/brands/${brandId}/overview`, then fix it so it WOULD have caught it:
- It must scan **all** pages AND components (not just `app/`), including
  `components/domain/**/*.tsx`.
- It must resolve **template-literal hrefs** (`` `/brands/${brandId}/overview` `` →
  `app/(auth)/brands/[brandId]/overview/page.tsx`), not only static strings.
- Its waiver list must be explicit and **documented** — and the stale-waiver check must fire if a
  waiver no longer corresponds to a real link.
- **Re-break proof:** re-introduce the bad href (`/brands/${brandId}/overview`) → the guard must go
  **RED** naming that file and href → revert → green. *If it doesn't go red, the guard is still
  broken.*

### 3 — Sweep for other invented routes
This CTA was invented; there may be others.
```bash
# Every internal brand-scoped href in the app, vs the routes that actually exist:
grep -rnoE "href=\{?\`?/brands/\\$\{[a-zA-Z.]+\}/[a-z-]+" app/ components/ | sort -u
ls "app/(auth)/brands/[brandId]/"
```
Report any href whose target segment has no matching `page.tsx`.

## Verify (on screen)
1. Click the CTA on `/brands/{metropolitanId}/autopilot` → it lands on a **real page** (the brand
   detail page), **not a 404**. Screenshot.
2. The dead-link guard, with the bad href re-introduced → **RED**. Reverted → green. Paste the RED
   output.
3. The sweep → no other invented routes (or report them).

## Constraints
- Do NOT build a `/brands/[brandId]/overview` page — canon doesn't specify one; the brand detail page
  already serves this role.
- Do NOT weaken the guard to make it pass — the guard must genuinely catch this href.
- Don't touch the verified autopilot loop internals (steps, honesty rule, responsive layout).

## Report back (paste inline)
1. What you did with the CTA (repointed to `/brands/{id}`, or removed) + **screenshot** of it landing
   on a real page.
2. **Why the dead-link guard missed it** + the fix + the **re-break RED output**.
3. The sweep: any other hrefs pointing at routes that don't exist?
