# FIX S9-TEST-01 — The F8 guard asserts numbers that don't exist. It is guarding nothing.

## Severity: the F8 regression guard is currently VACUOUS — it can pass while the bug it guards is live.

## The finding
`tests/phase2/sprint9/regression/group-d-honesty.test.tsx` asserts:
```
⚠️ Bondi's overall = 41.67 (3 active dims), NOT 31.25 (4 dims with NULL→0)
```

**Neither number is derivable from Bondi's real data.**

Bondi's actual dimensions (verified in the DB **and** on screen):
| Dim | Value |
|---|---|
| AI Sentiment | **50** |
| AI Presence | **0** |
| Site Readiness | **21** |
| Local Authority | **NULL** |

- **3 active dims (correct):** `(50 + 0 + 21) / 3` = **23.67**
- **4 dims with NULL→0 (the bug):** `(50 + 0 + 21 + 0) / 4` = **17.75**

**The Health Check screen shows `24/100 · Critical`** — i.e. **23.67 rounded.** Confirmed visually.

There is **no arithmetic** on `50 / 0 / 21` that yields **41.67**. (`41.67` would come from something
like `(75+50+0)/3` — a different, synthetic brand.)

## Why this matters
**F8 is the exact finding where "not applicable" (SaaS → hide) gets conflated with "not yet measured"
(non-SaaS NULL → show, exclude from the average).** A guard for that finding, built on fixture data
that doesn't match the case where the bug was actually found, **will not fire when the bug returns.**
It is a false alibi — the thing Section 3 explicitly exists to avoid.

It also violates the standing rule: **real answer-key fixtures, not invented data.**

## Task

### 1 — Find out what fixture it's actually using
```bash
cd c:/startup/VisibleAU/src
grep -n "41.67\|31.25\|Bondi\|sentiment\|presence\|siteReadiness\|localAuthority" \
  tests/phase2/sprint9/regression/group-d-honesty.test.tsx | head -30
```
Report the fixture it feeds in. Two possibilities:
- **Synthetic numbers** (e.g. 75/50/0) → replace with Bondi's real ones.
- **Correct numbers, wrong expected value** → the assertion is simply miscalculated.

Either way it has **never been tested against the real case.**

### 2 — Correct it to Bondi's real answer key
```ts
// Bondi Plumbing — 0f531803-b529-4d09-9fd6-b6272b5baba8 (tradies, non-SaaS)
const bondi = {
  scoreSentimentNumeric: 50,   // → amber
  scoreFrequency:        0,    // → red
  scoreComposite:        21,   // → red   (technical_audits)
  localAiTrustScore:     null, // → UNMEASURED — shown, EXCLUDED from the average
};

// CORRECT (3 active dims):
expect(overall).toBeCloseTo(23.67, 1);   // (50 + 0 + 21) / 3

// THE BUG (4 dims, NULL treated as 0):
expect(overall).not.toBeCloseTo(17.75, 1);   // (50 + 0 + 21 + 0) / 4
```

### 3 — Also verify the Metropolitan fixture
Same file — check the Metropolitan assertions against **its** real answer key:
| Dim | Value | Band |
|---|---|---|
| Sentiment | 100 | green |
| Presence | 5 | red |
| Site Readiness | 37 | red |
| Local Authority | **20** (non-NULL) | red |
| **Overall** | **40.5** → screen shows **41** | amber |

Metropolitan has **4 active dims** (its Local Authority is 20, not NULL): `(100+5+37+20)/4` = **40.5**.
**This is the control** — it proves the average includes *measured* dims and only excludes
*unmeasured* ones. If that assertion is also synthetic, fix it.

### 4 — Re-break-prove
The break-proof must go **RED** against the CORRECTED numbers:
- Make `buildDimensions` include pending dims in the average → Bondi's overall becomes **17.75** →
  the `toBeCloseTo(23.67)` assertion goes **RED**.
- Revert → green.
- **Paste the RED.** If it does not go red with the corrected fixture, the guard is *still* vacuous —
  report that.

### 5 — Sweep the other regression guards for the same problem
This one slipped through. Check whether any other Section 3 guard asserts numbers that aren't in the
answer key:
```
Metropolitan: sentiment 100 · presence 5 · siteReadiness 37 · localAuthority 20 · overall 40.5 (→41)
Bondi:        sentiment 50  · presence 0 · siteReadiness 21 · localAuthority NULL · overall 23.67 (→24)
Bondi's #1 action: "Update local directory listings" (priority 5000)
Metropolitan: no open task · 16 comparisons · 0 journeys
score_after: NULL on EVERY remediation_task system-wide
```
**Any guard asserting a number outside this set is either synthetic or wrong.** Report every hit.

## Constraints
- Real answer-key fixtures ONLY. If a synthetic brand is genuinely needed to test a case the real data
  doesn't cover (e.g. a SaaS brand — neither Metropolitan nor Bondi is SaaS), that's **fine** — but
  **label it explicitly as synthetic** and keep the real-data assertions alongside it.
- Do NOT change `buildDimensions` — the CODE is correct (the screen shows 24, which is right). **Only
  the TEST is wrong.**
- The break-proof must go RED with the corrected numbers.

## Report back (paste inline)
1. What fixture the F8 guard was actually using (synthetic numbers, or a miscalculated expectation?).
2. The corrected assertions (Bondi **23.67** / not **17.75**; Metropolitan **40.5**).
3. **The re-break RED** against the corrected fixture.
4. **The sweep:** any other Section 3 guard asserting numbers outside the answer key.
5. Full suite green (282).
