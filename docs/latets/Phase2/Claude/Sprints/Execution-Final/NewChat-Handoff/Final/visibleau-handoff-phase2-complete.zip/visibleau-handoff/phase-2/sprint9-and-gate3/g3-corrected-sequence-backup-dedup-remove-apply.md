# G-3 CORRECTED SEQUENCE — backup → findings-based dedup → remove phantom writer → re-check → apply 0011

## Context (why the original plan was wrong)
Ground truth proved the keep-rule was **INVERTED**:
- **`findings: {}` rows (composite 83) = PHANTOM** — from `technical-audit-run.ts`, a redundant Inngest
  fn with a hardcoded inflated algorithm.
- **`findings: {...}` rows (composite 37) = REAL** — from `run-technical-audit-inline.ts`, the crawl we
  watched (`composite=37` in the terminal).
- ⚠️ **"Keep highest score" would have deleted every REAL row and kept the phantoms.**

**Discriminator: `findings != '{}'`** — the presence of crawl evidence, NOT the score.

⚠️ **Order matters. Do the steps in sequence. Stop and report if any step's precondition isn't met.**

---

## STEP 1 — BACKUP (non-negotiable, before any write)
```bash
cd c:/startup/VisibleAU/src
pg_dump "postgresql://postgres:password@localhost:5432/visibleau_prod" > prod_backup_pre0011.sql
ls -la prod_backup_pre0011.sql   # confirm non-zero size
```
⚠️ **Do not proceed until the dump exists and is non-empty.** This is the rollback for everything below.

## STEP 2 — Dedup `technical_audits` by FINDINGS (not by score)
**First, preview exactly what will be deleted — do NOT delete yet:**
```bash
psql "$PROD" -c "
  SELECT audit_id, score_composite, created_at,
         CASE WHEN findings::text = '{}' THEN 'PHANTOM (delete)' ELSE 'REAL (keep)' END AS disposition
  FROM technical_audits
  ORDER BY audit_id, created_at;"
```
⚠️ **Sanity-check the preview:**
- Every `audit_id` with 2 rows must show **exactly one REAL + one PHANTOM.**
- ⚠️ **If any audit_id has TWO 'REAL' rows** (both non-empty findings) → **STOP.** The discriminator
  doesn't cleanly separate them; report it — we'd need a tiebreak (latest `created_at`).
- ⚠️ **If any audit_id has TWO 'PHANTOM' rows** (both empty) → **STOP.** Deleting both would leave that
  audit with no technical_audit at all. Report it.
- **Single-row audits** (no dupe) must be untouched.

**Then delete phantoms — keeping at least one row per audit:**
```bash
# Delete empty-findings rows ONLY where a real row exists for the same audit (never orphan an audit):
psql "$PROD" -c "
  DELETE FROM technical_audits t
  WHERE t.findings::text = '{}'
    AND EXISTS (
      SELECT 1 FROM technical_audits r
      WHERE r.audit_id = t.audit_id AND r.findings::text != '{}'
    );"
```
⚠️ **The `EXISTS` clause is a safety net** — it refuses to delete a phantom if it's the *only* row for
that audit. Report the delete count.

**Verify immediately:**
```bash
psql "$PROD" -c "
  SELECT audit_id, COUNT(*) FROM technical_audits
  GROUP BY audit_id HAVING COUNT(*) > 1;"
```
⚠️ **Must return ZERO rows.** If any audit still has 2, report before continuing.

## STEP 3 — Remove the phantom writer (root cause)
`technical-audit-run.ts` duplicates `run-technical-audit-inline.ts` with a worse algorithm. Remove it so
future audits don't recreate phantoms.

**First — confirm it's safe to remove (the dead-reference discipline):**
```bash
# What does technical-audit-run emit? Does ANYTHING listen for it?
grep -n "event\|\.send\|emit" inngest/functions/technical-audit-run.ts
grep -rn "technical-audit/complete\|technical-audit\.complete" inngest/ app/ lib/ --include=*.ts
```
⚠️ **If `technical-audit-run` emits an event that OTHER functions listen for, removing it breaks that
chain.** From Gate 3: `audit-entity-home`, `refresh-entity-score`, `score-agent-readiness` listen for
`technical-audit/complete`. **Which writer emits that event?**
- If the **phantom** (`technical-audit-run`) emits it → those 3 listeners depend on it. **Removing it
  breaks agent-readiness.** ⚠️ **STOP and report** — the real inline function must emit it instead
  first.
- If the **real** (`run-technical-audit-inline`) emits it → safe to remove the phantom. Proceed.

**Then remove it:**
```bash
# 1. Remove from serve()
# 2. Remove the import
# 3. Delete the file
```
- Remove `technicalAuditRun` from the `serve()` array in `app/api/webhooks/inngest/route.ts`.
- Remove its import.
- Delete `inngest/functions/technical-audit-run.ts`.
- ⚠️ **Also remove its trigger** — `audits/route.ts:63` sends `audit.run`; confirm whether that event
  is still needed for `run-audit` (the LLM visibility audit). **`run-audit` also triggers on
  `audit.run` — do NOT remove the `audit.run` send if `run-audit` needs it.** Only remove the
  phantom's *registration*, not the event other functions use. **Report what `audit.run` triggers after
  removal.**

**Update the manifest (serve() count 41 → 40):**
```bash
# Regenerate / edit the manifest so the set-difference guard expects 40, not 41:
# scripts/qa/inngest-serve-manifest.txt  — remove technicalAuditRun
npx vitest run tests/phase2/sprint9/ -t "serve"   # must pass at 40
```
⚠️ **The dangling-import guard must also stay green** — deleting the file + removing the import must
leave no reference behind (the OQ-1 lesson).

## STEP 4 — Re-check BOTH dupe tables on prod (before 0011)
`0011` adds unique indexes to **both** `technical_audits` AND `brand_entity_scores`. Both must be clean.
```bash
# technical_audits — should now be clean after Step 2:
psql "$PROD" -c "
  SELECT audit_id, COUNT(*) FROM technical_audits GROUP BY audit_id HAVING COUNT(*)>1;"

# ⚠️ brand_entity_scores — G-4's confirmed dupe carry. We have NOT verified its keep-rule yet.
psql "$PROD" -c "
  SELECT brand_id, market_code, checked_at, COUNT(*) AS n
  FROM brand_entity_scores
  GROUP BY brand_id, market_code, checked_at
  HAVING COUNT(*) > 1 ORDER BY n DESC;"
```
⚠️ **If `brand_entity_scores` has dupes on `(brand_id, market_code, checked_at)`** → the `0011` unique
index will **FAIL**. **STOP** — we need the same ground-truth treatment we just did for
`technical_audits`: **what distinguishes the dupe rows, and which is real?** Do NOT blindly de-dup it or
force the index. **Report the dupes and what differs between them.**

## STEP 5 — Apply 0011 to prod (ONLY if Step 4 shows BOTH tables clean)
```bash
# Apply the SAME migration dev has:
npx drizzle-kit migrate    # against visibleau_prod  (or the tracked apply path for 0011)
# Confirm the constraints landed:
psql "$PROD" -c "
  SELECT conname, confdeltype FROM pg_constraint
  WHERE conname LIKE '%audit_id%' AND contype='f' ORDER BY conname;"
psql "$PROD" -c "\d technical_audits" | grep -i uniq
psql "$PROD" -c "\d brand_entity_scores" | grep -i uniq
```
⚠️ `citations.audit_id` must be `c` (CASCADE); both unique indexes must exist on prod.

## STEP 6 — Drift check
```bash
<run the dev/prod drift checker>
```
⚠️ **dev == prod?** Both on the same migration state, same constraints, same indexes.

---

## CONSTRAINTS
- ⚠️ **BACKUP FIRST (Step 1).** Nothing destructive before the dump exists.
- ⚠️ **Dedup by `findings != '{}'`, NOT by score.** Score is inverted.
- ⚠️ **The `EXISTS` safety net stays** — never orphan an audit (never delete its only row).
- ⚠️ **Do not remove the phantom writer until confirming it doesn't emit an event others need** (Step 3
  check). If it does → STOP.
- ⚠️ **Do not apply 0011 until BOTH dupe tables are clean** — `brand_entity_scores` is unverified.
- ⚠️ **Do not force a unique index onto dup'd data.**
- Update the serve() manifest to 40; keep the dangling-import guard green.

## REPORT BACK (paste inline)
1. **Backup created?** (size)
2. **Dedup preview** — every dup audit = exactly 1 REAL + 1 PHANTOM? Any exceptions?
3. **Rows deleted** from `technical_audits`; zero dupes after?
4. ⚠️ **Which writer emits `technical-audit/complete`** — phantom or real? Safe to remove the phantom?
5. **Phantom writer removed?** serve() = 40, manifest updated, dangling-import guard green, `audit.run`
   still triggers what it should?
6. ⚠️ **`brand_entity_scores` dupes** — clean, or do they exist? (If they exist: what differs between
   the rows — we ground-truth it before touching.)
7. **0011 applied to prod?** CASCADE + unique indexes confirmed on prod?
8. ⚠️ **Drift checker: dev == prod?**
