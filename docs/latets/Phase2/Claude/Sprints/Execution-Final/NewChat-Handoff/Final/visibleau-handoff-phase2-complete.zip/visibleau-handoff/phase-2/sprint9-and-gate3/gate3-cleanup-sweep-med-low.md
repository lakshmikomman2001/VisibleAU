# GATE 3 CLEANUP SWEEP — the remaining MED/LOW findings (A-4, D-4, F-2, F-3, G-1, G-3, G-4)

These are the non-landmine remainder. **None is behavioural like the F-4/G-2/F-6/F-7 batch** — they're
consistency, dead code, and constraint hygiene. Group the fixes; report each.

⚠️ **One caveat up front:** F-2/F-3 must be re-checked against the **now-fixed drizzle-kit baseline**
(the `0010` snapshot rebuild). Gate 3 found them *before* that fix — the situation may have changed.
**Verify current state before acting.**

---

## A-4 [MED] — dead `technical-audit.complete` dot-emit
Gate 3's A-1 fix removed the dead dot-emit from one path; A-4 is the confirmation sweep.
```bash
cd c:/startup/VisibleAU/src
grep -rn "technical-audit\.complete\|technical-audit/complete" inngest/ app/ lib/ --include=*.ts
```
- ⚠️ **Only the SLASH form (`technical-audit/complete`) should remain**, and only where a listener
  consumes it.
- If any **dot** form survives → remove it.
- Confirm the slash form still has ≥1 real listener (else it's a different dead-emit).
**Report:** every occurrence, dot vs slash, emitter/listener status.

## D-4 [LOW] — tier hierarchy duplicated in ~11 places
```bash
grep -rn "GROWTH_PLUS\|AGENCY_PLUS\|\['growth'\|\"growth\".*\"agency\"\|tier.*>=\|isTierAtLeast" \
  app/ lib/ --include=*.ts | head -30
```
The tier ordering (free < growth < agency) and the "≥ X" logic should live in **ONE** place — the
`assertTier` / `isTierAtLeast` helper. Inline `GROWTH_PLUS = ['growth','agency']` arrays scattered
across routes are the finding.
- **Consolidate** to the single helper. Replace inline arrays with a call.
- ⚠️ **Behaviour must not change** — this is a refactor. Run the D-2/D-3 tier tests after; they must
  stay green.
**Report:** how many sites collapsed into the helper; tier tests still green?

## F-2 / F-3 [MED/LOW] — local-SEO migration + test residue ⚠️ RE-CHECK against the new baseline
Gate 3 found: `0008_brief_luckman.sql` creates `local_seo_results`, and 4 e2e files reference it. **But
drizzle-kit was just fixed and the snapshot rebuilt to a `0010` baseline.** State may have changed.

```bash
# Does ANY migration file still CREATE the deferred table?
grep -rln "local_seo_results\|localSeoResults" db/migrations/
grep -rn "CREATE TABLE.*local_seo" db/migrations/
# Is it in the NEW 0010 baseline snapshot?
grep -rn "local_seo" db/migrations/meta/*.json db/migrations/*0010* 2>/dev/null
# The 4 e2e references:
grep -rn "local_seo_results" tests/
```
⚠️ **Two outcomes:**
- **If `0010` baseline still contains `local_seo_results`** → the deferred table is baked into the
  current baseline. **A fresh `push`/`migrate` recreates it.** Remove it from the baseline (and confirm
  neither live DB has it — it shouldn't per the OQ-1 cleanup).
- **If the baseline is clean** (rebuild already dropped it) → F-2 is **already resolved** by the
  drizzle-kit fix. Just confirm and close.

**F-3 regardless:** remove the 4 dangling `local_seo_results` refs in the e2e helpers/specs
(`tests/e2e/backend/helpers/db.ts`, `sprint2-workflow.spec.ts`, `sprint3-visibility.spec.ts`,
`sprint4-reports.spec.ts`). They'll error against a DB without the table.
**Report:** is the table in the `0010` baseline or not? Do both live DBs lack it? F-3 refs removed?

## G-1 [MED] — audit FK `onDelete` inconsistency
```bash
grep -rn "auditId\|audit_id" db/schema/*.ts | grep -i "references\|onDelete"
```
Audit's children drift across three behaviours:
- `citations`, `action_items`, `technical_audits` → **NO ACTION**
- `audit_cost_snapshots`, `citation_source_intelligence`, `comparison_prompt_results` → **CASCADE**
- `evidence_snapshots`, `generated_reports`, `remediation_tasks` → **SET NULL**

⚠️ **Decide the intended semantics per relationship — don't just unify blindly:**
- Data that is **meaningless without its audit** (citations, technical_audits, comparison results) →
  **CASCADE** (delete with the audit).
- Data that is a **durable record** referencing an audit (reports, remediation tasks, evidence) →
  **SET NULL** (survive, lose the link) — **IF** the FK column is nullable.
- **NO ACTION** on `citations` is almost certainly wrong — deleting an audit would be blocked or orphan
  rows.

**Report the intended behaviour per child table, THEN propose the migration** (do not apply blindly —
changing FK cascade on a table with data needs care). ⚠️ **This is a schema change** — with drizzle-kit
now working, it can go through `generate`. **Show the generated migration; don't hand-write it.**

## G-3 / G-4 [LOW] — missing unique constraints
```bash
# G-3: technical_audits should be one-per-audit
grep -rn "unique\|Unique" db/schema/technical-audits.ts
# G-4: brand_entity_scores duplicate rows (confirmed carry)
grep -rn "unique\|Unique" db/schema/brand-entity-scores.ts
```
- **G-3:** `technical_audits` has no unique constraint on `audit_id`, so a retry/redelivery produces
  silent duplicates. Add `UNIQUE(audit_id)` **if** the one-per-audit invariant holds (confirm no brand
  legitimately has 2).
- **G-4:** `brand_entity_scores` duplicates — consumers already work around via
  `ORDER BY ... DESC LIMIT 1`. Add the missing unique constraint (on whatever the natural key is —
  likely `(brand_id, audit_id)` or `(brand_id, entity_type)`; **confirm from the data**).
- ⚠️ **Both:** check for EXISTING duplicates first — you can't add a unique constraint to a column that
  already has dupes without cleaning them. **Report dupe counts before adding.**
**Report:** dupe counts per table; constraints added (via `generate`); migration shown.

---

## CONSTRAINTS
- **Behaviour-preserving where stated** (D-4 is a pure refactor — tests must stay green).
- ⚠️ **Schema changes (G-1, G-3, G-4) go through `drizzle-kit generate`** now that it works — **show the
  generated migration, don't hand-write raw SQL.** Apply to **both** DBs; confirm tracked.
- ⚠️ **Check for existing duplicates BEFORE adding any unique constraint** — adding one to dup'd data
  fails.
- Do **not** re-add local-SEO or recreate the deferred table (§0.6).
- Group commits sensibly (e.g. one for the emit/refactor cleanup, one for the schema/constraint
  changes).

## REPORT BACK (paste inline)
1. **A-4:** any dot-form emit left? Slash form has a listener?
2. **D-4:** sites consolidated into the helper; tier tests green?
3. ⚠️ **F-2:** is `local_seo_results` in the `0010` baseline or not? (already-resolved, or needs
   removal?) Both live DBs lack it? **F-3** refs removed?
4. **G-1:** intended `onDelete` per child table + the generated migration.
5. **G-3/G-4:** existing dupe counts; constraints added via `generate`.
6. Any of these that turned out to be **already resolved** (esp. F-2) — say so.
