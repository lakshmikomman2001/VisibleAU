# GROUND-TRUTH THE `technical_audits` DUPE — before deleting anything on prod

## Why we're not running the dedup yet
The proposed keep-rule is **"keep the highest `score_composite` per audit_id."** That assumes the
higher-scoring row is the *more complete crawl*. **The data pattern suggests that assumption may be
backwards**, and this is a destructive **prod** delete — so we establish ground truth first.

**The suspicious pattern:**
- Row B is **`composite=37, robots=18`** in **7 of 10** groups — **identical**, across unrelated audits.
- Two *genuine* crawls of the same site seconds apart would vary slightly — not cluster at exactly
  `83/100` vs exactly `37/18`. **Identical recurring values smell like a DEFAULT or SEED, not a crawl
  result.**
- ⚠️ **`37` is the number we have GROUND TRUTH for.** During Audit #20 (`f3cda7f6`) the terminal
  printed: `[tech-audit] Complete for metropolitanplumbing.com.au: composite=37`. And Metropolitan's
  Site Readiness has rendered **37 (red)** all session — the app's answer key. **The product appears to
  already use 37, not 83.**

⚠️ **If `83` is a phantom/stale row and `37` is the real crawl, "keep highest" deletes the REAL data and
keeps the fake.** That's the opposite of the intended fix.

**READ-ONLY. Do not run `_dedup-ta-prod.mjs`. Do not apply 0011. Take no destructive action.**

---

## STEP 1 — Match the rows to Audit #20's KNOWN output
We *watched* `f3cda7f6` crawl 20 pages and report `composite=37`. So for this one audit, truth is known.
```bash
cd c:/startup/VisibleAU/src
# Show BOTH rows for Audit #20 with every column that ties a row to an ACTUAL crawl:
psql "$PROD" -c "
  SELECT audit_id, score_composite, score_robots, created_at, updated_at, *
  FROM technical_audits
  WHERE audit_id='f3cda7f6-bd64-4794-986f-63b639262cb0'
  ORDER BY created_at;"
```
⚠️ **Report the FULL row for each.** Looking specifically for crawl-evidence columns — page count,
crawl-completed timestamp, crawled-URL list, error fields, or a `source`/`status` column. **Which row
corresponds to the crawl we watched?**
- If the **`composite=37`** row is the one with real crawl evidence (20 pages, a completion timestamp
  matching the ~11:15 run) → **37 is REAL, 83 is the phantom.** The keep-rule is **inverted.**
- If the **`composite=83`** row has the real crawl evidence and 37 is the stale one → the original rule
  stands.

## STEP 2 — Is `83/100` a recurring constant (i.e. seed/default)?
```bash
# How often do the EXACT pairs recur across ALL audits/brands?
psql "$PROD" -c "
  SELECT score_composite, score_robots, COUNT(*) AS occurrences
  FROM technical_audits
  GROUP BY score_composite, score_robots
  ORDER BY occurrences DESC
  LIMIT 15;"
```
⚠️ **If `(83,100)` and `(37,18)` each recur many times identically**, they're not independent crawl
outputs — one (or both) is a constant. **A real crawl of different states of a site over 19 audits
should produce VARIED scores.** Report the distribution.

## STEP 3 — Which value does the APP actually read?
The UI shows Metropolitan Site Readiness = **37**. Confirm which row the product surfaces.
```bash
# How does the app SELECT a technical_audit for a brand/audit? Find the query:
grep -rn "technical_audits\|technicalAudits" lib/ app/ --include=*.ts | grep -iE "select|from|orderBy|limit" | head
```
⚠️ **If the app already selects the `37` row** (e.g. `ORDER BY created_at DESC LIMIT 1`, and 37 is
latest) — then **the 83 rows are already orphaned garbage the product ignores.** Deleting 37 would
change what users see; deleting 83 would change nothing. **This tells us the safe direction.**

## STEP 4 — Trace WHERE the phantom row comes from
If Step 1/2 confirm 83 is not a real crawl, the dedup is a band-aid — **the writer is producing a
phantom row every audit.**
```bash
grep -rn "technical_audits" inngest/ lib/ --include=*.ts | grep -iE "insert|values"
cat inngest/functions/technical-audit-run.ts | head -60
```
⚠️ **Is `technical_audits` written in TWO places?** (One real crawl result + one default/placeholder
insert?) **Report both write sites.** The real fix is stopping the phantom write — dedup only cleans
what already leaked.

---

## THE VERDICT — which row is real?
| Finding | Keep-rule | Then |
|---|---|---|
| **37 = real crawl (has crawl evidence, matches terminal), 83 = phantom/seed** | ⚠️ **Keep 37, delete 83** — the OPPOSITE of the original proposal | + fix the phantom writer (Step 4) |
| **83 = real crawl, 37 = stale** | Keep 83 (original rule) | proceed |
| **Both are real, differ legitimately** | Neither — need a different key | reconsider the unique constraint |

## CONSTRAINTS
- **READ-ONLY.** No deletes, no dedup script, no 0011, until the verdict is clear and Sri signs off.
- ⚠️ **Do not assume "higher score = better."** That is the hypothesis under test, not a given.
- Before ANY eventual delete: `pg_dump visibleau_prod > prod_backup_pre0011.sql` (note it, don't act
  yet).

## REPORT BACK (paste inline)
1. ⚠️ **The two full rows for Audit #20** — which one has real crawl evidence (20 pages, completion
   time matching the run)? **Is it the 37 or the 83?**
2. **The score-pair distribution** (Step 2) — do `(83,100)`/`(37,18)` recur as constants?
3. **Which row does the APP read?** (Step 3)
4. **How many places write `technical_audits`?** (Step 4) — is there a phantom writer?
5. ⚠️ **THE VERDICT:** is the keep-rule "highest score" correct, or **inverted**?
