# S8 — FINAL §12 QA PASS (sprint-close gate)

Run the full governance invariants script as the closing gate for Sprint 8 — the standalone
end-of-sprint QA pass (after all 5 test-track sections). The script already exists and was built in
§3; this is the final run-through to confirm every invariant is green at sprint close, in the
usual sequence.

## Run it
```bash
cd c:/startup/VisibleAU/src
bash scripts/qa/sprint8-invariants.sh
```

## Also confirm the full test suite is green alongside the QA script
(so the sprint-close state is: all 5 sections + QA, together)
```bash
# All governance tests across the 5 sections in one run:
npx vitest run tests/unit/governance/ tests/integration/governance/ 2>&1 | tail -8
# The E2E section (Playwright) — if quick enough to include; otherwise note last-known 13/13:
npx playwright test tests/e2e/sprint8/ 2>&1 | tail -8
```

## What "done" looks like
- `sprint8-invariants.sh` → **22/22 PASS** (nav set-difference, 44/44 assertBrandAccess, migration
  idempotency, serve() registration, /api/auth/me, OQ-1 absent, etc.).
- Governance unit+integration → green (110 + 62).
- E2E → 13/13 (or last-known-green noted).

## If anything is NOT green
Report which check/test failed. A QA check that flips red at sprint close usually means a later fix
or revert left something inconsistent — report it, don't force it green.

## Report back (paste inline)
1. The `sprint8-invariants.sh` output (the 22-check summary + PASS/FAIL total).
2. The governance unit+integration run count (green?).
3. E2E status (13/13 or noted).
4. Any red — which check/test, and what it points to.
