# QUERY — MISS FOX fixture: real ABN + vertical (read-only)

The MISS FOX brand was added to the Growth org on `visibleau_prod` during the fixture build. Pull
the two values that never got reported inline: the real ABN (fetched via the live ABN Lookup) and
the vertical enum it mapped to.

```bash
cd c:/startup/VisibleAU/src
# The brand row — vertical + org:
psql "$PROD" -c "
  SELECT b.name, b.domain, b.vertical, b.organization_id, s.tier
  FROM brands b
  JOIN subscriptions s ON s.organization_id = b.organization_id
  WHERE b.domain = 'missfox.com.au';"

# The ABN fields on the brand-entity record (from the live lookup):
psql "$PROD" -c "
  SELECT abn_number, abn_entity_name, abn_status, abn_verified
  FROM brand_entity_scores
  WHERE brand_id = (SELECT id FROM brands WHERE domain = 'missfox.com.au');"
```

## What we're confirming
1. **ABN** — is `abn_number` a real, populated value (not null, not a placeholder)? What entity name
   + status did the live lookup return? (This closes the "did it invent the ABN or fetch it live?"
   question — the fixture prompt required live-fetch, not invention.)
2. **Vertical** — which enum did MISS FOX (a beauty/day-spa) map to? (The open question was whether a
   beauty/wellness vertical existed, or whether it force-fit `tradies` / fell back to something. If
   it's `tradies`, that's a note — the mapping was wrong; if it's a sensible beauty/health/services
   enum, the fixture built cleanly.)

## Report back (paste inline)
1. The brand row (name/domain/vertical/tier).
2. The ABN fields (number/entity name/status) — real value or null/placeholder?
