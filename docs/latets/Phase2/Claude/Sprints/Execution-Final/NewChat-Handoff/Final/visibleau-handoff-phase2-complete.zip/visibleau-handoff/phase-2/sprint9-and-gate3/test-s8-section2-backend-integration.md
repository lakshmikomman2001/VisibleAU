# TEST TRACK S8 — SECTION 2: BACKEND INTEGRATION (DB writes · event chains · RLS · provisioning)

## Scope
The big S8 section: governance is mostly I/O, so this is where the CRITICAL/HIGH findings become
permanent guards (F2 residency writer, F6 owner-seed, F19 webhook dedup, HIGH-12 viewer-RBAC, the
recordAction-at-9-sites Priority-2, RLS cross-org 404). Canon hands us the exact test list —
**S8 prompt §11** — so this section asserts what the sprint ITSELF mandates. Build it, prove each
re-breaks, then section 3 (Walk regression guards).

## Test DB discipline (READ THIS FIRST)
- Run against a **dedicated test DB** (or a transaction rolled back per test) — **NOT
  `visibleau_prod`**. `LLM_MODE=mock` per §11 (no real LLM spend; the event CHAIN is what we test,
  not model output).
- Each test seeds its own org/members/brands in a transaction and rolls back (or truncates the
  governance tables between tests). No cross-test state leakage. Confirm which harness the repo
  already uses (below) and match it.
- setRlsContext must be exercised the way the routes use it (tests that bypass RLS prove nothing
  about the RLS guarantees).

## STEP 0 — Inventory first (per-section; do NOT skip)
Several §11 files may already exist from the sprint build. List them, classify behavioral vs hollow
(a route test that 200s but never asserts the ROW landed is hollow; the S7 CPR-01 class), so we
EXTEND/UPGRADE rather than duplicate.
```bash
cd c:/startup/VisibleAU/src
ls tests/**/*.test.ts 2>/dev/null | grep -iE "access-control|privilege-audit|audit-trail|webhook|org-member|invite|feature-flag|data-residency|fanout|residency|assertBrandAccess|provision"
grep -Rln "recordAction\|assertBrandAccess\|recordDataResidency\|setRlsContext\|internal_event_id\|view_audit_trail\|EVENT_NAME_MAP\|afterCreateOrganization\|invitation_token" tests/ 2>/dev/null | sort -u
# The DB test harness pattern (transaction rollback? test container? truncate?):
grep -Rln "beginTransaction\|ROLLBACK\|truncate\|pg-mem\|testcontainers\|withRlsContext\|createTestOrg\|seedOrg" tests/ 2>/dev/null | head
```
Report each existing §11 file + behavioral/hollow verdict BEFORE writing. Write only missing/weak.

## The §11 integration targets + the CANON assertions

### 2.1 — `access-control.test.ts` — the 3-layer model + brand isolation (S8b-01, S8b-02)
- **3-layer order:** session → users.role → org_members.role (the resolution order §6.2). Assert a
  member whose org_members role differs from users.role resolves per the documented precedence.
- **RBAC matrix at the DB layer** (section 1 proved the pure predicate; here prove the resolved
  role from `org_members` drives it): analyst runs audits but can't approve drafts; viewer
  read-only; only owner deletes a brand.
- **S8b-01 (the security one):** a brand ROUTE actually INVOKES `assertBrandAccess` — a member with
  `brand_access=[A]` gets **404 on brand B** (not just that the predicate is right). Pick a real
  brand-scoped route; call it as that member; assert 404. `brand_access=null` → all brands allowed.
  (This is the assertBrandAccess integration deferred from section 1.)
- **S8b-02:** an admin PATCHing a member to `role=owner` is **rejected (403)**; only an owner
  succeeds; no actor elevates a member above their own role. Route-level, not just predicate.

### 2.2 — `audit-trail.test.ts` — recordAction writes at ALL 9 sites (Priority 2, the DB half)
Canon §11: "assert recordAction is INVOKED at each of the sites — not merely that the function
handles the action values, so a missing call site is caught." This is the guard for the whole class
of F2/F6 "writer built but never called" bugs.
- **The write itself:** recordAction inserts a row with correct `action`, `resource_type`,
  **non-null `organization_id`**, `user_id` (or null for system), metadata. Assert a system action
  (null user_id) is allowed.
- **The 9 call sites INVOKE it** (the important part — a spy/mock on recordAction, then exercise
  each route/path, assert the spy was called with the right action/resource_type):
  S8's own: `data_residency_accessed` (GET data-residency), `feature_flag_changed` (flag path),
  `member_role_changed` (PATCH members), `member_removed` (DELETE members).
  Upstream edits: `draft_approved` + `draft_dismissed` (S4 draft route), `journey_triggered` (S7
  journeys/run), `hallucination_acknowledged` (S5 acknowledge), `competitive_benchmark_viewed` (S3
  benchmark GET). A site that doesn't call recordAction = the exact silent-miss §11 warns about →
  test RED.
- **The S7 orgId guard:** assert no call site passes `orgId` where recordAction expects
  `organizationId` (the null-org 23502 class) — a row with null organization_id must be impossible.

### 2.3 — `privilege-audit.test.ts` — S8b-03
A role change emits `member_role_changed`; a member removal/deactivation emits `member_removed`
(resource_type `org_member`) to audit_trail, WITH the change in metadata (old→new role / who).
Assert both land with correct action + resource_type + metadata.

### 2.4 — HIGH-12 behavioral: viewer DENIED on the audit-trail ROUTE
Section 1 froze the predicate; here prove the ROUTE enforces it end-to-end.
- A **viewer** calling `GET /api/organizations/[id]/audit-trail` → **403** (not 200).
- owner/admin/analyst → **200** with rows.
- This needs a viewer member seeded in the test org (fine in a test DB — the thing we couldn't do
  on prod without mutating it). This is the guard that would have caught the shipped HIGH.

### 2.5 — RLS cross-org → 404 on all 4 governance tables
For audit-trail, members, data-residency, feature-flags: a caller who is NOT a member of `[id]`
(or a different org's member) → **404** (existence-hiding), not 403/200, and RLS prevents reading
another org's rows even if the guard were bypassed. Assert per table.

### 2.6 — `org-members-invite.test.ts` — IC-01 lifecycle
- invite → row with `accepted_at` NULL, `is_active` false, `invitation_token` nanoid(21).
- accept(token) → `accepted_at`=now, `is_active`=true, token cleared (single-use — a second accept
  with the same token fails).
- cancel(DELETE) → deletes ONLY unaccepted rows (`accepted_at IS NULL`); an ACCEPTED member is NOT
  deleted via cancel (→ is_active=false path instead). This is the IC-01 footgun (§581).
- `UNIQUE(org, user)` enforced — a duplicate invite for the same user fails.

### 2.7 — `data-residency.test.ts` — the DR-01 declarative writer (F2)
Canon: `record-data-residency.ts` UPSERTs the STATIC map (declarative, not per-event — one row per
data_type per org, identical for every org).
- Calling the writer produces the canonical rows (data_types: audit_data, evidence_snapshots,
  pdf_reports, llm_cache, crawler_logs + the LLM-processing provider rows — assert the full set the
  writer emits; the live prod check showed **7 rows/org**).
- **Idempotent:** running it twice = no duplicate rows (`UNIQUE(org, data_type)` / ON CONFLICT).
- **retention_period values mirror the cleanup windows** (DR-02): audit_data/evidence/pdf='12
  months', llm_cache='30 days', crawler_logs='90 days' — assert these exact values (they must stay
  in sync with audit-data-retention.ts).

### 2.8 — Provisioning side-effects (F6 owner-seed + F2 writer wired)
The class of bug that shipped 5+ times (writer built, never called). Assert on `afterCreateOrganization`
(or the provisioning path):
- an **owner `org_members` row** is seeded for the creator (F6 — brand_access null, role owner).
- the **residency writer runs** → the org gets its residency rows (F2 — the writer is actually
  CALLED at provisioning, not just defined). This is the integration guard that would have caught
  both F2 and F6.

### 2.9 — `webhook-emit-sources.test.ts` + `fanout-webhooks.test.ts` — WH-01 + F19
- **Emit sources (S8-01, the 2 added emits):** acknowledging a hallucination (is_acknowledged=true
  on the acknowledge route) emits `hallucination/acknowledged`; a visibility_trends UPSERT emits
  `visibility/trend-updated` — each with `{ organizationId }`. (These were the not-built-upstream
  emits; assert they fire at source.)
- **Fanout mapping:** each of the 5 Phase 2 internal (slash) events maps to the correct external
  (dot) event via EVENT_NAME_MAP; a subscribed endpoint receives a delivery per event.
- **F19 dedup by event INSTANCE (the fix):** fire event instance A → 1 delivery; **retry A (same
  internal_event_id) → still 1 (no double-POST)**; **fire a NEW instance B of the SAME type →
  a NEW delivery (NOT deduped)**. This is the exact F19 regression case — the dedup must key on
  `endpointId + internal_event_id`, not event type.

### 2.10 — `feature-flags.test.ts`
Priority: `org_feature_flags` > env > default. An org override beats a false env flag. Flags are
operator-set — assert there is NO user-facing API write path (the GET is read-only).

## Test conventions
- Match the repo's existing DB-integration harness (Step 0) — transaction-rollback or truncate per
  test; do NOT invent a new one. `LLM_MODE=mock`.
- Spy/mock `recordAction` for the 9-call-site invocation checks (2.2); assert it was CALLED with the
  right args — the point is catching a MISSING call, which only an invocation spy does.
- Seed roles (owner/admin/analyst/viewer) in-test for the RBAC/route assertions (2.1/2.4/2.5).
- Assert canon values (retention strings, the dedup instance behavior, the 404s), not impl mirrors.
- No real LLM/webhook egress — mock the outbound POST; assert the `webhook_deliveries` ROW + the
  dedup behavior, not a live HTTP round-trip.

## RE-BREAK PROOF (required before section 3)
Prove the highest-value guards bite — break each, confirm RED, revert:
1. Comment out the recordAction call in ONE upstream route (e.g. the acknowledge route) → 2.2's
   invocation test for that site must FAIL. Revert.
2. Set the audit-trail route back to `view_reports` → 2.4 (viewer-denied) must FAIL (viewer gets
   200). Revert.
3. Re-key the fanout dedup to event TYPE (drop internal_event_id) → 2.9's "new instance B same type
   delivers" must FAIL (B gets deduped). Revert.
4. Skip the owner-seed in provisioning → 2.8's owner-row test must FAIL. Revert.
5. Make the residency writer non-idempotent (plain INSERT) → 2.7's re-run test must FAIL (dup rows).
   Revert.
Report the 5 REDs + green-after-revert.

## Constraints
- Test DB / rolled-back txns only — NEVER `visibleau_prod`. `LLM_MODE=mock`.
- INVENTORY first (Step 0) — extend/upgrade, don't duplicate the §11 files that exist.
- The 9-site check must be an INVOCATION assertion (spy), not "the function handles the value".
- Assert canon (§11 + the DDL/retention values), not implementation mirrors.
- Mock outbound webhook POST; assert the delivery ROW + dedup, not live egress.
- If any test reveals a real defect (a site not wired, a 404 that's a 403, a non-idempotent writer),
  REPORT it as a finding — do not fix inside this test prompt; it gets a scoped fix.

## Report back (paste inline)
1. Step 0 inventory: existing §11 files + behavioral/hollow verdict; the DB harness used.
2. Written (new) vs extended/upgraded (existing) — file list, per §11 target 2.1–2.10.
3. Test run: all green (count).
4. Any real defects surfaced (findings) — esp. a recordAction site not actually wired, a
   cross-org route returning 403 not 404, or a non-idempotent writer.
5. RE-BREAK: the 5 REDs + green-after-revert (proof they bite).
