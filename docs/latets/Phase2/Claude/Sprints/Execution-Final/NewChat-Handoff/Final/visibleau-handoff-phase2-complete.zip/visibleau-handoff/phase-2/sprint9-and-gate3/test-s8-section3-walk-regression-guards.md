# TEST TRACK S8 — SECTION 3: WALK REGRESSION GUARDS (one guard per finding; recurrence-killers)

## Scope & the core principle
Section 3 is the guards that stop this sprint's findings — and the recurring CLASSES — from
shipping again. The critical framing: **the §12 QA greps are the ones that reported "all pass"
while 15 findings shipped.** They assert PRESENCE (`grep -c "recordAction" ≥1`, `setRlsContext ≥1`)
not CORRECTNESS — which is exactly how HIGH-12 (setRlsContext present, but viewer not excluded) and
F2/F6 (writer present, never called) slipped through. So every guard here must be BEHAVIORAL or
STRUCTURALLY-SPECIFIC where the grep was a weak presence-check. Sections 1–2 already cover the
in-code behavior; section 3 adds the CROSS-CUTTING + RECURRENCE + INFRASTRUCTURE guards that no §11
test owns. Build it, re-break each, then section 4.

## STEP 0 — Inventory (per-section)
```bash
cd c:/startup/VisibleAU/src
ls scripts/qa/ 2>/dev/null; test -f scripts/qa/sprint8-invariants.sh && echo "QA SCRIPT EXISTS"
# The existing nav guard (added during F3) — is it behavioral or a presence grep?
grep -Rln "nav\|sidebar\|ACCOUNT_ITEMS\|settings.*nav\|reachable\|orphan" scripts/qa/ tests/ 2>/dev/null | sort -u
grep -Rln "IF NOT EXISTS\|DROP POLICY\|migration.*idempoten\|CREATE POLICY" tests/ scripts/ 2>/dev/null | sort -u
# What does the current §12 script assert (so we UPGRADE the weak greps, not duplicate)?
test -f scripts/qa/sprint8-invariants.sh && sed -n '1,140p' scripts/qa/sprint8-invariants.sh
```
Report: does the F3 nav guard exist + is it behavioral? does a migration-idempotency guard exist?
what does the QA script currently assert (presence vs correctness per line)?

## The guards (one per finding / recurring class)

### 3.1 — NAV-ORPHAN guard (F3) — THE RECURRENCE-KILLER (this class shipped S5→S8, 4 sprints)
Every settings/governance screen that exists must be REACHABLE from the sidebar `ACCOUNT` section.
The bug each sprint: a screen is built + routed but absent from the sidebar nav (URL-only). A
presence grep won't catch it. The guard must assert **completeness**: for every route under
`app/(auth)/settings/*`, there is a corresponding sidebar entry.
- Enumerate the settings routes (the `page.tsx` dirs under settings) and the sidebar's ACCOUNT
  items (from `app-sidebar.tsx` / wherever ACCOUNT_ITEMS is defined).
- Assert **every settings route has a nav entry** (set-difference = empty). Team, Audit Trail, Data
  residency, Webhooks, View plans — plus any future one automatically (that's the point: it catches
  the NEXT orphan without editing the test).
- Behavioral, not `grep -c "Team" ≥1`: it must FAIL if a new settings route is added without a nav
  entry. (Re-break: add a throwaway `settings/_orphan_test/page.tsx` → guard FAILS → remove it.)
- If a canonical nav order exists (Team→Audit Trail→Data residency→Webhooks→View plans), assert the
  order too (this was part of the F3 fix).

### 3.2 — MIGRATION IDEMPOTENCY guard (F1 CRITICAL class / MI-01)
F1 (governance migration not on prod → 44-route outage) + MI-01 (LLD 1711): the migration mixes
idempotent (`ADD COLUMN IF NOT EXISTS` ×32) and NON-idempotent (`CREATE TABLE`, `CREATE INDEX`,
`CREATE POLICY`) statements — a re-run/partial-replay crashes at the first non-idempotent one.
- Guard: scan the S8 governance migration file(s); assert `CREATE TABLE` → `IF NOT EXISTS`,
  `CREATE INDEX` → `IF NOT EXISTS`, `CREATE POLICY` → preceded by `DROP POLICY IF EXISTS` (the
  Supabase-PG idempotent idiom; PG has no `CREATE POLICY IF NOT EXISTS`).
- Assert NO bare `CREATE TABLE `/`CREATE INDEX `/`CREATE POLICY ` without the idempotent guard.
- (This guards the manual-replay path — the "apply to both DBs" discipline; a partial deploy must be
  re-runnable, which is what would have de-risked the F1 outage.)
- Re-break: strip `IF NOT EXISTS` from one CREATE TABLE → guard FAILS → revert.

### 3.3 — `/api/auth/me` contract guard (F7)
F7: the route was never built → 3 governance pages 404'd. Guard the CONTRACT, not just existence:
- Assert the route module exists AND, via the section-2 harness, returns 200 with the expected
  shape for an authed user: `{ id, organizationId, tier, role, ... }` (the fields the governance
  pages consume). tier sourced from subscriptions.tier; role mapped (member→analyst).
- Behavioral: hitting it authed returns the shape; unauthed → 401. (Re-break: rename the route file
  → the governance pages' contract test / this guard FAILS.)

### 3.4 — PROVIDER display-name guard (F13) + no-hex-alpha (§13)
- F13: assert the `PROVIDER_DISPLAY` map has no naive-capitalized value — specifically
  `openai→"OpenAI"` (NOT "Openai"), and all 6 providers map to canon strings. (Section 1 covers the
  map; this is the cross-cut "no CSS `capitalize` on provider cells" — assert the residency table
  doesn't reapply `capitalize` to the provider column.)
- §13 no-hex-alpha: assert `grep -REc "var\(--[a-z-]+\)[0-9a-fA-F]{2}"` on governance components = 0
  (a CSS var immediately followed by 2 hex chars = the invisible-color bug class). This one is a
  legit structural grep (it catches a real defect shape). Keep it.

### 3.5 — S8-01 the two ADDED emits exist AT SOURCE (§13 anti-pattern)
Section 2 tests they FIRE; this guard is the cheap structural backstop that they're wired at the
producer (the §12 greps for these are fine — they assert source presence, which is the right shape
here):
- `visibility/trend-updated` emitted in `aggregate-visibility-trend.ts`;
  `hallucination/acknowledged` emitted in the acknowledge route. Assert both present at source AND
  (stronger, from §2) that fanout maps them. Keep the source grep as the fast guard; the behavioral
  fire-test lives in §2.

### 3.6 — OQ-1: no invented `local_seo_results` table (§13)
Assert `db/schema/local-seo-results.ts` does NOT exist (the sprint explicitly must NOT build it —
S6's local_ai_trust_score stays NULL pending Sri). `test ! -e` → guard. (Re-break: touch the file →
guard FAILS → remove.)

### 3.7 — S8b-01 brand-access RETROFIT coverage (the tenant-isolation recurrence, §13 + S9 note)
The most security-critical recurrence: `assertBrandAccess` must be adopted by the S1–S7
`/api/brands/[id]/…` routes (a backward retrofit), or brand_access is inert. Section 2 proves the
predicate + one route 404s; this guard asserts **breadth of adoption**:
- Enumerate the `/api/brands/[id]/…` routes that read brand-scoped data; assert each INVOKES
  `assertBrandAccess` (or the shared guard). A route that reads brand data without it = the inert-
  isolation gap (a member restricted to brand A reaches brand B). The §12 grep only checks "≥1 route
  adopts it" — upgrade to "every brand-data route adopts it" (set-difference = empty), or at minimum
  enumerate + report the routes MISSING it as a finding.
- (This is the S9-forward guard: the LLD note says "S9 must not re-introduce the un-enforced path".)

### 3.8 — Upgrade the §12 QA script (`scripts/qa/sprint8-invariants.sh`)
Rewrite the weak presence-greps into what the walk actually proved, and assert the sprint's N
functions are PRESENT in `serve()` (the Inngest registration at
`app/api/webhooks/inngest/route.ts`) — NOT a running total that drifts:
- The recordAction 5-upstream-site greps: keep, but note §2 is the real invocation guard.
- `setRlsContext ≥1` on audit-trail → this is the grep that MISSED HIGH-12; add alongside it a
  note/pointer that the behavioral viewer-403 guard is §2 (the grep alone is insufficient).
- The `serve()` registration: assert the S8 Inngest functions (fanout-webhooks,
  audit-data-retention, the residency/provisioning hooks if registered there) appear in the
  `serve({ functions: [...] })` array — a function defined but not registered never runs (the F2/F6
  class at the Inngest layer).
- Add the 3.1 nav-completeness + 3.2 migration-idempotency as script checks too (so the QA script
  catches the recurrence classes, not just the in-code greps).
Report the before/after of the QA script: which checks were weak presence-greps and are now
behavioral/specific.

## Test conventions
- Prefer behavioral/set-difference guards over presence greps wherever the grep could pass while
  broken (3.1, 3.3, 3.7). Keep structural greps only where the defect IS a source shape (3.4 hex-
  alpha, 3.5 emit-at-source, 3.6 file-absence).
- The route-contract guards (3.3) reuse the section-2 harness (test DB / mock).
- Match the repo's existing test + QA-script conventions; don't introduce a new framework.

## RE-BREAK PROOF (before section 4)
1. Add `app/(auth)/settings/_orphan_test/page.tsx` with no nav entry → 3.1 FAILS. Remove.
2. Strip `IF NOT EXISTS` from a `CREATE TABLE` in the migration → 3.2 FAILS. Revert.
3. Rename the `/api/auth/me` route file → 3.3 FAILS. Revert.
4. Set `PROVIDER_DISPLAY.openai` → "Openai" → 3.4 FAILS. Revert.
5. `touch db/schema/local-seo-results.ts` → 3.6 FAILS. Remove.
6. Remove `assertBrandAccess` from one brand-data route → 3.7 FAILS (or reports it missing). Revert.
Report the 6 REDs + green-after-revert.

## Constraints
- Behavioral/specific over presence-grep where a grep could pass-while-broken (that's the whole
  point of this section — the §12 greps passed while 15 findings shipped).
- Do NOT duplicate §2's behavioral tests (viewer-403, dedup, recordAction-invocation) — reference
  them; §3 adds the cross-cutting/recurrence/infra guards §2 doesn't own.
- The nav guard (3.1) must catch the NEXT orphan automatically (set-difference), not hard-code the
  current 5 items.
- If 3.7 reveals brand-data routes MISSING assertBrandAccess, REPORT as a finding (tenant-isolation
  gap) — do not fix inside this test prompt.
- Test/script-only changes (+ reverted re-breaks).

## Report back (paste inline)
1. Step 0: does the F3 nav guard / migration guard already exist + behavioral? current QA-script state.
2. Written vs extended — the guard files/checks, per 3.1–3.8.
3. The QA-script before/after (weak greps → behavioral/specific).
4. Any finding surfaced — esp. 3.7 (a brand-data route missing assertBrandAccess = tenant-isolation
   gap) or a §serve() function defined-but-not-registered.
5. RE-BREAK: the 6 REDs + green-after-revert.
