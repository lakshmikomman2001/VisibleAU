# TEST TRACK S8 — SECTION 4: FRONTEND UNIT (component render tests, every state)

## Scope
Component-level render tests for the S8 governance UI — every canonical STATE (loading / empty /
data / error / permission-denied / responsive), asserting the prompt §6U specs + the prototype's
exact styling. The build shipped ZERO frontend unit tests (same gap as S7), so this is almost
entirely net-new. Several findings become permanent component guards here: F8 (Joined col), F11
(brand_access picker), F12 (seat block), F13 (provider names), F21 (metadata expand), and the
TierGate half of F18. Build it, re-break each, then section 5 (E2E).

## STEP 0 — Inventory + detect the frontend test setup
```bash
cd c:/startup/VisibleAU/src
# What frontend test runner + render lib does the repo use? (RTL? vitest+jsdom? testing-library?)
grep -RlE "@testing-library/react|render\(|screen\.|jsdom|happy-dom" tests/ 2>/dev/null | head
cat vitest.config.* 2>/dev/null | grep -iE "environment|jsdom|happy-dom|setupFiles"
# Any existing component tests for these? (avoid duplicating)
ls components/domain/governance/ 2>/dev/null
grep -RlE "member-row|role-badge|invite-form|audit-log-row|residency-table|TierGate|tier-gate" tests/ 2>/dev/null | sort -u
```
Report the runner/render-lib + any existing component tests (behavioral vs snapshot-only — a bare
snapshot that re-baselines on change is NOT a behavioral guard; note those). If NO jsdom/happy-dom
environment is configured, report that (frontend unit tests need a DOM env) — I'll add a setup step
before the tests if needed.

## The components + canon assertions (prompt §6U + prototype)

### 4.1 — `role-badge.tsx` — the color mapping (prototype 2905 region + §6U.2)
Canon mapping: **owner = governance, admin = blue, analyst = workflow, viewer = secondary** (the
semantic token per role). Render each role; assert:
- The correct label text (Owner/Admin/Analyst/Viewer).
- The correct semantic token/class per role (owner→governance token, admin→blue, analyst→workflow,
  viewer→secondary) — assert the class/style hook, not a raw hex. This is where a role could render
  with the wrong color (a real bug shape).
- An unknown role degrades gracefully (a default badge, no crash).

### 4.2 — `member-row.tsx` — all fields (§6U.2, F8)
Render a member; assert all 5 columns present: **name / email / role-badge / brand-access / Joined**
(F8 — the Joined column was missing; freeze it). Assert:
- name + email render; role-badge present; brand-access shows "All brands" for null and the
  specific brand names for a scoped array.
- **Joined** renders a formatted date (F8).
- **Actions** column: present + interactive for owner/admin; **hidden/disabled for analyst/viewer**
  (the permission-denied state — pass a `canManage=false`/viewer prop, assert no role-change/remove
  controls).
- "you" indicator on the current user's own row.
- RESPONSIVE: the row reflows to a stacked card on `<md` (assert the responsive class/structure).

### 4.3 — `invite-form.tsx` — email + role + brand_access picker + seat states (§6U.2, F11, F12)
- Renders **3 controls: email + role select + brand_access picker** (F11 — the picker was missing;
  freeze it). The brand_access picker offers All-brands vs Specific-brands.
- **Seat-limit state (F12):** when `accepted+pending >= seatLimit`, the form is replaced by the
  seat-limit block ("Seat limit reached (5/5) · Upgrade") with a billing link — assert the form
  inputs are NOT rendered in that state, and the upgrade link is.
- **Permission-denied:** for analyst/viewer, the invite form is not shown (or disabled) — assert.
- RESPONSIVE: single-column on `<md`.

### 4.4 — `audit-log-row.tsx` — the F21 metadata expand (the exact component we render-proofed)
Freeze F21 as a unit test (companion to the E2E render-proof):
- **metadata present** → a "Details" expand control renders; clicking toggles `aria-expanded`
  false→true and reveals a `<dl>` with the key/value (e.g. `brandId: 418f321f…` truncated).
- **metadata null/empty** → NO expand control; row stays compact (the negative case — this is what
  the `hasMetadata` guard protects).
- action label + resource_type badge + actor ("by X" for a user, "system" when user_id null) +
  timestamp with tabular-nums. Assert the **system** case (null user_id → "system", not "by null").
- RESPONSIVE: row reflows to a card on `<md`, metadata expands inline.

### 4.5 — `residency-table.tsx` — provider names + null handling (§6U.4, F13)
- Renders the residency rows; **provider names via PROVIDER_DISPLAY** — assert `openai`→"OpenAI"
  (NOT "Openai"), and no CSS `capitalize` on the provider column (F13). Region via REGION_LABELS
  (`ap-southeast-2`→"Australia (Sydney)").
- **null retention** handled gracefully (a row with null retention renders without "undefined" /
  crash) — the null-handling the live screen showed.
- The primary-region banner renders.

### 4.6 — `tier-gate.tsx` (TierGate) — the locked overlay (F18 component half; prototype 700–738)
Section 5 does the full Agency-vs-Growth E2E; here freeze the COMPONENT render:
- Renders the overlay: lock icon, the `feature` title, "Available on {requiredTier} plan. You're on
  {currentTier}." desc, and a full-width "Upgrade to {requiredTier}" button.
- Assert the upgrade button is text-labeled (a11y — not color-only) and links/handlers to billing.
- (Structure per prototype: absolute inset-0, the centered card. Assert the key elements render with
  the right text — don't pixel-assert the blur.)

### 4.7 — EmptyState + loading skeletons (the states §6U calls out)
- Team empty (solo owner) → just the owner row (no phantom rows).
- Audit-trail empty (new org) → "No activity yet" EmptyState (the canon copy).
- Loading → row skeletons render (not a blank flash) for team + audit-trail + residency.
- Error → the error boundary/fallback renders (assert the boundary catches a thrown child).

## Test conventions
- Use the repo's frontend render lib (Step 0). Query by role/text/label (accessible queries), NOT by
  brittle CSS selectors where avoidable.
- **Avoid bare snapshots** — assert specific elements/text/aria/behavior. A snapshot that
  re-baselines on any change is not a guard (it hides regressions behind an "update snapshot").
- Assert canon (the role→token mapping, the 5 columns, "OpenAI", the F21 toggle behavior), not
  implementation-mirrored markup.
- Mock only what's needed to render (props/context); these are unit renders, no real DB/HTTP.

## RE-BREAK PROOF (before section 5)
1. Change the analyst role-badge token to the owner token → 4.1 FAILS. Revert.
2. Remove the Joined column from member-row → 4.2 FAILS. Revert.
3. Remove the brand_access picker from invite-form → 4.3 FAILS. Revert.
4. Make audit-log-row render the expand even when metadata is null → 4.4 negative case FAILS. Revert.
5. Reapply CSS `capitalize` to the provider column (or set openai→"Openai") → 4.5 FAILS. Revert.
6. Change the audit-trail empty copy from "No activity yet" → 4.7 FAILS. Revert.
Report the 6 REDs + green-after-revert.

## Constraints
- Frontend unit renders only — no real DB/HTTP/events (those are §2). If a component can't render
  without a live data source, mock the data source; don't spin up a backend.
- No bare snapshots as the primary assertion — specific element/aria/behavior assertions.
- Assert canon specs (§6U + prototype styling), not current markup mirrors.
- If a component is MISSING a spec'd element (e.g. a state not implemented), REPORT as a finding —
  don't silently skip the assertion.
- Test-only changes (+ reverted re-breaks). If Step 0 finds no DOM test env, report it before
  writing (I'll add the env setup first).

## Report back (paste inline)
1. Step 0: the frontend runner/render-lib + DOM env; any existing component tests (behavioral vs
   snapshot); whether a DOM env needs adding.
2. Written vs extended — the component test files, per 4.1–4.7.
3. Test run: all green (count).
4. Any finding — a component missing a spec'd element/state (§6U).
5. RE-BREAK: the 6 REDs + green-after-revert.
