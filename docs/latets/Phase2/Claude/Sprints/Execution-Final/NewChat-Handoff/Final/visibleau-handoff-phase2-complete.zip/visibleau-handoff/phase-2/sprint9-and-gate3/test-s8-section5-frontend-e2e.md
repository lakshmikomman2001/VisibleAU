# TEST TRACK S8 — SECTION 5: FRONTEND E2E (Playwright) — THE FINAL SECTION

## Scope & why this one is different
§5 mirrors the manual walk end-to-end AND carries the deferrals only a full flow can prove:
- **F6/F2 FUNCTIONAL provisioning proof (LOAD-BEARING):** §2 could only source-assert that
  `afterCreateOrganization` CONTAINS the owner-seed + residency-writer calls — it couldn't prove
  they FIRE (the hook isn't importable). Only a real org-create E2E asserts the owner row + 7
  residency rows appear BECAUSE provisioning ran. This is the genuine F6/F2 guard; without it those
  findings have only source-level protection. **This is the reason §5 matters most.**
- **Full F18 tier-gate** (Agency full vs Growth locked) end-to-end — §4 froze the component; §5 does
  the real signed-in flow.
- **HIGH-12 end-to-end** — a viewer session actually blocked from audit-trail (not just the §2
  handler test).
- The manual-walk mirror across the 3 governance screens.

Build it, re-break the load-bearing ones, and the 5-phase track is COMPLETE.

## STEP 0 — Inventory the existing Playwright harness
```bash
cd c:/startup/VisibleAU/src
ls tests/e2e/ tests/e2e/backend/ 2>/dev/null
# The auth/session setup — how does an E2E test sign in as a given role/org? (storageState? a login helper? a seeded session?)
grep -RlE "storageState|signIn|login|test.use|authenticate|setup.*auth|createSession" tests/e2e/ 2>/dev/null | head
grep -Rn "role|owner|viewer|analyst|org|organization" tests/e2e/**/helpers/* 2>/dev/null | head
# Playwright config — baseURL, projects, whether a dev server is auto-started
cat playwright.config.* 2>/dev/null | grep -iE "baseURL|webServer|projects|testDir|storageState"
# Any existing governance/settings E2E?
grep -RlE "settings/team|audit-trail|data-residency|TierGate|tier-gate|governance" tests/e2e/ 2>/dev/null
```
Report: the harness dir, how a test authenticates as a specific role+org (the key capability — the
whole section needs owner/viewer/Growth-org sessions), and any existing settings E2E.
**If there's no way to sign in as a chosen role/org**, report it — that's the prerequisite; I'll
write an auth-fixture step first (seed org+members with known roles, produce storageState per role).

## The E2E scenarios (mirror the walk + prove the deferrals)

### 5.1 — F6/F2 FUNCTIONAL PROVISIONING (the load-bearing test — do this one carefully)
Drive a REAL org creation through the app's actual path (the sign-up / create-organization flow the
app uses — the one that triggers `afterCreateOrganization`), then assert provisioning FIRED:
- After creating a fresh org (a unique test name/email, cleaned up after), query the DB (the §2
  test-DB helper / a direct connection):
  - an **owner `org_members` row** exists for the creator: `role='owner'`, `brand_access=null`,
    `is_active=true` — WITHOUT any test code inserting it (it must be there because provisioning ran).
  - the **7 data_residency_log rows** exist for the new org — again, because provisioning called
    `recordDataResidency`, not because the test did.
- Then load `/settings/data-residency` for the new org and assert the 7 rows RENDER (or the graceful
  "Residency information loading" state if provisioning is async, per §6U.4 — then it resolves to 7).
- **This is the ONLY test that proves F6/F2 actually fire.** Make it robust: create via the real
  flow, assert via DB read of provisioning's output, no test-side seeding.
- Cleanup: delete the test org + its cascade after (scoped by the test org id, the §2 SAFE pattern —
  NOT truncate).

> If the org-create flow can't be driven headlessly (email verification, external step), report the
> blocker and take the closest real path (e.g. the create-organization API the UI calls, still
> WITHOUT test-seeding the owner/residency rows). The invariant: rows appear via provisioning, not
> the test.

### 5.2 — F18 tier-gate end-to-end (Agency full vs Growth locked)
- Sign in as an **Agency**-tier org owner → `/settings/team` → assert the FULL team page renders
  (members table + invite form visible, NO lock overlay).
- Sign in as a **Growth**-tier org owner → `/settings/team` → assert the **TierGate locked overlay**:
  "Agency plan required" + an Upgrade control → /settings/billing, and the invite form is NOT
  interactable (behind the overlay). This is the exact conditional we render-proofed by hand.
- (Tier from subscriptions.tier — the test orgs' tiers set accordingly in the fixture.)

### 5.3 — HIGH-12 viewer blocked from audit-trail (end-to-end)
- Sign in as a **viewer**-role member → navigate to `/settings/audit-trail` → assert it is **blocked**
  (403 page / redirect / access-denied — whatever the app shows), NOT the audit log.
- Sign in as an **analyst** (or owner/admin) → `/settings/audit-trail` → assert the log RENDERS.
- This is the real-session proof of the HIGH we fixed (the §2 test is the handler; this is the user).

### 5.4 — Audit-trail walk mirror (the screen we walked by hand)
Sign in as owner on an org WITH audit rows (seed a couple via the real audited actions, or the §2
helper):
- Rows render: action label + resource_type badge + actor ("by X" / "System") + tabular timestamp.
- **Pagination** works (Previous/Next; disabled at boundaries).
- **F21 metadata expand end-to-end:** a row WITH metadata shows "Details" → click → reveals
  `brandId` (the real E2E companion to §4's unit test + the earlier render-proof).
- Empty org → "No activity yet".

### 5.5 — Data-residency + Team walk mirror
- `/settings/data-residency` (Agency org): the 7 rows render, provider names "OpenAI"/"Anthropic"/
  "Supabase" (F13), primary-region banner, the DPA text.
- `/settings/team` (Agency owner): members table (5 columns incl. Joined), invite form (email +
  role + brand_access picker), pending-invites section if any; seat subtitle "(5 seats)".
- **Nav reachability (F3 end-to-end):** from the dashboard, the sidebar ACCOUNT section links to
  Team / Audit Trail / Data residency and each navigates (the URL-orphan bug, proven fixed via
  actual clicks).

## Test conventions
- Reuse the existing Playwright harness + auth pattern (Step 0). Use accessible/role-based locators
  (getByRole/getByText), not brittle CSS.
- Each test seeds its own org/members with known roles+tiers and cleans up scoped-by-id (the §2 SAFE
  pattern — never truncate shared tables). LLM_MODE=mock; no real spend.
- Assert canon states (the locked overlay copy, the 7 rows, "No activity yet", the F21 reveal), not
  incidental markup.
- Don't re-prove §2/§4 in isolation — §5 is the end-to-end user flow; where it overlaps, it's the
  real-session version (that's the added value).

## RE-BREAK PROOF (the load-bearing ones)
1. **F6/F2 (5.1):** in a throwaway branch, comment out the owner-seed in `afterCreateOrganization`
   → 5.1 FAILS (owner row absent after real org-create). Revert. Then comment out the
   `recordDataResidency` call → 5.1 FAILS (7 rows absent). Revert. **This is the proof §2 couldn't
   give — that provisioning actually fires.**
2. **F18 (5.2):** set the Growth test org's tier to agency → 5.2's "Growth shows locked" FAILS
   (it'd show the full page). Revert.
3. **HIGH-12 (5.3):** point the audit-trail route back at `view_reports` → 5.3's "viewer blocked"
   FAILS (viewer sees the log). Revert.
Report the REDs + green-after-revert. #1 is the most important re-break in the entire track.

## Constraints
- 5.1 must create the org via the REAL provisioning path and assert via DB read of provisioning's
  output — NO test-side seeding of the owner/residency rows (or it proves nothing, the F23 lesson).
- Scoped-by-id cleanup only — NEVER truncate shared tables. LLM_MODE=mock.
- Reuse the existing harness/auth fixture; if signing in as a role/org isn't possible, report it and
  I'll write the auth-fixture step first.
- If 5.1 reveals provisioning does NOT actually seed on org-create (the real F6/F2 failing for real),
  that's a CRITICAL finding — REPORT it (do not fix in the test prompt). This is the test most
  likely to catch a real remaining bug, because it's the first time we drive true org-create.

## Report back (paste inline)
1. Step 0: the harness + how a test authenticates as role/org; whether an auth fixture is needed.
2. Written vs extended — the E2E spec files, per 5.1–5.5.
3. Test run: all green (count).
4. **5.1 specifically:** did a real org-create produce the owner row + 7 residency rows WITHOUT
   test seeding? (the F6/F2 functional verdict — the whole point of §5.)
5. Any finding — esp. if 5.1 shows provisioning doesn't fire (CRITICAL).
6. RE-BREAK: the REDs + green-after-revert (esp. #1, the provisioning proof).
