# S9 TEST TRACK — SECTION 4: FRONTEND UNIT

## Scope
The **6 S9 components** (§6U, canon), tested at the render layer with mocked props. No DB, no HTTP.

```
components/domain/autopilot/
├── autopilot-loop.tsx           §6U.2  the 5-step stepper
├── loop-step-card.tsx           §6U.2  one step (icon, title, desc, status, time)
├── health-check-panel.tsx       §6U.3  traffic-light dims + #1 action
├── action-progress-tracker.tsx  §6U.4  "N of M gaps closed this month"
├── prompt-trend-sparkline.tsx   §6U.5  12-week sparkline (ORPHANED — F12)
└── persona-dashboard.tsx        §6U.6  persona shaping (~70% — F14)
```

**Location:** `tests/phase2/sprint9/components/`
**Do NOT duplicate Sections 1–3.** Sections 1–2 cover the pure functions and routes; Section 3 covers
the walk findings. **Section 4 covers the LLD's declared STATES for each component** — the states
canon names explicitly, most of which have never been rendered in a test.

---

## ⚠️ 4.0 — A CANON CLAUSE NOBODY HAS TESTED (probable NEW FINDING)

**§6U.2, verbatim:**
> *"Handle a **flat or negative** outcome honestly (the real delta / 'no measurable change yet') —
> **never always 'improved X%.'**"*

**Every test we have checks `score_after IS NULL` → pending. NOT ONE checks what a NEGATIVE
`lift_achieved` renders.** If the copy hardcodes "improved" / "↑" / a `+` prefix, then **a fix that
made a brand's visibility WORSE would be reported as an improvement.** That is a lie on the sprint's
flagship honesty surface.

Test `buildMeasureDescription` / step 5 with:
| `score_after` | `lift_achieved` | Must render |
|---|---|---|
| NULL | — | **"validation audit scheduled — pending"** (no number) |
| 42.5 | **+7.3** | an improvement, **+7.3** |
| 42.5 | **0** | ⚠️ **"no measurable change yet"** — **NOT "improved 0%"**, NOT the pending copy |
| 42.5 | **−5.2** | ⚠️ **the real negative delta** — **NOT "improved 5.2%"**, NOT a hidden/absolute value |

⚠️ **Assert the ABSENCE of "improved" / "↑" / "+" in the 0 and negative cases.** If the component
can't render a negative honestly → **that's a NEW FINDING (F24). Report it; do not fix it silently.**

Also (§6U.4 contrast): the **tracker's** citation-rate delta **IS** a real week-over-week
`visibility_trends` trend with an up/down arrow — canon says *that one is fine*. **Only the per-fix
loop claim needs the `score_after` gate.** Don't conflate them.

---

## 4.1 — `loop-step-card.tsx` — the 3 presentational states

**⚠️ CANON, IN CAPITALS (§6U.2):** `step.status` is **`done | current | pending`** — a *timeline
stepper* concept — and is **NOT** `remediation_tasks.status` (the DB enum
`open|in_progress|ready_for_review|complete|wont_fix`). *"Do NOT unify them."* §12 even greps for it:
`grep -Rc "open\|in_progress\|..." autopilot-loop.tsx → 0`.

- Each of `done` / `current` / `pending` renders its distinct visual (check / highlighted / dashed).
- ⚠️ **The component NEVER accepts or renders a `remediation_tasks` enum value.** Pass `"in_progress"`
  as a status → it must **not** render as if valid. **Freeze the separation.**
- Renders: icon, title, description, optional timestamp.
- `pending` steps are visually de-emphasised (dashed), not hidden.

## 4.2 — `autopilot-loop.tsx` — the LLD's declared states
| State | Assertion |
|---|---|
| **loading** | step **skeletons** render |
| **loop-not-started** (no audit, no gaps) | an **EmptyState** explaining the loop populates after the first audit + gap — **NOT** five pending steps with fabricated copy |
| **in-flight** | current step highlighted; future steps dashed |
| **measure-pending** | ⚠️ **"validation audit scheduled — pending"** — assert **no number at all** |
| **measure-complete** | the real `lift_achieved`, **including flat/negative** (4.0) |
| **error** | an error boundary — **not** a silent empty |

Plus the **real fixtures**: Bondi (task, no gap) → step 2 **done**, advances to 3. Metropolitan (no
task) → honestly stalls at step 2.

## 4.3 — `health-check-panel.tsx` — bands + the #1 action

**⚠️ 3 bands** (green/amber/red). **The prototype's 4-band is KNOWN-WRONG (S9-02).**

- **Metropolitan** (answer key): 100 green · 5 red · 37 red · 20 red · overall **40.5 → 41 "Fair"**.
- **Bondi**: 50 amber · 0 red · 21 red · **NULL → em-dash "Not yet measured"** · overall **23.67 → 24
  "Critical"**.
- ⚠️ **SaaS** → Local Authority **absent from the DOM entirely** (§6U.3: "skip for SaaS brands").
- ⚠️ **`unmeasured` NEVER renders as a band** (F20 — the latent F11 mechanism).
- ⚠️ **The raw audit multidims must NOT appear.** §12: `grep -Rc "scorePosition\|scoreContext\|
  scoreAccuracy" health-check-panel.tsx → 0`. The Health Check **synthesises across layers**; it is
  **not** the raw multidim page. Assert those labels are absent.
- The **#1 action** renders the task title; ⚠️ with a NULL `description` it renders the **honest
  placeholder** and **does not fabricate a rationale** (F9/F13, carried).
- The hero banner is **reduced-motion-safe** (RM-02).

## 4.4 — `action-progress-tracker.tsx` (§6U.4 / LLD 9060)
- "N of M gaps closed this month" — Bondi's real state: **0 / 1**.
- ⚠️ Measured Impact with no measured lift → **"Validation audit scheduled — measured impact
  pending"**; assert the **absence of `0`** (not a zero, not a blank).
- The citation-rate delta **does** show an arrow (canon permits it — see 4.0).
- LLD 9060: *"must be prominent, not buried"* — assert it renders **above** the fold-level sections it
  precedes; and (F7) **exactly ONE** work-completed surface exists.

## 4.5 — `prompt-trend-sparkline.tsx` (§6U.5) — ⚠️ ORPHANED (F12)
**This component is not mounted anywhere** — the prompt-results table it belongs in was never built
(carried to S10). **Test it standalone anyway**, so it's correct when S10 mounts it:
| State | Assertion |
|---|---|
| **loading** | a **shimmer** in the cell |
| **empty (<2 weeks)** | **"Not enough history yet"** — **not** a flat zero line |
| **error** | a **muted dash**, **no** error boundary (canon: it's an inline cell) |
| **data** | e.g. 8% → 12% → 22% → 34% renders as a trend |
- **RESPONSIVE:** fixed-width; on `<sm` it moves **below** the prompt text rather than inline.
- ⚠️ Keep the **component-mount guard's waiver** intact and documented — do NOT mount it to satisfy a
  test.

## 4.6 — `persona-dashboard.tsx` (§6U.6) — ⚠️ ~70% SHIPPED (F14)
Guard **what ships today**; document what doesn't. Canon: Agency (multi-brand command centre +
cross-brand task queue) · SMB (Health Check + top-5 fixes + Mention-Source archetype + LinkedIn
presence) · local-tradie.
- Each persona renders its shipped elements.
- ⚠️ **The 4 ABSENT elements** (suburb visibility, Reddit AU feed, embedding-page gap alert, persona
  filter dropdown) — assert they are **absent**, with a comment naming them as carried. **The gap
  stays visible in the suite.**

---

## CONSTRAINTS
- **Render behaviour, not class names.** Where jsdom forces a CSS-class assertion (responsive,
  reduced-motion), **flag it as weak** — Section 5 (Playwright) will test those properly in a real
  browser with a real viewport and a real `prefers-reduced-motion`.
- **Assert canon, not the code.** A code-vs-canon disagreement is a **NEW FINDING** — report it.
- Real answer-key fixtures (Metropolitan / Bondi). Any synthetic fixture must be **labelled synthetic**
  with a reason (the F8-guard lesson: a synthetic fixture silently made that guard vacuous).
- **Do NOT fix carried findings** (F12 mount, F14 personas, F9/F13 explainability). Guard today's
  honest behaviour.
- Do **NOT** touch §12 QA — standalone final pass after Section 5.

## REPORT BACK (paste inline)
1. File paths + test count.
2. ⚠️ **4.0 — the flat/negative lift result.** Does step 5 render a negative `lift_achieved` honestly,
   or does it say "improved"? **If it can't, that's F24 — a NEW HIGH-ish finding on the honesty
   surface.** This is the single most important answer in this section.
3. ⚠️ **4.1 — is the `done|current|pending` / `remediation_tasks.status` separation actually enforced**,
   or does the component accept a DB enum value?
4. Any state canon declares that the component **doesn't implement** (loading skeletons? EmptyState?
   error boundary?) → each is a finding.
5. Which assertions could only be CSS-class greps (flagged weak, deferred to Section 5).
6. Full suite green (283 + Section 4).
