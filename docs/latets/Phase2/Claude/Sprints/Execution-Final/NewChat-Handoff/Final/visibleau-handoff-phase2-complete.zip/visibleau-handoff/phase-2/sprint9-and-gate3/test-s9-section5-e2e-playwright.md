# S9 TEST TRACK — SECTION 5: FRONTEND E2E (PLAYWRIGHT)

## Why this section exists
Everything before it ran in **jsdom** — no viewport, no media queries, no real navigation, no session.
Section 5 is the **only** layer that can test what canon actually binds:
- **RESPONSIVE** breakpoints (canon declares them per-component; jsdom cannot resize)
- **`prefers-reduced-motion`** (RM-02 — a real media query)
- **Tier gates** — ⚠️ **never once exercised** (our test org is Agency; every S9 surface is **Growth+**)
- **The loop, end to end**, against the real DB

**Harness exists:** `tests/e2e/` with `auth.ts` / `db.ts` helpers (built in S8). Reuse them.
**Location:** `tests/e2e/sprint9/`

---

## ⚠️ 5.0 — TWO CANON MISMATCHES FOUND WHILE READING THE SPEC (verify, then report)

### F26 — the Health Check grid: canon says **5 columns**, the screen shows **4 cards**
**Canon §6U.3, verbatim:**
> *"**5 traffic-light sections**"* … *"**#1 ACTION** (the 5th section)"* …
> *"RESPONSIVE: section cards `grid-cols-1 sm:grid-cols-2 lg:grid-cols-5`"*

**The #1 Action is the FIFTH CARD IN THE GRID** — not a separate panel below it. On screen it renders
in its own box underneath the four dimension cards. **Verify against the DOM:**
- Is the grid `lg:grid-cols-5`, or `lg:grid-cols-4` with the action outside it?
- **This also means the `sm:grid-cols-2` and `grid-cols-1` breakpoints have NEVER been rendered** —
  every screenshot has been a wide desktop window.
Test all three widths. **Report the mismatch; do not silently "fix" the layout** — Sri decides whether
canon or the current UX wins.

### F27 — every S9 surface is **Growth+**, and the tier gate has NEVER been tested
**Canon:** *"the Autopilot loop view, Health Check, Action Progress Tracker, per-prompt trend, and
persona dashboards are **Growth+**… the Agency multi-brand command centre is **Agency+**."*
**Our test org is Agency tier** — so the gate has never fired in a browser. ⚠️ **A Free/Starter user
has never loaded these pages.** They must see a **TierGate lock**, not a 404, not a 500, and
**absolutely not the content.**
**⚠️ `subscriptions.tier` is the SOLE source — never `organizations.tier`** (the S8 footgun).

---

## 5.1 — THE LOOP, END TO END (the sprint's whole point)
Real login → real DB → real render.
- **Bondi** `/brands/{bondiId}/autopilot`:
  - header **"Bondi Plumbing"** (not "Brand") · **"Step 3 of 5"**
  - step 1 **done** with real score · engines · **prompts** (⚠️ `promptsCount` — the field missing
    from the SELECT, F15)
  - step 2 **done**, showing **"Update local directory listings"**
  - step 5 → **"validation audit scheduled — pending"** ⚠️ **assert NO number appears**
- **Metropolitan** `/brands/{metroId}/autopilot`: honestly **stalls at step 2** ("No gaps identified
  yet") — it has no open task. ⚠️ **The two brands must DIVERGE.** That divergence is F17's proof.
- **"Back to brand"** → lands on `/brands/{id}` (the tile grid), **not a 404** (F19).

## 5.2 — HEALTH CHECK: the answer key, on a real screen (F11's proof)
- **Metropolitan**: Sentiment **100 green** · Presence **5 red** · Site Readiness **37 red** · Local
  Authority **20 red** · overall **41 "Fair"**.
- **Bondi**: **50 amber** · **0 red** · **21 red** · **em-dash "Not yet measured"** (grey, **no red
  dot**) · overall **24 "Critical"**.
- ⚠️ Assert **NO brand renders 0/100 "Critical"** when its real score is non-zero. *That was F11 — the
  bug this whole track exists because of.*
- ⚠️ The raw multidims (`Position` / `Context` / `Accuracy`) are **absent** — the Health Check
  synthesises across layers; it is not the multidim page (§12: those greps must be 0).
- **"Start this action →"** CTA leads into the Autopilot loop (§6U.3).

## 5.3 — ⚠️ RESPONSIVE (the four weak assertions, now testable for real)
Playwright `page.setViewportSize()` — real breakpoints, real reflow.
| Component | Canon | Widths to test |
|---|---|---|
| Autopilot stepper | horizontal `≥lg`, **vertical `<lg`** | 1280 · **390** |
| Health Check grid | `grid-cols-1` / `sm:grid-cols-2` / `lg:grid-cols-5` | **375 · 640 · 1280** |
| Health Check hero | **stacks `<md`** | 375 · 768 |
| Sparkline | fixed-width; **below the prompt text `<sm`** | 375 · 640 |
- ⚠️ **Assert the actual computed layout** (bounding boxes / stacking order), **not class names.**
  A vertical stack means step 2's `y` > step 1's `y`. **That's the test jsdom could never write.**
- **No horizontal scroll** at 390px (`document.body.scrollWidth <= viewport.width`).

## 5.4 — ⚠️ REDUCED MOTION (RM-02 — grep #14 claimed PASS while a violation was live)
```ts
await page.emulateMedia({ reducedMotion: 'reduce' });
```
- The Health Check **hero gradient** does not animate.
- **No `animate-pulse`** runs on the current step.
- **Break-proof:** remove the `motion-safe:` gating → the test goes **RED**. *(An ungated
  `animate-pulse` shipped once already, past a green grep.)*

## 5.5 — ⚠️ TIER GATES (F27 — never tested)
Seed orgs at each tier (**`subscriptions.tier`**, never `organizations.tier`):
| Tier | `/autopilot`, `/health-check`, tracker | Agency command centre |
|---|---|---|
| **free / starter** | ⚠️ **TierGate LOCK** — not a 404, not a 500, **and NOT the content** | locked |
| **growth** | ✅ full content | locked |
| **agency** | ✅ full content | ✅ |
- ⚠️ **Fixture: `organizations.tier='free'` + `subscriptions.tier='growth'` → MUST be ALLOWED.** This
  is the test that catches a route reading the wrong column. **Break-proof it:** point the gate at
  `organizations.tier` → RED.
- ⚠️ **Assert the locked page does not leak the data** in the DOM or the network response.

## 5.6 — BRAND ISOLATION, IN THE BROWSER
- Log in as Org A → navigate to Org B's `brandId` → **404** (canon: cross-org → 404, not 403).
- ⚠️ Assert **zero rows leak** — the brand name, scores, and task titles must be **absent from the
  page and from any XHR payload**. (Section 2 proved this at the DB/route layer; prove it end to end.)

## 5.7 — THE DASHBOARD
- **Exactly ONE** work-completed surface (F7 — the vestigial card is retired).
- The tracker shows **"0 / 1 gaps closed this month"** + **"Validation audit scheduled — measured
  impact pending"**; ⚠️ **assert the absence of `0`** in the impact copy.
- LLD 9060: *"prominent, not buried"* — assert it renders **above** Share of Voice / Recent audits.

## 5.8 — CANON-DECLARED STATES (F25 — three are unimplemented)
Section 4 found `autopilot-loop` lacks canon's **loading skeleton**, **EmptyState**, and **error
boundary**. Confirm in a real browser:
- **A brand with NO audit** → does it show canon's EmptyState ("the loop will populate after the first
  audit"), or 5 pending steps with generic copy?
- **A malformed route response** (intercept + return garbage) → does the page throw a **white screen**,
  or degrade honestly? ⚠️ **Without an error boundary, a route-shape change takes down the whole
  page.** That is the failure mode the envelope class (F11/F15/F16/F17) would now produce. **Report
  which happens.**

---

## CONSTRAINTS
- **Real browser, real DB, real session.** Reuse `tests/e2e/auth.ts` / `db.ts`.
- **Assert computed layout, not class names** — that's the entire reason this section exists.
- Real answer-key fixtures (Metropolitan / Bondi). Tier fixtures may be seeded — **label them**.
- **Report canon mismatches (F26, F27); do NOT silently redesign.** Sri decides.
- Do **NOT** fix carried findings (F12, F14, F9/F13, F23, F25).
- Do **NOT** touch §12 QA — it runs as the **standalone final pass** after this section.

## REPORT BACK (paste inline)
1. File paths + test count.
2. ⚠️ **F26** — is the Health Check grid `lg:grid-cols-5` with the #1 action as the 5th card, or 4 + a
   separate panel? **Screenshots at 375 / 640 / 1280.**
3. ⚠️ **F27** — what does a **free-tier** user actually see on `/autopilot` and `/health-check`?
   (Lock / 404 / 500 / **the content**?) **This has never been tested.**
4. ⚠️ **5.8** — malformed response → white screen, or honest degradation?
5. The RM-02 break-proof RED.
6. The `<lg` vertical stack proven by **bounding boxes** (not classes).
7. Full suite green (390 + Section 5).
