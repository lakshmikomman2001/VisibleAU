# TOOL — Dev vs Prod migration drift checker (+ does it explain the S9 zeros?)

## Why this is worth building once, properly
1. **This gap is a repeat offender.** S8's **CRITICAL F1** was exactly this: the governance migration
   was applied to dev, never to prod → **44 routes 500'd**. The standing rule is "migrations to BOTH
   DBs," and it keeps slipping because there's no check.
2. **It may explain the S9 zeros — and if so, it changes our conclusions.** On prod we observed:
   - **0 journeys** on every brand → `conversational_journeys` (migration **0020**, Sprint 7)
   - **0 topical gaps** on Bondi → `topical_coverage_gaps` (migration **0013**, Sprint 3)
   Both come from **manual, non-Drizzle-journal migrations**. If either table is missing or empty on
   prod, those zeros are **honest empties over an unmigrated table**, not the bugs we assumed.
   **We've been grading screens against the DB — if the DB is missing tables, the answer key itself
   is wrong.**

## PART 1 — Build the drift checker (a keeper — reuse it every sprint)

`scripts/db/check-migration-drift.sh` (or `.ts` — match repo convention). It must:

1. Connect to **BOTH** DBs (dev `visibleau` from `.env.test.local`; prod `visibleau_prod` from
   `.env.local`). Read the URLs from env — never hardcode.
2. For **each** DB report:
   - the Drizzle journal state (`SELECT * FROM __drizzle_migrations ORDER BY created_at`) — which of
     0000–0009 are applied
   - **table existence** for every table introduced by the MANUAL migrations (0010–0022 +
     `sprint-8-tables.sql`), since those are NOT in the journal and Drizzle can't tell us
3. Emit a **side-by-side drift table**:
   ```
   TABLE                       | dev | prod | migration                        | STATUS
   topical_coverage_gaps       |  ✓  |  ✓   | 0013_phase2_sprint3_visibility   | OK
   conversational_journeys     |  ✓  |  ✗   | 0020_phase2_sprint7_discovery    | ⚠ MISSING ON PROD
   ...
   ```
4. **Exit non-zero if any table exists on one DB but not the other** — so it can be a pre-flight gate.
5. Also report, for the tables that DO exist on both: **row counts** side by side (a table can exist
   but be empty — a different problem from missing).

Derive the table list from the migration files themselves rather than hardcoding:
```bash
cd c:/startup/VisibleAU/src
grep -hoE "CREATE TABLE (IF NOT EXISTS )?[\"a-z_]+" db/migrations/00*.sql db/migrations/sprint-8-tables.sql 2>/dev/null \
  | sed -E 's/CREATE TABLE (IF NOT EXISTS )?//' | tr -d '"' | sort -u
```
(adjust the path to wherever the .sql files live)

## PART 2 — Run it and answer the S9 question

Run the checker, then specifically report:

| Table | Migration | dev | prod | rows (dev) | rows (prod) |
|---|---|---|---|---|---|
| `conversational_journeys` | 0020 (S7) | ? | ? | ? | ? |
| `topical_coverage_gaps` | 0013 (S3) | ? | ? | ? | ? |
| `content_drafts` | 0011 (S2) | ? | ? | ? | ? |
| `remediation_tasks` | 0011 (S2) | ? | ? | ? | ? |
| `webhook_deliveries` | 0021/0022 (S8) | ? | ? | ? | ? |
| `technical_audits` | (S7) | ? | ? | ? | ? |
| `agent_readiness_scores` | (S6) | ? | ? | ? | ? |

**Then classify the S9 zeros:**
- **`conversational_journeys` MISSING on prod** → F16's "0 journeys" was an **honest empty over a
  missing table**, not (only) the unwrap bug. *The unwrap fix is still correct* — `Array.isArray` on
  an envelope was genuinely wrong — but the symptom had a second cause. Report both.
- **`conversational_journeys` EXISTS but is EMPTY on prod** → honest empty (S7 never ran journeys for
  these brands). The unwrap fix is unverifiable from the UI until data exists. Note it.
- **`conversational_journeys` EXISTS with rows on prod** → then the 0 WAS the unwrap bug, and the fix
  should now show a real count. **Verify on screen.**
- Same three-way classification for **`topical_coverage_gaps`** — which decides whether **F17's CASE 1
  conclusion** ("Bondi legitimately has no gap") is right, or whether gaps are absent because the
  table/data isn't there.

## PART 3 — Apply what's missing (carefully)
If the drift report shows tables missing on prod:
- Apply the missing migrations **to prod** (the manual ones, in order).
- **Idempotency check first:** the S8 QA script verified `CREATE TABLE/INDEX/POLICY → IF NOT EXISTS`.
  Confirm the pending migrations are idempotent before running (re-running a non-idempotent migration
  on a partially-migrated DB is how you get a mess).
- Re-run the checker → drift should be zero.
- **Then re-check the S9 screens** — a previously-500ing or empty screen may now populate, and any
  conclusion we drew from a zero needs revisiting.

## Constraints
- Read the DB URLs from env; never hardcode credentials.
- The checker must be **read-only** in Part 1/2 (it only inspects). Part 3 (applying migrations) is a
  separate, explicit step.
- Verify idempotency BEFORE applying anything to prod.
- Do NOT drop/recreate anything. Additive only.

## Report back (paste inline)
1. The checker script (path) + the **full drift table** (dev vs prod, per table).
2. The **row counts** for the S9-relevant tables (both DBs).
3. **The classification** for `conversational_journeys` and `topical_coverage_gaps`: missing / empty /
   populated — and therefore whether F16's and F17's zeros were bugs, honest empties, or both.
4. Which migrations (if any) are pending on prod, and whether they're idempotent.
5. After applying (if needed): the re-run drift table showing zero drift.
