# VALIDATE MIGRATION 0011 AGAINST PROD — before commit

## Why this can't be skipped
`0011_watery_cerebro.sql` was generated and **pushed to dev only.** But:
- **Dev has 0 rows. `visibleau_prod` has 3,405 citations across 19 audits** — the real data lives in
  prod.
- ⚠️ **The dupe check ran against the empty dev DB** — *"0 rows, no duplicates."* **That proves
  nothing.** `brand_entity_scores` was the **confirmed duplicate carry** (G-4) — consumers use
  `ORDER BY ... DESC LIMIT 1` *because dupes exist*. **The unique index will likely FAIL on prod.**
- ⚠️ **Dev now has `0011`; prod doesn't → the DBs have DIVERGED.** This is the exact drift class that
  caused **S8's CRITICAL F1** (migration on one DB, not the other → 44 routes 500'd).

`0011` also changes **cascade semantics on live data** (`citations` NO ACTION → CASCADE). Correct
design — but on a DB with 3,405 citations it's applied deliberately, not as a "pushed to dev"
side-effect.

⚠️ **READ-ONLY until Step 2 confirms it's safe. Do NOT run `0011` on prod yet.**

---

## STEP 1 — ⚠️ Check for duplicates ON PROD (the check that actually matters)
The unique indexes in `0011` will be **rejected** if the data already violates them.

```bash
cd c:/startup/VisibleAU/src

# G-4: brand_entity_scores — the CONFIRMED dupe carry. Is (brand_id, market_code, checked_at) unique?
psql "$PROD" -c "
  SELECT brand_id, market_code, checked_at, COUNT(*) AS n
  FROM brand_entity_scores
  GROUP BY brand_id, market_code, checked_at
  HAVING COUNT(*) > 1
  ORDER BY n DESC;"

# G-3: technical_audits — is audit_id already unique?
psql "$PROD" -c "
  SELECT audit_id, COUNT(*) AS n
  FROM technical_audits
  GROUP BY audit_id
  HAVING COUNT(*) > 1
  ORDER BY n DESC;"
```
⚠️ **Report the dupe counts.** Three outcomes per table:
- **Zero dupes** → the unique index will apply cleanly. Proceed.
- **Dupes exist** → the index will FAIL. **Do NOT force it.** Report the dupes; we decide how to
  de-dup (keep latest per group, delete the rest) **before** the constraint goes on.
- ⚠️ **`brand_entity_scores` is EXPECTED to have dupes** (that's why G-4 exists). If it comes back
  clean, double-check the tuple is right — maybe the dupes are on a *different* key than
  `(brand_id, market_code, checked_at)`.

## STEP 1b — ⚠️ Is `(brand_id, market_code, checked_at)` even the right natural key?
The dupes may have been created by **the same audit run writing twice** — in which case those rows share
a `checked_at`, and this tuple would reject them.
```bash
# What distinguishes two rows for the same brand? Look at actual dup groups:
psql "$PROD" -c "
  SELECT brand_id, market_code, checked_at, audit_id, score_of_10, created_at
  FROM brand_entity_scores
  WHERE brand_id IN (
    SELECT brand_id FROM brand_entity_scores
    GROUP BY brand_id, market_code, checked_at HAVING COUNT(*)>1 LIMIT 1)
  ORDER BY checked_at, created_at;"
```
**Report what actually differs between duplicate rows.** If they differ by `audit_id`, the natural key
might be `(brand_id, market_code, audit_id)`, not `checked_at`. ⚠️ **Confirm the key against real data
before locking it into a constraint** — a wrong unique key is worse than none.

## STEP 2 — Apply 0011 to prod (ONLY if Step 1 is clean, or after de-dup)
Once dupes are resolved (or confirmed absent):
```bash
# Apply the SAME migration to prod that dev has:
npx drizzle-kit migrate    # against visibleau_prod   (or apply 0011 via the tracked path)
```
⚠️ **Both DBs must end on the same migration.** After applying:
```bash
# Confirm 0011 is recorded on BOTH:
psql "$DEV"  -c "SELECT * FROM drizzle.__drizzle_migrations ORDER BY created_at DESC LIMIT 2;" 2>/dev/null
psql "$PROD" -c "SELECT * FROM drizzle.__drizzle_migrations ORDER BY created_at DESC LIMIT 2;" 2>/dev/null
```
(If these DBs are `push`-managed and have no `__drizzle_migrations` table, confirm parity a different
way — e.g. both have the new unique indexes and cascade constraints.)

## STEP 3 — Verify the cascade change didn't break anything live
```bash
# Confirm the new constraints are actually on prod:
psql "$PROD" -c "
  SELECT conname, confdeltype FROM pg_constraint
  WHERE conname LIKE '%audit_id%' AND contype='f'
  ORDER BY conname;"
# confdeltype: 'c'=CASCADE, 'n'=SET NULL, 'a'=NO ACTION
# Confirm the unique indexes exist on prod:
psql "$PROD" -c "\d technical_audits" | grep -i uniq
psql "$PROD" -c "\d brand_entity_scores" | grep -i uniq
```
⚠️ **`citations.audit_id` must show `c` (CASCADE), not `a` (NO ACTION)** on prod — that's the G-1 fix
landing where the data actually is.

## STEP 4 — Re-run the drift checker
The whole point is that dev and prod match **and** match the migration files.
```bash
# the dev/prod drift checker built earlier this sprint
<run the drift-check script>
```
⚠️ **After 0011, dev == prod?** If not, they've diverged again and `0011` didn't land on one of them.

---

## CONSTRAINTS
- ⚠️ **Do NOT force a unique index onto dup'd data** — it fails, or (worse) silently isn't created.
  De-dup first, deliberately, with the keep-rule stated.
- ⚠️ **Do NOT run `drizzle-kit push` against prod** — `push` is destructive. Apply the specific
  migration `0011` via the tracked/`migrate` path.
- **Both DBs must end identical** — that's the S8-F1 lesson.
- If prod has dupes → **STOP and report**, don't auto-clean without stating the keep-rule (keep the
  latest `created_at` per group? confirm).

## REPORT BACK (paste inline)
1. ⚠️ **Prod dupe counts** — `brand_entity_scores` and `technical_audits`. (Does the confirmed carry
   actually have dupes?)
2. ⚠️ **What differs between duplicate rows** — is `(brand_id, market_code, checked_at)` the right key,
   or should it be `audit_id`?
3. If de-dup was needed: the **keep-rule** and how many rows removed.
4. **0011 applied to prod?** Both DBs on the same state?
5. **`citations.audit_id` = CASCADE on prod?** Unique indexes present on prod?
6. ⚠️ **Drift checker: dev == prod?**
