# VERIFY F-6 BEFORE COMMIT — does each sparkline plot REAL history, or a flat line?

## Why this check exists
F-6 was mounted, but the prompt's **Step 1 gate** was: prove per-prompt trend **history** exists before
mounting. The report says the data source is *"distinct prompt **texts** from the `citations` table."*

⚠️ **Distinct prompt text is not trend history.** A sparkline plots **one prompt's result across many
audits** — a line over time. If each sparkline only gets **one data point** (the current value), it
renders a **flat line**, which is the **F11 lie**: *"no movement"* when the truth is *"no history yet."*
**That is worse than leaving it orphaned.**

"28/28 pass" doesn't settle this — a test that renders a sparkline with one data point still passes.
**This is the screen-vs-test distinction that caught ~40 findings this session.**

READ-ONLY diagnosis. Do not commit anything yet.

---

## STEP 1 — What does each sparkline actually receive?
```bash
cd c:/startup/VisibleAU/src
cat components/domain/autopilot/prompt-trend-sparkline.tsx        # what prop shape does it plot?
cat components/domain/autopilot/prompt-trend-section.tsx          # what does the container pass in?
cat app/api/brands/[brandId]/prompts/route.ts                     # what does the route return?
```
**Report the data shape end to end:** route → section → sparkline. Specifically —
⚠️ **does each prompt come with an ARRAY of values over time (multiple audits), or a SINGLE value?**

## STEP 2 — Is there any per-prompt-over-time data in the DB at all?
Metropolitan = `418f321f-2489-4560-aaa9-895728580465` — **19 audits now**, so if history exists anywhere,
it exists for this brand.
```bash
# Do citations record which audit they came from, so a prompt CAN be tracked across audits?
psql "$PROD" -c "
  SELECT prompt_text, COUNT(DISTINCT audit_id) AS audits_spanning
  FROM citations
  WHERE audit_id IN (SELECT id FROM audits WHERE brand_id='418f321f-2489-4560-aaa9-895728580465')
  GROUP BY prompt_text
  ORDER BY audits_spanning DESC
  LIMIT 10;"
```
⚠️ **This is the deciding query.**
- If prompts span **multiple audits** (`audits_spanning > 1`) → real history EXISTS; the sparkline
  *can* be genuine. Confirm the route actually returns that series.
- If every prompt shows `audits_spanning = 1` → **there is no per-prompt history.** Each sparkline can
  only plot one point. **The mount is an F11 flat-line.**

## STEP 3 — The empty/insufficient case
The prompt required: a prompt with **<2 history points** must render **"not enough history yet"**, NOT a
flat zero line.
```bash
grep -n "not enough\|insufficient\|history\|length < 2\|length === 1\|EmptyState" \
  components/domain/autopilot/prompt-trend-sparkline.tsx \
  components/domain/autopilot/prompt-trend-section.tsx
```
⚠️ The report mentioned an empty-state for **zero prompts** (`returns null`) — but **not** for **a
prompt with insufficient history**, which is the actual F11 risk. **Does the <2-points case render a
message, or a flat line?**

---

## THE VERDICT — one of three
| Finding | Verdict | Action |
|---|---|---|
| Prompts span multiple audits **AND** the route returns the time series **AND** <2-points shows a message | ✅ **Genuine mount** | Commit F-6 |
| Prompts are single-audit / route returns single values → sparkline plots a flat line | ❌ **F11 flat-line** | **Un-mount.** Restore the guard waiver with a visible comment. Document as **S10** (needs a per-prompt trend table). |
| History exists but the route isn't returning it | ❌ **Wiring gap** | Fix the route to return the series, then re-verify |

## Constraints
- **Do not commit** until the verdict is ✅.
- ⚠️ **Do not "fix" this by making a test pass** — the test passing is not the question. The question is
  what a real sparkline plots for a real brand.
- If the honest answer is "no history exists," **un-mounting is the correct outcome**, not a failure.

## REPORT BACK (paste inline)
1. **The data shape** route → section → sparkline: array-over-time, or single value?
2. ⚠️ **The deciding query:** do any Metropolitan prompts span >1 audit? (paste the result)
3. **The <2-points case:** message, or flat line?
4. ⚠️ **The verdict** — genuine mount, F11 flat-line, or wiring gap?
