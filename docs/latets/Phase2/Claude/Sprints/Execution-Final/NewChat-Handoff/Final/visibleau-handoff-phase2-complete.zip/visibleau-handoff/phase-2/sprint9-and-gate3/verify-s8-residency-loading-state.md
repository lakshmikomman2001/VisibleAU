# VERIFY S8 — is 5.1.2 (data-residency: no table) a flake or a missing loading-state? (read-only)

## Why this one, not the other two E2E fails
5.2.1 and 5.5.3 are clean timeout flakes (goto/render hit the wall under 7-worker contention; pass
at --workers=1). Accepted.

5.1.2 is DIFFERENT. Its failure was **"page renders heading but no `<table>` — residency data loads
but page shows no table element."** That's rendered-but-empty, NOT timed-out. And it's on the
PROVISIONING test — the one place where "the org was just created and its 7 residency rows may not
be materialized yet" is a REAL live condition. §6U.4 specifies a graceful **"Residency information
loading"** state for exactly this timing. So the question: when the table isn't ready, does the page
show that loading state, or does it show a heading with nothing under it (a real gap)? READ-ONLY.

## Task — READ ONLY

### 1 — What does the data-residency page render when rows aren't ready?
```bash
cd c:/startup/VisibleAU/src
# The page's states: does it have a loading / not-yet-provisioned branch, or only table vs empty?
sed -n '1,120p' "app/(auth)/settings/data-residency/page.tsx"
grep -n "loading\|Residency information loading\|isLoading\|skeleton\|no.*table\|empty\|Suspense\|await\|fetch\|useState\|useEffect" \
  "app/(auth)/settings/data-residency/page.tsx"
# The residency-table component — does it render nothing on empty, or a message?
grep -n "length === 0\|!rows\|empty\|loading\|Residency information\|return null\|no data" \
  components/domain/governance/residency-table.tsx
```
CLASSIFY the page's behavior when residency rows are absent/not-yet-loaded:
- **HAS graceful state** — renders "Residency information loading" (or a skeleton) when rows aren't
  ready, then the table when they arrive. Then 5.1.2 was a true flake (the test asserted the table
  before the async fetch resolved; the page WAS showing the loading state). Fix = the test waits for
  the table / the loading→table transition. Not a product bug.
- **NO graceful state (gap)** — the page renders the heading + (empty) and NO loading indicator when
  rows aren't ready; the table only appears if data is present at render. Then 5.1.2 caught a REAL
  §6U.4 gap: a just-provisioned org (or any slow fetch) shows a heading over a void, not the
  specified "Residency information loading". FINDING (LOW-MED) — the graceful state isn't
  implemented. (This is precisely the provisioning-timing case §6U.4 calls out.)

### 2 — What exactly did 5.1.2 assert, and against which timing?
```bash
grep -n "5.1\|data-residency\|getByRole.*table\|locator.*table\|toBeVisible\|waitFor" \
  tests/e2e/sprint8/*.spec.ts | grep -iE "table|residency|5\.1" | head
```
Determine whether 5.1.2 waits for the table with a timeout (flake-prone if the loading state is
shown first) or asserts immediately. If the page HAS a loading state and the test doesn't wait
through it, that's a test-timing fix. If the page has NO loading state, the test correctly exposed
the gap.

### 3 — (context) Was 5.1 test 1 — the DB provisioning proof — still green?
The report says 5.1 test 1 (sign-up + DB owner-row + 7 residency rows) PASSED. Confirm 5.1.2 is the
*render* assertion (the page showing the table), NOT the DB proof — so the F6/F2 functional guard
(test 1) is unaffected regardless of 5.1.2's outcome. (It is — test 1 reads the DB; test 2 reads the
screen. The DB proof stands.)

## Classification (report one):
- **FLAKE** — page has the §6U.4 loading state; 5.1.2 just needs to wait for the table. Test-timing
  fix, no product finding.
- **FINDING (LOW-MED)** — page has NO loading state; a not-yet-provisioned / slow-fetch residency
  page shows a heading over nothing. Report it (the §6U.4 graceful state is missing) — scoped fix
  after.

## Constraints
- READ-ONLY. Inspect the page + component + test source; no edits, no runs that write.
- Keep 5.2.1 / 5.5.3 classified as accepted timeout flakes (not part of this check).
- The 5.1 DB provisioning proof (test 1) is NOT in question — this is only about the residency
  page's render behavior (test 2).

## Report back (paste inline)
1. Does the data-residency page render a §6U.4 "Residency information loading" (or skeleton) when
   rows aren't ready — or nothing (heading over void)?
2. What 5.1.2 asserts + whether it waits through a loading state.
3. Classification: FLAKE (test-timing) or FINDING (missing loading state). Confirm 5.1 test-1 DB
   proof is unaffected.
