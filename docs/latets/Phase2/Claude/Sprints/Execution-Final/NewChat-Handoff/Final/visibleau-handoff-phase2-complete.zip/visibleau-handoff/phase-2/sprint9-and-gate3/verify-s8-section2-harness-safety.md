# VERIFY S8 SECTION 2 — harness DB safety + owner-seed re-break mapping (read-only)

## Why
Section 2 passed (172 green, 5 re-break REDs). Two things to confirm before we trust it as a
re-runnable guard — both READ-ONLY, no edits:

1. **DB SAFETY (important):** the integration tests use TRUNCATE-based cleanup and read DATABASE_URL
   from `.env.test.local`. Truncating governance tables is only safe if that URL points at a
   DEDICATED TEST DB — NOT `visibleau` (the dev DB, which holds the MISS FOX org + Metropolitan
   audit rows we've been verifying against) and obviously NOT `visibleau_prod`. If the tests
   truncate the dev DB, re-running them wipes our fixtures.
2. **RE-BREAK #4 mapping:** the report says skipping the owner-seed produced "2 RED (acceptedAt +
   isActive assertions)" — but acceptedAt/isActive are INVITE-lifecycle fields (2.6), while the
   owner-seed test (2.8) asserts `role='owner', brand_access=null`. Confirm the owner-seed test
   SPECIFICALLY fails when the owner-seed is skipped (not just that some other test failed).

## Task — READ ONLY

### 1 — Which DB does the integration harness target?
```bash
cd c:/startup/VisibleAU/src
# What URL does .env.test.local point at? (redact password; we only need the DB NAME + host)
grep -i "DATABASE_URL\|POSTGRES\|DB_NAME" .env.test.local 2>/dev/null | sed -E 's/:[^:@]*@/:****@/'
# What DB name does that resolve to — visibleau, visibleau_prod, or a distinct test DB?
# Also: does the integration test file hardcode/override any connection, or trust .env.test.local?
grep -n "DATABASE_URL\|\.env\.test\|connectionString\|new Pool\|postgres(" \
  tests/integration/governance/s8-governance-db.integration.test.ts \
  tests/phase2/sprint4/helpers/test-db.ts 2>/dev/null | head
# And confirm the truncate targets — which tables get truncated between tests?
grep -n "truncate\|TRUNCATE\|delete from\|DELETE FROM" \
  tests/integration/governance/s8-governance-db.integration.test.ts \
  tests/phase2/sprint4/helpers/test-db.ts 2>/dev/null | head
```
REPORT: the DB NAME `.env.test.local` targets (name only, redact creds). CLASSIFY:
- **SAFE** — a dedicated test DB (e.g. `visibleau_test`), distinct from `visibleau` and
  `visibleau_prod`. Truncation is fine.
- **UNSAFE** — it points at `visibleau` (dev) or `visibleau_prod`. Then every integration run
  truncates governance tables in a DB we care about → the MISS FOX/Metropolitan fixtures get wiped.
  This is a FINDING: the integration harness needs its own test DB. (Do NOT fix here — report it; the
  fix is a one-time test-DB setup + pointing `.env.test.local` at it.)

> If UNSAFE and the tests were already run against the dev DB, note whether the dev-DB governance
> fixtures (MISS FOX org, Metropolitan audit_trail rows) still exist:
> ```bash
> psql "$DEV" -c "SELECT count(*) FROM audit_trail;" 2>/dev/null
> psql "$DEV" -c "SELECT count(*) FROM organizations WHERE name ILIKE '%growth%' OR name ILIKE '%agency%';"
> ```
> (Just to know if a re-run already cost us the fixtures — informational.)

### 2 — Owner-seed re-break maps to the owner-seed test
```bash
# The owner-seed test (2.8) — what does it assert?
grep -n "owner\|role\|brand_access\|is_active\|acceptedAt\|accepted_at\|isActive" \
  tests/integration/governance/s8-governance-db.integration.test.ts | grep -iE "owner|role|brand_access|provision" | head
```
Confirm the 2.8 owner-seed test asserts `role='owner'` (and brand_access=null) and that THIS test
is the one that goes RED when the owner-seed is skipped — not (only) an invite-lifecycle test that
happens to share a fixture. If re-break #4 actually tripped the invite test (acceptedAt/isActive)
and NOT the owner-seed assertion, then the owner-seed test isn't actually guarding the owner-seed →
note as a weak-guard finding (the owner-seed provisioning test needs to assert the owner row
directly).

## Constraints
- READ-ONLY. No edits, no truncation triggered, no test runs that write. Just inspect config + test
  source. Redact DB credentials (show DB name + host only).
- Do NOT fix the harness DB here if UNSAFE — report it; the fix is a scoped one-time setup.

## Report back (paste inline)
1. The DB name `.env.test.local` targets + SAFE/UNSAFE classification (+ whether dev-DB fixtures
   survive, if UNSAFE and already run).
2. What the 2.8 owner-seed test asserts, and whether it (specifically) is what fails on re-break #4
   — or whether #4 only tripped the invite test (weak-guard finding).
