# VERIFY S8 SECTION 3 — notifications nav-orphan (real bug or by-design?) + two-migration-file check (read-only)

## Why
Section 3 passed (33 tests, 22 QA, 6 re-breaks). Two things to confirm before closing — both
READ-ONLY:

1. **The nav guard's FIRST real catch was waived.** `/settings/notifications` has no sidebar entry;
   the build added a `NAV_WAIVER` calling it "per-user prefs, by design." But this is EXACTLY the
   nav-orphan class that shipped 4 sprints running (S5→S8) — and "by design" is the kind of claim
   that's been wrong before. Confirm against canon whether notifications is INTENDED to be unlinked,
   or whether the waiver is masking the 5th instance of the bug.
2. **Two S8 governance migration files exist** (`0021_phase2_sprint8_governance.sql` AND
   `sprint-8-tables.sql`). That's unusual — confirm they're not overlapping/duplicate/one-stale.

## Task — READ ONLY

### 1 — Is /settings/notifications a real orphan or by-design?
```bash
cd c:/startup/VisibleAU/src
# Does the notifications page exist + what is it?
test -f "app/(auth)/settings/notifications/page.tsx" && head -40 "app/(auth)/settings/notifications/page.tsx"
# Is notifications referenced in the sidebar at all (even commented/conditionally)?
grep -rn "notification" components/ app/ | grep -iE "sidebar|nav|account_items|href" | head
# Is there ANOTHER entry point to it (a bell icon in the top bar, a profile menu, a settings index)?
grep -rn "notifications\|/settings/notifications\|Bell\|notification" components/ app/\(auth\)/ | grep -iE "href|Link|onClick|route|push" | grep -i notif | head
```
Then check canon:
```bash
cd /home/claude/s8/visibleau-handoff/phase-2 2>/dev/null || cd -
# Does the PROTOTYPE show notifications in the sidebar/nav, or is it deliberately unlinked?
grep -niE "notification|Bell|notif" prototype/visibleau-phase2-prototype-FIX17.jsx 2>/dev/null | head
# Does the LLD mention a notifications settings page + how it's reached?
grep -niE "notification.*setting|settings.*notification|notification.*nav|notification.*page|per-user pref" lld/visibleau-phase2-LLD-v8.70.md 2>/dev/null | head
```
CLASSIFY:
- **BY-DESIGN (waiver valid)** — canon shows notifications reached via a NON-sidebar entry point (a
  top-bar bell, a profile/account menu, a settings landing page) OR canon explicitly says it's not a
  standalone nav item. Then the NAV_WAIVER is correct — but the guard should assert the ACTUAL entry
  point exists (a waiver that just excludes it, with no alternative path asserted, means the page
  could become truly unreachable and the guard wouldn't notice).
- **REAL ORPHAN (finding)** — the page exists, has NO entry point anywhere (no sidebar, no bell, no
  profile menu, no settings index), and canon shows it SHOULD be linked. Then the waiver is masking
  the 5th nav-orphan; REPORT as a finding (add the nav entry, don't waive).
- **NOT AN S8 CONCERN** — notifications is a Phase-1/pre-existing page unrelated to S8 governance and
  its linking is out of this sprint's scope. Note it as carried, not an S8 finding.

### 2 — Why two migration files?
```bash
cd c:/startup/VisibleAU/src
# What does each contain — do they create the SAME governance tables (duplicate) or different?
grep -iE "CREATE TABLE( IF NOT EXISTS)?" db/migrations/0021_phase2_sprint8_governance.sql | sed -E 's/.*(TABLE( IF NOT EXISTS)?) *"?([a-z_]+)"?.*/\3/' | sort
echo "---"
grep -iE "CREATE TABLE( IF NOT EXISTS)?" db/migrations/sprint-8-tables.sql | sed -E 's/.*(TABLE( IF NOT EXISTS)?) *"?([a-z_]+)"?.*/\3/' | sort
# Which one is in the drizzle journal / actually applied? Are both tracked, or is one orphaned?
ls -la db/migrations/ | grep -iE "sprint.?8|0021"
cat db/migrations/meta/_journal.json 2>/dev/null | grep -iE "0021|sprint" | head
```
CLASSIFY:
- **COMPLEMENTARY** — the two files create DIFFERENT objects (e.g. one tables, one policies/indexes)
  and both are tracked/applied. Fine — note the split.
- **DUPLICATE/STALE (finding)** — both create the SAME governance tables (the 4 governance tables
  appear in both), meaning one is a stale/duplicate that could diverge or double-apply. Or one is
  NOT in the drizzle journal (orphaned file that won't run via migrate, only via manual psql — which
  is how F1 happened: applied to dev manually, missed on prod). REPORT which, as a finding.

## Constraints
- READ-ONLY. Inspect files + canon; no edits, no migrations run.
- For (1), the key question is whether an ALTERNATIVE entry point exists + canon's intent — a waiver
  is only valid if the page is genuinely reachable another way (or genuinely meant to be standalone).

## Report back (paste inline)
1. notifications: does it have any entry point (sidebar/bell/profile/settings-index)? what does
   canon show? Classification: by-design / real-orphan-finding / not-S8.
2. two migration files: same tables or different? both journaled/applied? Classification:
   complementary / duplicate-or-stale-finding (say which file + why).
