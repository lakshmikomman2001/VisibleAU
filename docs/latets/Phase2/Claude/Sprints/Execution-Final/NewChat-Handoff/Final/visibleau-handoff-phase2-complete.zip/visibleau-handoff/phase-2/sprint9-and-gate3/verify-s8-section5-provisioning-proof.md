# VERIFY S8 SECTION 5 — the 5.1 F6/F2 proof (did it actually prove it?) + ensureUser stale-org (read-only)

## Why
§5 is 13/13 green, but two things must be confirmed before the track is closed — both READ-ONLY:

1. **5.1 was the ENTIRE REASON §5 existed** — the only test that can prove F6/F2 provisioning
   actually FIRES (owner-seed + 7 residency rows on real org-create), which §2 could only
   source-assert. The report showed 5.1 passing, but the listed 5.1 fixes were all test-infra
   (stale-org cleanup, locator strict-mode) — NOT evidence the assertion holds. And the report's
   summary item #4 (the F6/F2 verdict) + re-break #1 (comment out owner-seed → 5.1 RED) were not in
   the paste. Confirm 5.1 proves what it claims — otherwise it may be green for the wrong reason
   (reading rows a PRIOR run's provisioning left, or the fixture seeding them). This is the exact
   "test passes without proving its claim" class we've caught 3× this session.
2. **The recurring 5.2–5.4 root cause was `ensureUser` returning an existing user WITHOUT updating
   organizationId** (tests patched it with force-updates). Confirm that's a test-fixture artifact,
   not a real code smell that could bite org-switch / multi-org paths.

## Task — READ ONLY (inspect test + source; no runs that write, no edits)

### 1 — Does 5.1 actually assert provisioning's OUTPUT, without seeding it?
```bash
cd c:/startup/VisibleAU/src
# Show the 5.1 test body — the org-create call + the assertions:
grep -rn "5.1\|provisioning\|afterCreateOrganization\|owner.*seed\|residency.*7\|data_residency_log\|org_members" tests/e2e/ 2>/dev/null | grep -iE "5\.1|provision|residency|owner" | head
# The actual 5.1 spec file — read the create + assert + cleanup:
ls tests/e2e/ | grep -iE "provision|5.1|governance|section5|org.?create"
```
Open the 5.1 test and CONFIRM, explicitly:
- It creates the org via the REAL flow (sign-up / create-organization the app uses — the one that
  triggers `afterCreateOrganization`), NOT `db.insert(organizations)` directly.
- It asserts the **owner org_members row** + **7 data_residency_log rows** by READING the DB, and
  the test does **NOT** itself insert those rows anywhere (no `insert(orgMembers)` /
  `insert(dataResidencyLog)` / `recordDataResidency(` call in the test/fixture for this org).
- Cleanup deletes a UNIQUE per-run org (so it's not re-reading a prior run's rows — the org name/id
  is fresh each run).
REPORT verbatim: the create call, the two assertions, and grep-proof that the test doesn't seed the
owner/residency rows. CLASSIFY:
- **VALID PROOF** — real create + DB-read assertion + no test-seeding + fresh per-run org. 5.1 truly
  proves F6/F2 fire.
- **WEAK/INVALID** — the test seeds the rows, or asserts against a reused org, or creates via direct
  insert (bypassing the provisioning hook). Then 5.1 does NOT prove F6/F2 → FINDING (the proof is
  hollow; fix it to drive real provisioning).

### 2 — Did re-break #1 actually fire? (the most important re-break in the track)
The report didn't show it. Re-run JUST the provisioning re-break, read-only-ish (source revert
guaranteed):
```bash
# Confirm where the owner-seed lives so the re-break targets the real code:
grep -n "insert(orgMembers)\|role: *\"owner\"\|recordDataResidency\|brandAccess: null" lib/auth/server.ts | head
```
Then (only if safe in a throwaway manner): comment out the owner-seed insert in
`afterCreateOrganization`, run ONLY the 5.1 spec, confirm it goes **RED** (owner row absent after a
real create), then REVERT and confirm GREEN. Same for the `recordDataResidency` call → 7-rows
assertion RED → revert. If you'd rather not touch source, at minimum REPORT whether the earlier run
did this and the result. The point: 5.1 must FAIL when provisioning is broken, or it isn't guarding
provisioning.

### 3 — Is `ensureUser` stale-org a test artifact or a real smell?
```bash
grep -rn "ensureUser\|function ensureUser\|organizationId" tests/e2e/**/helpers/* 2>/dev/null | head
# Is ensureUser a TEST helper (fixture-only) or does it exist in app source?
grep -Rln "ensureUser" lib/ app/ 2>/dev/null
```
CLASSIFY:
- **TEST-ONLY** — `ensureUser` is a test fixture helper; real sign-up/org-create doesn't reuse a
  user across orgs this way. The stale-org was a fixture reuse quirk; force-update is the correct
  fixture fix. No product concern.
- **REAL CODE SMELL** — `ensureUser` (or the pattern) exists in app source and a user's
  organizationId can go stale on a legitimate flow (org-switch, multi-org membership). Then note it
  as a finding to look at (does the app correctly set organizationId when a user acts in a
  different org?). Report which.

## Constraints
- READ-ONLY inspection + (optionally) the source re-break for #2 with guaranteed revert. No other
  edits, no truncate, scoped cleanup only.
- If 5.1 turns out not to prove F6/F2 (seeds rows / reused org / direct insert), that's a FINDING —
  report, don't paper over. This is the one test whose validity the whole §5 rationale rests on.

## Report back (paste inline)
1. 5.1: the create call + the 2 assertions + grep-proof the test doesn't seed the rows + fresh-org-
   per-run. Classification VALID / WEAK.
2. Re-break #1 result: does 5.1 go RED when owner-seed / residency call is removed? (or report the
   earlier run's result). The F6/F2 functional verdict.
3. ensureUser: test-only or real smell (which, + finding if real).
