# Claude Code — Park the `config:validate` CI step (deferred until config is seedable)

Canon check resolved Finding 1: a **valid config is NOT seedable by end of Sprint 1** (§5.5 seeds only
`provider-market-capabilities` + `metric-quality-gates`; the sampling policy, active config bundle, and
prompt_pack_coverage that `config:validate` also requires are seeded in LATER sprints). `config:validate`
requires those rows to EXIST (it's a strict validator, no fallback pass), so it legitimately cannot pass yet —
and there's no Sprint 1 acceptance criterion requiring it to. So **defer the CI step (Option b)** — but park it
cleanly so it's ready to activate, not forgotten.

> Small, surgical change: comment out the one step we added, with a clear explanatory TODO. Do NOT remove it
> (we want it ready). Do NOT seed fake rows. Do NOT change other CI steps.

## STEP 1 — Comment out the step we added, with a clear TODO
In `.github/workflows/ci.yml`, the step added in the `test` job:
```yaml
      - name: Validate Phase 2 config
        run: pnpm visibleau config:validate --market AU_EN --locale en-AU
```
Replace it with a commented-out version + a TODO that states WHY it's parked and WHAT unblocks it:
```yaml
      # TODO(phase2): Activate Phase 2 config validation in CI once the config is fully seedable.
      # config:validate (LLD §7 / 5082) requires an active config bundle + sampling policy +
      # prompt_pack_coverage='complete' + ≥1 enabled provider. Sprint 1 only seeds providers +
      # quality gates (§5.5); the bundle / sampling policy / coverage seeds land in a later sprint.
      # Until those seeds exist (and the CI test DB runs them after db:migrate), this step would
      # fail CI. Uncomment when config is seedable. Do NOT seed placeholder rows just to pass.
      # - name: Validate Phase 2 config
      #   run: pnpm visibleau config:validate --market AU_EN --locale en-AU
```
(Match the file's real indentation/style. Keep it in the `test` job — that's the job with the Postgres service
+ DATABASE_URL, which is where it'll need to run once activated.)

## STEP 2 — Verify
```bash
grep -n "config:validate\|TODO(phase2)" .github/workflows/ci.yml
```
- Confirm the step is now commented out (won't run / won't red CI).
- Confirm the TODO clearly explains the dependency + the activation condition.
- Confirm no other CI steps changed and the YAML is still valid (the commented block must not break parsing —
  it's all `#` comment lines, so it won't, but eyeball indentation).

## REPORT
- Confirm the step is parked (commented) with the TODO, in the `test` job.
- Confirm CI will now pass (this step no longer runs).
- Confirm no other CI changes.

---

## FOR SRI — track the activation (bank this, not a Claude Code task)
Add to your canon/notes so this gets turned on at the right time:

> **Deferred CI step — `config:validate`:** Written and parked (commented) in `.github/workflows/ci.yml` `test`
> job. **Activate when** the config is fully seedable in CI — i.e. when seed scripts exist for `sampling_policies`,
> `config_bundle_cache` (an `is_active=true` bundle), and `prompt_pack_coverage='complete'`, AND the CI test
> job runs those seeds after `db:migrate`. At that point: uncomment the step. (LLD §7/5082 asks for it in
> Sprint 1, but the config it validates isn't complete until later — an LLD sequencing imprecision; the step's
> activation should track config-seed-completeness, not Sprint 1.)

> **LLD note (optional):** Consider annotating LLD §7 so the next reader knows the `config:validate` CI step is
> intentionally deferred until config seeds are complete — avoids a "why is this red / missing?" confusion.
