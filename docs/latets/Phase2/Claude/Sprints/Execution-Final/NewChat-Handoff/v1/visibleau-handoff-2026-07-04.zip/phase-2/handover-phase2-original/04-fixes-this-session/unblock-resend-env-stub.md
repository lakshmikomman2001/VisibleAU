# Claude Code — UNBLOCK: add RESEND_API_KEY stub so the Inngest serve endpoint syncs

The Inngest dev server can't sync — `PUT /api/webhooks/inngest` returns **500** repeatedly. Root cause confirmed
from the app terminal: `lib/digest/send.ts:3` runs `new Resend(process.env.RESEND_API_KEY)` at **module load**,
and `RESEND_API_KEY` is unset → Resend's constructor throws **"Missing API key"** on import. Because the Inngest
serve route (`app/api/webhooks/inngest/route.ts`) imports every function — incl. `weekly-digest-cron.ts` →
`lib/digest/send.ts` — that one throw crashes the whole endpoint, blocking ALL functions (incl.
`triggerValidationReaudit`).

**This is the QUICK UNBLOCK only** (env stub) so the task-completion loop can be tested now. A proper code fix
(lazy Resend instantiation + sweep for other eager `new X(process.env.KEY)` modules) is tracked separately — do
NOT do the code fix here.

## STEP 1 — Add the stub env var
Add to `.env.local` (and `.env.dev` if the app reads that locally — match wherever `INNGEST_EVENT_KEY=local-stub`
already lives):
```
RESEND_API_KEY=re_local_stub_for_dev
```
- The `re_` prefix matters (Resend may validate the key shape). If `re_local_stub_for_dev` is still rejected at
  construction, use a longer `re_...` placeholder. Do NOT use a real key — this is a local stub.
- Confirm the var is on its own line, no quotes needed, and that `.env.local` isn't overridden by another env
  file loaded later.

## STEP 2 — Restart the Next.js app
`RESEND_API_KEY` is read at module load, so the running app won't pick it up until restarted.
- Stop the `:3000` dev server (Ctrl+C) and restart it (the project's dev command).
- Leave the **Inngest dev server** running on `:8288` (it polls the serve endpoint every few seconds).

## STEP 3 — Verify the sync is now green (this is the acceptance check)
After restart, confirm ALL of:
1. **App terminal:** the repeated `PUT /api/webhooks/inngest 500 ... Missing API key` errors **STOP**. (If a 500
   persists, capture the NEW stack trace — it likely means another module also instantiates a client with an
   env key at load time, e.g. Stripe/Anthropic. Report it; that's the next domino, not this fix.)
2. **Inngest dashboard → Apps** (`http://localhost:8288/apps`): the red **"Error"** badge clears; the app shows
   **"Synced"** (not "Not Synced").
3. **Inngest dashboard → Functions:** the synced functions are listed — confirm **`triggerValidationReaudit`**
   appears (and `weekly-digest-cron`, the others).

## STEP 4 — Behavioural test: the completion loop
With the sync green, on the Bondi kanban
(`/brands/8f59b2a2-6aa0-4318-9848-b33ed520ca36/workflow/tasks`):
- Drag a task to **Done** → confirm `POST .../complete` returns **200** (no 401).
- On the Inngest dashboard (**Runs** / **Events**): confirm the **`task/completed`** event fires AND
  **`triggerValidationReaudit`** triggers.
- EXPECTATION: `triggerValidationReaudit` has `step.sleep('14 days')` → it will **start then enter a
  sleeping/scheduled state**. That sleeping state IS success — you're verifying the event fired + the function
  triggered, not that the re-audit completes now.

## REPORT
1. Confirm `RESEND_API_KEY=re_local_stub_for_dev` added to `.env.local` (+ `.env.dev` if applicable).
2. After restart: are the `PUT /api/webhooks/inngest` 500s gone? (If not, paste the new stack trace.)
3. Inngest Apps = Synced (Error badge cleared)? Functions lists `triggerValidationReaudit`?
4. Drag-to-Done: `/complete` → 200 (no 401)? `task/completed` fired? `triggerValidationReaudit` triggered (then
   sleeping)?
5. Note: the proper code fix (lazy Resend + sweep other eager-instantiation modules) is still pending — this was
   the env-stub unblock only.
