# VisibleAU — Consolidated Go-Live & Hardening Checklist

**Compiled:** end of Sprint 2 close-out session (audit/start saga + full RLS/tenant-isolation remediation).
**Purpose:** a single tracked record of everything that must land before prod deploy, plus what's still open in
the codebase. Nothing here should be actioned blindly — each item links back to context. Check items off as they
land; this doc should be the source of truth until it's all closed, then retire it.

---

## 🔴 CRITICAL — must be done before real prod traffic (security-load-bearing)

### 1. Get the 3 hand-applied RLS/security migrations into the tracked migration pipeline
These were applied directly via `psql` against BOTH `visibleau` (dev) and `visibleau_prod` during this session's
security remediation. They are correct and verified, but **they exist as ad-hoc SQL, not as tracked
drizzle-kit/migration-pipeline entries.** A fresh prod deploy or environment rebuild will NOT reproduce them unless
they're formalized. This is a drift risk — if prod is ever rebuilt from the migration set alone, RLS protection
would be silently absent again.
- [ ] `scripts/db/rls-missing-tables.sql` (14 tables — RLS policies added, `org_isolation`, `FOR ALL + USING +
      WITH CHECK`, direct-org + brand-join forms)
- [ ] `tier1a-app-role.sql` (creates `visibleau_app` role: `NOSUPERUSER NOBYPASSRLS`, least-privilege DML grants,
      `FORCE ROW LEVEL SECURITY` on the 22 tenant tables)
- [ ] `rls-with-check.sql` (adds missing `WITH CHECK` to `content_drafts`, `remediation_tasks`, and — critically —
      enables RLS from scratch on `subscriptions`, which had NONE before this session)
- **Action:** convert each into a proper numbered migration file in the project's migration system so
  `drizzle-kit migrate` (or equivalent) reproduces them on any fresh environment. Confirm idempotency is preserved.

### 2. Deployed prod app must connect as the non-superuser role, not `postgres`
Tier 1A created `visibleau_app` (NOSUPERUSER, NOBYPASSRLS) and switched the **local** `.env.local` to use it for
the user-request path, keeping `serviceDb`/service_role for Inngest. **The deployed prod environment's
`DATABASE_URL` has NOT been changed** — this was a local-only fix, deliberately scoped that way.
- [ ] Set the deployed prod `DATABASE_URL` to use `visibleau_app` (or the prod-equivalent constrained role) for the
      API/user-request connection.
- [ ] Set a SEPARATE prod service-role connection string for Inngest (mirroring the local `serviceDb` split).
- [ ] **Verify after deploy:** repeat the Tier 1A verification against prod — connect as the prod app role,
      confirm `rolsuper=false, rolbypassrls=false`, confirm RLS enforces (no-context query → 0 rows).
- **Why critical:** without this, prod would repeat the EXACT bug this session found — the app bypassing all RLS
  via superuser, even though the policies are correctly in place. The policies are necessary but not sufficient;
  the connecting role is what makes them real.

### 3. Prod Inngest — real Cloud keys + deployed serve endpoint
The local fixes this session (`INNGEST_DEV=1`, the `isDev` client fix) make LOCAL dev work against the local
Inngest dev server. **Real production Inngest is the opposite configuration** and has not been set up.
- [ ] Obtain real `INNGEST_EVENT_KEY` + `INNGEST_SIGNING_KEY` from the Inngest Cloud dashboard.
- [ ] Set them in the deployed prod environment (NOT `.env.local`).
- [ ] Ensure `INNGEST_DEV` is **unset/false** in the deployed prod environment (opposite of local).
- [ ] Deploy the app and register its serve endpoint (`/api/webhooks/inngest`) with Inngest Cloud so events
      actually deliver in production.
- [ ] Verify: complete a task / generate a draft / let a scheduled audit fire in a staging-prod-like environment
      and confirm the Inngest Cloud dashboard shows the runs.
- **Why critical:** without this, every event-driven feature (drafts, re-audits, scheduled audits, bulk re-audit)
  silently fails in real production — likely surfacing as the same class of bug found and fixed locally this
  session (unhandled/hardened sends), just against Cloud instead of the local dev server.

### 4. Clean up test data created in the PROD database during this session's smoke-testing
The prod DB was deliberately used for schema-migration smoke-testing and for exercising Sprint 2 flows on real
prod data. Real rows were created:
- [ ] Test audits (at least #131, #132, #133 — the scheduled-cron fix, and the bulk-reaudit fix's two audits)
- [ ] The bulk re-audit operation row from testing `bulk-reaudit-orchestrate`
- [ ] Test remediation tasks + content_drafts created while testing the Workflow loop on Sydney Plumbing / Bondi
      Plumbing / Marrickville Dental against prod
- [ ] Any test brands created solely for this testing that shouldn't be in the production dataset
- **Action:** identify test-created rows (via `triggered_by` values, creation timestamps during the testing window,
  or brand names) and remove them before real customers see the data. Confirm with a query pass before deleting —
  don't blind-delete against prod.

---

## 🟡 IMPORTANT — should be done before go-live, not blocking further dev work

### 5. Finish the Sprint 2 automated test track — Section 5 (QA)
Sections 1-4 are complete and green (Backend Unit, Backend E2E, Frontend Unit, Frontend E2E — 1237+ tests). Section
5 (QA — batch-script run per the test checklist) is the last piece: run each feature's batch script, confirm it
closes & relaunches BOTH backend + frontend, exercises the feature with real test data, watched end-to-end.
- [ ] Run Section 5 per `phase2-sprint-2-test-checklist.md`.
- [ ] Confirm against **dev DB**, not prod (same DB-safety discipline as Sections 2 & 4).

### 6. LLD version bump — v8.69 → v8.70 collision fix
The audit/start canon correction was mislabelled as v8.69 (already taken by the prior session's TC-01
task-creation fix). The prompt for this exists and is ready: `fix-lld-version-collision-v8.70.md`.
- [ ] Apply the version bump (both LLDs, CHANGELOG re-labelled, inline `[CORRECTED]` stamps updated to v8.70).
- [ ] Update the stored canonical-version note (currently says "v8.68" — now several versions stale).

### 7. `e2e-rls-fk-services.integration.test.ts` — fix the DB-mismatch config
Diagnosed as a database-mismatch (test pointed at the wrong DB — `visibleau` vs `visibleau_prod`), not a code bug.
It's been "pre-existing" across several test runs; worth actually fixing the test's DB target so it stops being a
permanent asterisk on an otherwise-green suite.
- [ ] Fix the test config to point at the correct DB.
- [ ] Confirm the 34 timeout failures disappear (or re-diagnose if they don't — don't assume the mismatch is the
      whole story until confirmed).

### 8. `llm_response_cache` RLS-disabled — confirm it's genuinely safe
Left RLS-disabled during the 14-tables fix as "system cache, no org scoping column." Quick sanity check, not
assumed:
- [ ] Confirm cached entries never contain org-specific/tenant content that could leak between orgs via a shared
      cache key (i.e. it's a pure prompt→response cache with no tenant data embedded).
- [ ] If confirmed safe: document the decision in the LLD/schema notes so it's not re-flagged as a false positive
      later. If NOT safe: scope it (org-keyed cache or org column + RLS).

---

## 🟢 MINOR — doc hygiene, no functional risk, fix opportunistically

### 9. Doc-drift notes accumulated this session
- [ ] `lib/email/client.ts` is a **nodemailer wrapper**, not the "Phase 1 Resend singleton" canon describes —
      update the LLD/handover reference so a future rebuild doesn't go looking for a Resend client that isn't there.
- [ ] `cross_prompt_impact` column **does not exist** in the schema — LLD specifies it as the Action Center sort
      key + index; `expectedImpactScore` (HIGH/MEDIUM/LOW text) is what's actually used. Either build the column
      later or correct the canon reference.
- [ ] `organizations.tier` is read directly in at least two places (`run-audit.ts` Path A; the brand-page nav
      tier-gate) where canon says `subscriptions.tier` is sole source-of-truth. Confirmed NOT to cause zero-engine
      bugs (the resolver normalizes any input), but worth a one-time confirm: is `organizations.tier` guaranteed
      synced from `subscriptions.tier` (safe as a read-only mirror), or can it drift? If it can drift, the 2 reads
      should switch to the canonical source (small, low-risk fix either way).

### 10. SPRINT8 tracking item (already documented, just cross-referencing)
- [ ] `getOrgProgressSummary` (dashboard aggregate) and the Action Center aggregate currently scope to ALL org
      brands, not `brand_access`-restricted accessible brands (deferred — `brand_access` is stored-but-inert
      app-wide until Sprint 8 builds `assertBrandAccess`). When Sprint 8 retrofits the S1-S7 routes, add these two
      aggregates to that same retrofit checklist. (See `SPRINT8-tracking-dashboard-brand-access-scoping.md`.)

---

## ✅ CONFIRMED DONE this session (for reference — no action needed)

- Sprint 2 Workflow Completion Engine loop verified end-to-end on real data (lift 80→88)
- `audit/start` canon-level bug killed across 4 functions (reaudit, scheduled cron, bulk reaudit, workflow
  scheduler) + the LLD corrected at the root (D-05, now v8.70-pending-bump)
- Resend lazy-instantiation fix (prod-blocker) — can't crash the Inngest serve endpoint anymore
- Complete-route idempotency + decoupled event fix (self-heals stuck tasks, never silently drops re-audit events)
- Draft generation, view-drafts nav, brand-page Workflow nav (Finding 1 + 3), dashboard aggregate, Action Center
  aggregate — all built, verified, tested
- **Full cross-tenant security remediation** (the big one):
  - Tier 2 — `withRlsContext` transaction wrapper (fixed RLS context lost across the connection pool)
  - Tier 1A — non-superuser `visibleau_app` DB role (fixed: app was connecting as `postgres` superuser, bypassing
    ALL RLS on ALL traffic)
  - 14 tenant tables given RLS policies that had none (including `subscriptions`, which had ZERO RLS)
  - WITH CHECK added to 3 write-path-hole policies (`content_drafts`, `remediation_tasks`, `subscriptions`)
  - Tier 3 — explicit org/brand ownership checks added to 10 routes as defense-in-depth (34 routes surveyed, 22
    already had checks, 1 global correctly excluded)
- Sections 1-4 of the Sprint 2 automated test track (1237+ tests, backend + frontend, unit + E2E)

---

## Suggested order to close out the 🔴 CRITICAL section

1. **Items 1 + 2 together** (migrations → pipeline, prod role) — these are the two that, if skipped, silently
   reintroduce the exact security hole this session closed. Highest priority.
2. **Item 4** (prod test-data cleanup) — do this before any real customer traffic, independent of the others.
3. **Item 3** (prod Inngest Cloud keys) — needed for the app to function in prod at all, but not a security risk
   like 1/2, so it can follow.

The 🟡 and 🟢 sections can proceed at your normal pace alongside Sprint 3 work — none of them block moving forward.
