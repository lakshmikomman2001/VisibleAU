# Claude Code — BUILD: Content-draft generation entry point (the missing UI path) — Finding (draft side of TC-01)

Sprint 2 manual testing found there is **no working UI path to generate a content draft**. The whole
draft sub-loop (task → Generate draft → editor → approve) is unreachable from the UI. Confirmed behaviour:
- The recommendation detail (Action Center) has Create task / Mark as done / Dismiss — no "Generate draft".
- The Workflow hub "Generate draft" button only **navigates** to `/workflow/drafts` (it does not generate).
- The Content Drafts page (`/brands/[brandId]/workflow/drafts`) shows "No draft yet — Generate draft", but
  clicking it fires **NO** `POST /drafts` request — it changes local UI state (the text disappears) and does
  nothing. No network call, no row created, no Inngest event. Console shows "No Issues" (no error thrown).

Root cause: the backend is fully built (`POST /api/brands/[id]/drafts` emits `draft/generate`;
`generateContentDraft` Inngest fn writes a `content_drafts` row, status 'pending'→'draft'), but the UI never
calls it. Critically, the `draft/generate` event payload is `{ taskId, brandId, orgId, contentFormat }` (LLD
§8.1 / Sprint 2 prompt §8.1) — so generation MUST be initiated **from a specific task**, and the UI gives the
user no way to select a task + format. That's why the buttons are dead: they have no taskId to send.

This is the SAME class as TC-01 (the create-task button that was decorative) — backend exists, UI entry point
missing. Build the entry point.

> **Investigate-first. Report before building if the cause differs from the hypothesis below.** Read, in order:
> - `app/(auth)/brands/[brandId]/workflow/drafts/page.tsx` + its client component (the "No draft yet — Generate
>   draft" empty state — find what the click currently does; confirm it fires no POST).
> - `app/(auth)/brands/[brandId]/workflow/page.tsx` / `workflow-hub-client.tsx` (the hub "Generate draft" button
>   that navigates here — line ~43 was the navigation in testing).
> - `app/api/brands/[id]/drafts/route.ts` (the POST handler — confirm what body it expects: does it take
>   `{ taskId, contentFormat }` and emit `draft/generate`? Does it create the `content_drafts` row as 'pending'
>   first, or does the Inngest fn create it?).
> - `inngest/functions/generate-content-draft.ts` (confirm event name `draft/generate`, payload shape, and that
>   it sets status 'pending'→'draft' on completion).
> - `lib/workflow/content-generator.ts` (the recommendation_key→draft_type translation + selectModel call).
> Report what the POST route actually expects so the UI calls it correctly rather than duplicating logic.

---

## WHAT TO BUILD — a task-driven "Generate draft" action

The user must be able to pick a TASK and generate a draft from it. Provide a real entry point (pick the cleanest
of these that fits the existing structure — report which you chose):

### PREFERRED — "Generate draft" on a task
- Add a **"Generate draft"** action on the **task** (on the task card in the kanban, and/or the task detail if
  one exists). Clicking it calls `POST /api/brands/[brandId]/drafts` with `{ taskId }` (+ a `contentFormat` —
  see below). The server/Inngest path then generates the draft FROM that task.
- This is the most faithful to canon: the `draft/generate` payload is keyed on `taskId`, and the editor's
  "Source action" panel is the task/recommendation the draft came from.

### ALSO WIRE — the drafts-page + hub buttons (don't leave them dead)
- The Content Drafts page empty state ("No draft yet — Generate draft") and the hub "Generate draft" button must
  do something real, not just navigate/toggle local state. Two acceptable options (pick one, report it):
  - (a) They open a **task picker** (a modal/dropdown listing this brand's open/in-progress tasks) → user picks a
    task + format → `POST /drafts` with `{ taskId, contentFormat }`.
  - (b) They are explicitly repositioned as "generate from a task" — i.e. the primary action lives on the task
    (PREFERRED above), and the drafts-page empty state copy points the user there ("Generate a draft from one
    of your tasks") rather than presenting a dead button.
- Do NOT leave a button that looks actionable but fires no request (that's the current bug).

## CONTENT FORMAT (required in the payload)
`draft/generate` needs `contentFormat`. Source it correctly — do NOT hardcode:
- Resolve via `content-format-selector.ts` (§6.4) from the task's gap/recommendation, OR
- Offer the format selector the editor already has (the prototype WF-2 context panel has a Content format
  `<select>`: Wikipedia article / Blog post / FAQ page / Press release) — let the user pick before generating,
  defaulting to the selector's recommended format.
- Whatever the choice, pass a VALID `content_drafts.content_format` enum value (listicle | how_to_guide |
  comparison_article | faq_block | expert_article | case_study | press_release | linkedin_article).

## THE FLOW (end to end)
1. User triggers "Generate draft" from a task (+ chosen/derived format).
2. `POST /api/brands/[brandId]/drafts` with `{ taskId, contentFormat }`. The route (per §9) emits
   `draft/generate` `{ taskId, brandId, orgId, contentFormat }`. (If the route currently expects a different
   body, align the UI to it OR extend the route to accept `{ taskId, contentFormat }` — report which.)
3. A `content_drafts` row exists in status **'pending'** while generating (skeleton/aria-busy on the editor),
   then `generateContentDraft` sets it to **'draft'** on completion.
4. Navigate the user to the editor at `/brands/[brandId]/workflow/drafts/[draftId]` so they see the generated
   draft (or back to the drafts list with the new draft visible). The editor renders title/body + the format
   chip + Approve / Request revision / Dismiss.

## INVARIANTS — do not violate (already canonical)
- `content_drafts.status` enum: **draft | approved | published | rejected** (default 'draft'); the Inngest fn
  uses a transient **'pending'** before 'draft'. Never invent other values.
- `draft_type` uses **underscores** (wikipedia_article); recommendation_key uses hyphens — `content-generator.ts`
  owns the translation table; do NOT do string-equality mapping in the UI.
- Model: generation uses **`selectModel(tier, engine, 'content_draft')`** — never a hardcoded model (it's in the
  Inngest fn already; don't add a hardcoded one in the UI/route).
- **Tier gate:** `content_drafts` is **Growth+ only**. Free/Starter must see a TierGate lock, not a generate
  action. (Bondi/VisibleAU Dev is Agency tier, so generation is allowed for testing.)
- Use the existing shared components (StatusBadge, EmptyState, TierGate, the editor) and design tokens — don't
  invent new UI primitives. Follow ARIA (the format select labelled; the editor textboxes already role="textbox").
- Don't regress: the kanban interaction, the task badges (impact derived from scoreBefore, confidence), the
  complete→re-audit path.

## ⚠️ LOCAL PREREQUISITE (not a code change — note for the tester)
Generation runs through Inngest exactly like the complete→re-audit loop. The Inngest dev server must be running
(`START-INNGEST.bat` on :8288) and the app synced, or `draft/generate` won't be delivered. (Same setup that
unblocked the task-completion loop — INNGEST_DEV=1 + the Resend stub are already in `.env.local`.)

## VERIFY (behavioural — actually generate a draft on screen)
On Bondi Plumbing (Agency tier, so the gate allows it):
1. From a task (e.g. the "Your AU local directory listings are incomplete" task in Open), trigger "Generate
   draft" (+ a format). Confirm a **`POST /api/brands/8f59b2a2-.../drafts`** fires (DevTools Network) and returns
   2xx — NOT zero requests like today.
2. Inngest dashboard (:8288 → Runs): the **`draft/generate`** event fires and **`generateContentDraft`** runs
   and completes (drafts are on-demand, concurrency 5 — finishes in seconds, not delayed like the 14-day reaudit).
3. A `content_drafts` row exists for this brand with `task_id` set, `status='draft'` (passed through 'pending'),
   an underscore `draft_type`, a valid `content_format`, and a non-empty `body` (real LLM content in prod mode).
4. The editor at `/brands/8f59b2a2-.../workflow/drafts/[draftId]` renders: format chip matching the row's
   content_format, the generated title/body (editable), and Approve / Request revision / Dismiss. (The
   "Expected impact"/"Confidence" in the context panel should reflect the task's real data, not hardcoded
   placeholders — flag if they're static.)
5. The drafts list page now shows the draft (no longer "No draft yet"); the hub/empty-state "Generate draft"
   buttons now do something real (picker or a clear pointer to the task action) — no dead buttons remain.
6. Free/Starter gate check (if quick): a non-Growth brand shows a TierGate lock instead of a generate action.
7. Full Sprint 2 suite still green.

## REPORT
- What the drafts-page + hub "Generate draft" actually did before (confirm: no POST fired, local state only).
- What the POST `/drafts` route expects (body shape; whether it already emits `draft/generate`; whether it
  creates the 'pending' row or the Inngest fn does) — and any route/Inngest change you had to make.
- Which entry-point design you built (task action + picker, or task action + repointed empty state) and why.
- How contentFormat is sourced (selector vs content-format-selector derivation).
- Behavioural confirmation: a draft generated from a task, POST 2xx, `draft/generate` fired,
  `generateContentDraft` ran, row in 'draft' with correct task_id/draft_type/content_format/body, editor renders
  it, no dead buttons left, tier gate correct.
- Confirm invariants held (status enum + 'pending', underscore draft_type, selectModel, Growth+ gate) + suite green.
