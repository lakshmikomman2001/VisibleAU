# Claude Code — CLEANUP (test data) + BANK: fix the contaminated Agency test brand; log domain-normalization as pre-launch

Two actions: (1) fix the misconfigured Agency test brand NOW so Agency-tier testing uses clean data, and (2) add the
domain-variant SoV bug to the go-live checklist as a real pre-launch fix (do NOT fix it now — just log it).

## Background (from diagnosis)
- The Agency-tier brand "Agency SEO Sydney" (brand_id `026acf75-188f-4a9f-9126-6ed2fb324f91`) is a **copy of the
  Bondi Plumbing brand** with the WRONG domain variant: `brands.name = "Bondi Plumbing"`, `brands.domain =
  bondiplumbing.com` (no .au), under org "Agency SEO Sydney". This is contaminated test data.
- Because its domain (`bondiplumbing.com`) doesn't match the cited sources (`bondiplumbing.com.au`), the brand's
  own .com.au variant appears as a "competitor" in its SoV donut. The Bug-1 fix is working correctly (exact-string
  domain exclusion); the brand data is just wrong.
- The Competitive Benchmark tier-gating PASSED (Agency → "No competitor data available yet"; Growth → locked
  teaser) — no fix needed there.

## ACTION 1 — Clean up the Agency test brand (do now)
Give this Agency test brand a DISTINCT, correct identity so it's not a Bondi clone:
- Update `brands` row `026acf75-188f-4a9f-9126-6ed2fb324f91`:
  - `name` → a distinct name (e.g. "Agency SEO Sydney" to match its org, or another clearly-non-Bondi name).
  - `domain` → a distinct domain (e.g. `agencyseo.com.au` — NOT any bondiplumbing variant).
  - (Keep it Agency-tier, keep its org, keep its region — only fix name + domain so it's a real distinct brand.)
```bash
# Confirm current state first:
psql "$DEV_DATABASE_URL" -c "SELECT id, name, domain, organization_id FROM brands WHERE id='026acf75-188f-4a9f-9126-6ed2fb324f91';"
# Update to a distinct identity (adjust name/domain as preferred):
psql "$DEV_DATABASE_URL" -c "UPDATE brands SET name='Agency SEO Sydney', domain='agencyseo.com.au' WHERE id='026acf75-188f-4a9f-9126-6ed2fb324f91';"
```
- **Clear the stale SoV/visibility rows** generated under the wrong domain (they're contaminated), so a fresh audit
  regenerates clean data:
```bash
# Remove this brand's stale visibility rows (they were computed with the wrong domain):
psql "$DEV_DATABASE_URL" -c "DELETE FROM share_of_voice_snapshots WHERE brand_id='026acf75-188f-4a9f-9126-6ed2fb324f91';"
psql "$DEV_DATABASE_URL" -c "DELETE FROM visibility_trends WHERE brand_id='026acf75-188f-4a9f-9126-6ed2fb324f91';"
psql "$DEV_DATABASE_URL" -c "DELETE FROM query_fan_out_results WHERE brand_id='026acf75-188f-4a9f-9126-6ed2fb324f91';"
psql "$DEV_DATABASE_URL" -c "DELETE FROM topical_coverage_gaps WHERE brand_id='026acf75-188f-4a9f-9126-6ed2fb324f91';"
```
- **Scope:** dev DB only, this ONE brand. Do NOT touch the working Growth Bondi
  (`6ece067f-063c-436b-ac42-7952c7d7a271`) or any other brand. Do NOT touch prod.

## ACTION 2 — Add the domain-normalization bug to the go-live checklist (log only, do NOT fix)
Append a new item to `docs/go-live-checklist.md` under the 🟡 IMPORTANT (or a "pre-launch product bugs") section:

> **[NEW] SoV domain-variant normalization — real bug, fix before real customers use Share of Voice.**
> The SoV brand-vs-competitor exclusion + aggregation compare EXACT domain strings, so `example.com` and
> `example.com.au` (or `www.` variants) are treated as different entities. Consequence: if a customer's stored
> `brands.domain` differs from the form LLMs cite (very common for AU businesses that own both `.com` and
> `.com.au`, or are cited under the .au form), **the customer's OWN domain appears as a competitor against
> themselves** in their SoV — a credibility-destroying wrong number in the flagship metric. Fix: normalize domains
> (strip `www.`, unify `.com`/`.com.au` and other TLD variants of the same root; at minimum exclude ALL variants
> of the brand's own domain from competitors) in `lib/visibility/sov-calculator.ts` (and the mention-source /
> aggregation paths) before the brand-vs-competitor comparison. Not urgent (doesn't block dev/testing — clean test
> data avoids it), but MUST be fixed before SoV ships to real customers. Surfaced during Sprint 3 manual testing
> via a domain-variant test brand.

## VERIFY
1. The Agency brand now has a distinct name + domain (`agencyseo.com.au`, not a bondiplumbing variant); confirm via
   the SELECT.
2. Its stale visibility rows are cleared (0 rows in the 4 tables for that brand_id).
3. Re-run an audit for the Agency brand (Inngest up) → the 5 visibility functions fire → SoV now shows the Agency
   brand correctly (its own domain excluded, only genuine competitors shown — no self-as-competitor). Confirm the
   donut no longer lists a bondiplumbing variant as a competitor.
4. The go-live checklist has the new domain-normalization item logged.
5. The working Growth Bondi is untouched (still renders correctly). 68/68 tests green.

## REPORT
- ACTION 1: the Agency brand's new name/domain; stale visibility rows cleared; after a fresh audit, SoV renders
  clean (no self-as-competitor).
- ACTION 2: the domain-normalization item added to the go-live checklist (logged, not fixed).
- Confirm: dev-only, only this one brand touched, Growth Bondi + prod untouched, 68/68 green.

## NOTE
This closes the SoV oddity as what it was — contaminated test data (fixed now) + a real domain-normalization gap
(banked for pre-launch). The Competitive Benchmark test itself PASSED. After this, Sprint 3's manual pass is fully
complete and validated on clean data → ready for the automated test track (Sections 1–5, one at a time).
