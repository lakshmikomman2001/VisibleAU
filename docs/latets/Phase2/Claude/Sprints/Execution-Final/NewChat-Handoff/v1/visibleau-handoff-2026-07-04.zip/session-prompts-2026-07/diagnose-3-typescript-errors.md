# Claude Code — DIAGNOSE (report-first, NO fixes): 3 TypeScript errors in core files

Three pre-existing TS errors were reported in **critical** files:
`generate-narrative-report.ts`, `simulate-query-fan-out.ts`, `run-audit-inline.ts`. Two of these are central: the
**Sprint 4 report generator** (about to be tested via "Generate report") and the **fan-out function wired earlier
this session** (BudgetPolicy + selectModel fix). A TS error in the report generator, right before testing report
generation, could be the cause of a failure — or a real bug hiding under "78 tests green."

**DIAGNOSE ONLY. Report each error + whether it's a real bug or benign. Change NO source.**

## STEP 0 — Get the EXACT errors (project-wide, not per-file)
Note: earlier "0 TS errors" may have been measured per-changed-file. Run a FULL project typecheck:
```bash
npx tsc --noEmit 2>&1 | head -40
# or the repo's typecheck script if different:
grep -n "typecheck\|tsc\|type-check" package.json | head
```
Report the **exact** error text + file:line for each of the 3 (and whether there are only 3, or more).

## STEP 1 — generate-narrative-report.ts (HIGHEST PRIORITY — gates the Generate-report test)
```bash
npx tsc --noEmit 2>&1 | grep -A3 "generate-narrative-report"
sed -n '1,120p' inngest/functions/generate-narrative-report.ts
grep -n "ReportSection\|sections\|as ReportSection\|template.sections\|DEFAULT_SECTIONS\|selectModel\|filter\|\.include\|any\|@ts-" inngest/functions/generate-narrative-report.ts lib/communication/narrative-generator.ts 2>/dev/null | head
```
Check against the spec contract:
- **LLD 8147 / TS-01 (Sprint 4 prompt line 73):** `report_templates.sections` is typed **`ReportSection[]`** (a
  JSONB array), read via **`(template.sections as ReportSection[]).filter(s => s.include)`**. A common TS error
  here is the JSONB column coming back as `unknown`/`Json`/`any` and the cast/filter not lining up. Is the error
  about the `sections` typing / the `ReportSection[]` cast?
- **selectModel:** does it call `selectModel(tier, engine, 'narrative_generation')` (LLD line 1183) — is the TS
  error about a wrong arg/type there?
- **The fallback (LLD 3529):** `sections: template ? (template.sections as ReportSection[]) : DEFAULT_SECTIONS` —
  is the error about the union/fallback typing?
Determine: **is this TS error a REAL bug that would break/misbehave report generation at runtime, or a benign type
annotation issue** (compiles-and-runs-fine but tsc complains)? This is the key question — it decides whether
"Generate report" will work.

## STEP 2 — simulate-query-fan-out.ts (did our earlier fix introduce it?)
```bash
npx tsc --noEmit 2>&1 | grep -A3 "simulate-query-fan-out"
grep -n "FanOutSubQuery\|selectModel\|BudgetPolicy\|simulateQueryFanOut\|maxSubQueries\|getLLMService\|as \|any\|@ts-" inngest/functions/simulate-query-fan-out.ts | head
```
We wired this earlier (delegate to the library `simulateQueryFanOut` + BudgetPolicy + selectModel). Determine:
- Is the TS error **NEW from that wiring fix** (e.g. a type mismatch between the Inngest fn and the library
  signature, the injected callbacks, or the budget/tier types), or pre-existing?
- Is it a real bug (the wiring is type-unsound → could fail at runtime) or benign?
This matters — a TS error in a file we just "fixed" needs to be understood, not carried.

## STEP 3 — run-audit-inline.ts
```bash
npx tsc --noEmit 2>&1 | grep -A3 "run-audit-inline"
grep -n "any\|as \|@ts-\|import" inngest/functions/run-audit-inline.ts app/*/run-audit-inline.ts 2>/dev/null | head
```
Report the error + whether it's a real bug or benign. (Lower priority — not Sprint 4 core, but report it.)

## FOR EACH ERROR — classify
- **The exact error** (file:line + message).
- **Real bug** (would cause wrong/failing runtime behaviour — e.g. a genuine type mismatch that means the code does
  the wrong thing, a null not handled, a wrong function signature) **vs benign** (compiles to correct runtime
  behaviour; tsc complains about an annotation/cast that's actually safe — e.g. a JSONB `as ReportSection[]` cast
  that is correct at runtime).
- **New or pre-existing** (especially for simulate-query-fan-out — did our session's wiring fix introduce it?).
- **Does it gate anything Sri is about to test?** (generate-narrative-report → the Generate-report flow.)

## VERDICT + fix direction (report, don't fix)
- Which of the 3 are **real bugs** vs **benign type issues**.
- **generate-narrative-report:** will "Generate report" work, or does this error block/break it? (The decisive one.)
- **simulate-query-fan-out:** did our fix introduce it? real or benign?
- The precise fix direction for each real one (for Sri to approve) — e.g. correct the type/cast, handle the null,
  fix the signature. NON-real (benign) ones: note whether worth cleaning up or leaving.
- Whether these 3 were the "0 TS errors" earlier (i.e. earlier count was per-file, project has 3) — so the true
  project typecheck state is clear.

## REPORT
- STEP 0: the full `tsc --noEmit` output (exact errors, and whether only 3).
- Per file: exact error, real-bug-vs-benign, new-vs-pre-existing, gates-a-test-or-not.
- **The decisive answer: does the generate-narrative-report error block report generation?**
- Verdict + per-error fix direction. No source changed (diagnosis only).

## NOTE
"0 TS errors" was likely reported per-changed-file; a full project `tsc --noEmit` is the real state. Three TS errors
in core files (the report generator + the fan-out fn we just wired + audit) is a real signal worth understanding
before commit — especially generate-narrative-report, since Sri is about to test that exact flow. Report-first: tell
Sri what they are and whether they're real, then we fix the real ones (three-source checked) before testing
generation.
