# Claude Code — DIAGNOSE (report-first): Agency-brand SoV shows duplicate bondiplumbing.com — test-data vs real bug?

Context: manual testing switched to an **Agency-tier** brand ("Agency SEO Sydney", brand_id
`026acf75-188f-4a9f-9126-6ed2fb324f91`) to test the Competitive Benchmark (Agency+ gated). Two observations:

1. **Competitive Benchmark WORKS (confirm):** Agency tier → "No competitor data available yet" (gate opens, CPR-01
   graceful degradation, NOT an error). Growth tier → locked teaser. Both correct pre-S7.
2. **BUT the SoV donut on this Agency brand shows a duplicate/odd pattern** — even though a fresh audit was run
   AFTER the Bug 1 fix (brandDomain from brands.domain):
   ```
   bondiplumbing.com        50.0%
   bondiplumbing.com...     50.0%   (truncated — possibly bondiplumbing.com.au?)
   hipages.com.au           33.3%
   ```
   Also: the brand is named "Agency SEO Sydney" but its **audit result is titled "Bondi Plumbing"** and Competitor
   context shows "#1 Bondi Plumbing (you)" — suggesting this Agency brand's **domain is actually bondiplumbing.com**
   (contaminated/misconfigured test brand), not a real Sprint 3 bug.

**Determine which:** (A) contaminated TEST DATA (this Agency brand was set up with Bondi's domain → ignore/clean
up, not a code bug), (B) a DOMAIN-VARIANT edge case (`bondiplumbing.com` vs `bondiplumbing.com.au` treated as two
competitors because aggregation keys by exact string), or (C) a real GAP in the Bug 1/Bug 3 fix. **Report only —
do not fix until classified.**

## STEP 1 — What is this Agency brand's actual domain + name?
```bash
psql "$DEV_DATABASE_URL" -c "SELECT id, name, domain, primary_regions FROM brands WHERE id='026acf75-188f-4a9f-9126-6ed2fb324f91';"
```
Report: is this brand's `domain` literally `bondiplumbing.com` (or `.com.au`)? Is the name "Agency SEO Sydney" but
the domain a Bondi domain? → if so, this is a MISCONFIGURED TEST BRAND (contaminated data), which explains the
Bondi-branded audit + bondiplumbing SoV. That alone would be classification (A).

## STEP 2 — What are the actual SoV rows? (.com vs .com.au, or true duplicates?)
```bash
psql "$DEV_DATABASE_URL" -c "\d share_of_voice_snapshots"
psql "$DEV_DATABASE_URL" -c "SELECT * FROM share_of_voice_snapshots WHERE brand_id='026acf75-188f-4a9f-9126-6ed2fb324f91' ORDER BY calculated_at DESC LIMIT 15;"
```
Report the exact competitor/domain strings in the rows:
- Are the two "bondiplumbing" entries **`bondiplumbing.com` vs `bondiplumbing.com.au`** (TWO DIFFERENT strings)? →
  classification (B): a domain-variant edge case — the brand's real domain is one form, but the cited sources use
  another form, so the brand's own domain (in the other form) counts as a competitor. The Bug-1 `brands.domain`
  match only excludes the EXACT stored domain; a variant slips through.
- Or are they the **SAME exact string duplicated**? → classification (C): a real fix gap (the domain resolution or
  aggregation still double-counts).
- Do the shares sum wrong (50+50+33=133)? Confirm whether that's because of the extra brand-variant row.

## STEP 3 — Confirm whether this is fresh (post-fix) data
```bash
# When was this brand's latest audit + SoV row created, vs when Bug 1 was fixed?
psql "$DEV_DATABASE_URL" -c "SELECT id, brand_id, status, created_at FROM audits WHERE brand_id='026acf75-188f-4a9f-9126-6ed2fb324f91' ORDER BY created_at DESC LIMIT 5;"
```
Report: is the SoV data from an audit that ran AFTER the Bug 1 fix (the user says yes)? If post-fix data STILL shows
the duplicate, then (A) test-data or (B) variant edge case is the cause — NOT the fix regressing (the Growth-brand
Bondi rendered correctly with the same fix, so the fix works; this brand differs by its data).

## STEP 4 — Cross-check against the working Growth brand
The Growth Bondi (`6ece067f-063c-436b-ac42-7952c7d7a271`) renders SoV CORRECTLY (brand once + hipages) after the
fix. Compare its `brands.domain` and SoV rows to this Agency brand's:
```bash
psql "$DEV_DATABASE_URL" -c "SELECT id, name, domain FROM brands WHERE id IN ('6ece067f-063c-436b-ac42-7952c7d7a271','026acf75-188f-4a9f-9126-6ed2fb324f91');"
```
Report the difference: does the working brand have a clean single domain while the Agency brand has a variant/
mismatch? That difference IS the diagnosis.

## VERDICT (report one)
- **(A) CONTAMINATED TEST DATA** — the Agency brand is misconfigured (Bondi's domain on a brand named "Agency SEO
  Sydney"), producing Bondi-branded audits + bondiplumbing SoV. NOT a code bug. → Action: clean up / recreate the
  test brand with a proper distinct domain; no source fix. (Most likely.)
- **(B) DOMAIN-VARIANT EDGE CASE** — `bondiplumbing.com` vs `bondiplumbing.com.au`: the brand's own domain in a
  different form counts as a competitor because the Bug-1 exclusion + Bug-3 aggregation match exact strings, not
  normalized domains. → This IS a real (if minor) product bug worth fixing: normalize domains (strip www, unify
  the brand's own domain variants) before the brand-vs-competitor comparison + aggregation. Report the exact
  strings so the fix is precise.
- **(C) FIX GAP** — same exact domain still duplicated post-fix → the Bug 1/3 fix didn't fully apply for this path.
  Report where.

## REPORT
- This brand's `domain` + `name` (is it a misconfigured Bondi-domain test brand?).
- The exact SoV row domain strings (.com vs .com.au variants, or true duplicates) + whether shares sum wrong.
- Whether the data is post-fix (it should be) — confirming the fix itself isn't regressing (Growth brand proves it
  works).
- The difference vs the working Growth brand.
- **The verdict (A / B / C)** with evidence, and the recommended action (clean test data / normalize domains / fix
  gap). Do NOT apply a fix yet.
- Also confirm: the **Competitive Benchmark tier-gating is verified working** (Agency → "No competitor data
  available yet" graceful; Growth → locked teaser) — this part PASSED, note it as a passed test.

## NOTE
The Competitive Benchmark test the user set out to do PASSED (both tier states correct, CPR-01 degradation graceful
for Agency+). The SoV oddity is a SEPARATE question — most likely a misconfigured test brand (Bondi domain on an
"Agency SEO Sydney" brand), possibly a domain-variant normalization edge case. Classify before fixing so we don't
"fix" contaminated test data as if it were a product bug. If (B), it's a small real improvement (domain
normalization); if (A), it's test-data cleanup, not code.
