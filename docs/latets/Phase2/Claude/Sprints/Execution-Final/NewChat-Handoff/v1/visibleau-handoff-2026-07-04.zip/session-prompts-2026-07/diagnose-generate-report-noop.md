# Claude Code — DIAGNOSE (report-first, NO fixes): "Generate report" does nothing (silent no-op, no error)

Clicking **"Generate report"** on `/brands/[brandId]/reports` produces **nothing** — no report card, and the
console shows **NO error** (only Fast Refresh + PostHog 404 noise). No 500, no failed request, no exception. So the
click either (a) fires no request, (b) fires a request that silently succeeds without creating a report, or (c) the
function runs but no-ops. The blockers we fixed (Inngest arity, wrong column, missing tables) would throw ERRORS —
a SILENT no-op is a different cause.

**DIAGNOSE ONLY. Report the cause. Change NO source.**

## ✅ THREE-SOURCE CHECK (done) — the trigger architecture (this likely explains it)
- **§8.1 (line 339-340) + LLD NR-01 (1095-1098):** `generate-narrative-report` **listens on the `trend/aggregated`
  Inngest event**, which `aggregate-visibility-trend` (S3) emits after writing a visibility_trends row.
- **⚠️ LLD line 418-419 (KEY):** the report *"only generates when an **active delivery schedule exists**"* (+
  concurrency 5, emits `report/generated` after the INSERT).
- **§9 / LLD 8464:** there is ALSO a **`POST /api/brands/[id]/reports/generate`** route ("generate a narrative
  (Growth+); emits the generation path").
- **The likely causes (silent no-op):**
  1. **Inngest not running** — the button/route emits an event, but no Inngest dev server at :8288 → event dropped
     silently, no report, no error (the Sprint 2 pattern: event-driven actions fail silently when Inngest is down).
  2. **No active delivery schedule** — if generation gates on "active delivery schedule exists" (LLD 418), and Sri
     has NO schedules (the delivery-schedules screen was orphaned, never used) → the function fires but no-ops
     (no schedule → nothing to generate) → silent, no error, no report.
  3. **The button isn't wired** — the "Generate report" CTA has no onClick, or an onClick that doesn't POST → no
     request fires at all.
  4. **The button POSTs but the route doesn't create a report** — e.g. the route only emits `trend/aggregated`
     (which then gates on schedule per cause 2), rather than directly creating a report.

## STEP 1 — Does clicking the button fire a REQUEST at all?
```bash
# Find the Generate report button + its handler:
grep -rn "Generate report\|generateReport\|reports/generate\|onGenerate" components/ app/ | grep -iE "button\|onClick\|fetch\|post\|route" | head
sed -n '1,80p' components/domain/communication/*report*card* 2>/dev/null || find components app -iname "*report*list*" -o -iname "*report*card*" | head
```
Report: does the button have an onClick that POSTs to `/api/brands/[id]/reports/generate` (or emits an event)? Or is
it unwired / a no-op? (Sri's console showed NO network request to a generate endpoint — confirm whether one fires.)

## STEP 2 — What does the generate route DO?
```bash
cat "app/api/brands/[id]/reports/generate/route.ts"
```
Report: on POST, does the route:
- **Directly INSERT a generated_reports row + run the narrative + PDF** (synchronous-ish), OR
- **Emit an Inngest event** (`trend/aggregated`? a custom `report/generate`?) and return 202 — deferring to the
  Inngest function? (If it emits `trend/aggregated`, that's the automatic-path event, which gates on a delivery
  schedule per cause 2.)
- Does it require an **active delivery schedule** before doing anything? Does it return 200/202 even when nothing
  gets created (→ silent success)?

## STEP 3 — Does generate-narrative-report GATE on an active delivery schedule?
```bash
sed -n '1,90p' inngest/functions/generate-narrative-report.ts
grep -n "delivery_schedule\|deliverySchedule\|is_active\|active.*schedule\|schedule.*exist\|return\|skip\|if.*!.*schedule" inngest/functions/generate-narrative-report.ts
```
Report: does the function check for an active delivery schedule and **early-return / skip** if none exists (LLD
418)? If so, and Sri has NO delivery schedules → THIS is the silent no-op: the function runs but does nothing.

## STEP 4 — Is Inngest running + did the function fire?
```bash
# Is the Inngest dev server up?
curl -s http://localhost:8288/health 2>&1 | head; echo "---"
curl -s http://localhost:8288/api/apps 2>&1 | head
grep -nE "INNGEST_DEV|INNGEST_EVENT_KEY" .env.local .env.test.local .env 2>/dev/null
```
Report: is Inngest running at :8288 and is `visibleau` synced? Is `generate-narrative-report` registered in the
serve() array? (If Sri emits the event but Inngest is down, it's dropped silently.) If Inngest IS up, check its
dashboard/stream for whether `generate-narrative-report` (or `trend/aggregated`) fired when Sri clicked — did the
function run, and if so did it no-op or error?

## STEP 5 — Are there any delivery schedules for this brand/org?
```bash
psql "$DATABASE_URL" -c "SELECT id, brand_id, frequency, is_active FROM report_delivery_schedules WHERE organization_id='49bc204c-ef83-4f08-ac76-a46f5d005d0e';"  # likely 0 rows
```
Report: does an active delivery schedule exist? (Expected: none — Sri never created one.) If generation gates on
this (STEP 3) and there are none → confirmed cause 2.

## VERDICT (report one, with evidence)
- **Inngest down** → the event is dropped; fix = start Inngest dev (+ the route should surface the failure, not
  silent-200).
- **Gates on delivery schedule + none exist** → the function no-ops by design; the button is misleading (it implies
  on-demand generation but the flow requires an active schedule). Fix direction: either the manual button should
  generate ON DEMAND (bypass the schedule gate for the explicit button), OR the UX should tell the user "create a
  delivery schedule first." Report which the spec intends (§9 says the button "generates a narrative" — implying
  on-demand; LLD 418 says the FUNCTION gates on schedule — these may conflict; LLD wins, but the BUTTON path may be
  meant to bypass the gate).
- **Button unwired / route no-ops** → the button doesn't actually trigger generation; fix = wire it.
- **Combination** → report all contributing.

## REPORT
- STEP 1: does the button fire a request? (wired or no-op)
- STEP 2: what the generate route does (direct insert vs emit event vs gate on schedule).
- STEP 3: does generate-narrative-report early-return without an active delivery schedule?
- STEP 4: is Inngest up + synced + did the function fire when clicked?
- STEP 5: are there any active delivery schedules? (likely 0)
- **Verdict** (which cause) + the fix direction (start Inngest / on-demand button vs schedule-gate / wire button) for
  Sri to approve.
- Confirm: no source/data changed; which DB.

## NOTE — the architectural question this surfaces
§9 says the "Generate report" button "generates a narrative (Growth+)" — implying **on-demand** generation. But LLD
418 says generate-narrative-report **only generates when an active delivery schedule exists** — it's designed as an
event-chained, schedule-gated flow (audit → trend → report), NOT primarily an on-demand button. So the button may be
hitting a flow that's architecturally meant to be automatic + schedule-gated. If Sri has no schedules, "nothing
happens." The real question for the fix: is the manual button SUPPOSED to generate on-demand (bypassing the
schedule gate), or is it only meant to work once a schedule exists? The spec is ambiguous here (§9 on-demand vs LLD
418 schedule-gated) — flag it; per canon LLD wins, but the on-demand button UX needs a clear intended behaviour.
This is a design clarification, not just a bug.
