# Claude Code — DIAGNOSE (report-first, NO fixes): pdf_url never populates (report stuck 'generating' forever)

**Corrected understanding:** report CONTENT generation works (narrative + Sprint 3 wins/gaps populated — confirmed).
But **`pdf_url` stays NULL**, so the derived status is stuck on **'generating' forever**. The spec says this state
is TRANSIENT, not expected:
- **LLD 8369 / §4 line 269:** *"Row is inserted first, pdf_url populated AFTER [the PDF renders]"* — pdf_url is
  MEANT to populate.
- **LLD 8373:** `pdf_url IS NULL → 'generating' (PDF render IN FLIGHT)` — 'generating' = transient, render pending.
- **§4 line 111-112:** *"PDF storage uses the existing Supabase Storage bucket (pre-signed URLs, 7-day expiry);
  confirm the bucket/credentials Phase 1 Sprint 9 already configured."* — the bucket is supposed to EXIST.
So a permanently-NULL pdf_url is a **real bug**, NOT "expected in dev." Either the PDF render/upload step is failing
(storage unreachable / error swallowed) or it was never implemented. Find which.

**DIAGNOSE ONLY. Change NO source.**

## STEP 1 — Does the PDF render/upload code even EXIST in the function?
```bash
# The full function body — is there renderToBuffer → upload → set pdf_url, or does it stop after inserting content?
cat inngest/functions/generate-narrative-report.ts
grep -n "renderToBuffer\|pdf-builder\|pdfBuilder\|ReportPdf\|@react-pdf\|storage\|upload\|createSignedUrl\|getSignedUrl\|pdf_url\|update.*generated_reports\|supabase" inngest/functions/generate-narrative-report.ts
```
Report: after inserting the report row + narrative, does the function:
- (a) call `renderToBuffer()` on the PDF component, then
- (b) upload the buffer to Supabase Storage, then
- (c) create a pre-signed URL, then
- (d) UPDATE generated_reports SET pdf_url = <url>?
OR does it stop after writing narrative_text (no PDF step at all)? **If the PDF step is MISSING → that's the bug (not
implemented). If it EXISTS → go to STEP 2 (it's failing).**

## STEP 2 — If the PDF step exists: is it failing? (storage / render error swallowed)
```bash
# The pdf-builder + how it's invoked:
cat lib/communication/pdf-builder.tsx | head -60
# Is the PDF/upload step wrapped in a try/catch that SWALLOWS errors (so the function 'Completes' but pdf_url stays null)?
grep -n "try\|catch\|renderToBuffer\|upload\|storage\|await\|pdf_url" inngest/functions/generate-narrative-report.ts
# Is Supabase Storage configured/reachable in THIS env?
grep -nE "SUPABASE_URL|SUPABASE_SERVICE_ROLE|SUPABASE_ANON|STORAGE_BUCKET" .env.local .env.test.local .env 2>/dev/null
grep -rn "storage.from\|createSignedUrl\|\.upload(" lib/ | grep -i pdf | head
```
Report:
- Is the PDF/upload in a step that could throw but is CAUGHT and swallowed (→ function completes green, pdf_url
  never set)? The Inngest run showed 'Completed' — if the PDF step threw inside a swallowing try/catch, that
  explains Completed-but-pdf_url-null.
- Is Supabase Storage configured in this env (URL + service role key + bucket)? The spec says the bucket exists from
  Sprint 9 — is it actually reachable here, or is the app on a local/prod-mixed env where storage isn't wired?
- Does the Inngest run's STEP TRACE (on :8288) show a render/upload step that errored or was skipped? Check the run
  detail for the render/upload step specifically.

## STEP 3 — Confirm from the run trace what happened after narrative
In the Inngest dashboard (:8288 — the server the app uses), open a `generate-narrative-report` run and read ALL its
steps:
```bash
curl -s "http://localhost:8288/v1/runs" 2>&1 | head -60
```
Report: what steps ran? Was there a render-pdf / upload step? Did it succeed, error, or not exist? (The run being
'Completed' with narrative-but-no-pdf_url means either: no PDF step, or a PDF step that errored inside a swallow.)

## STEP 4 — The Supabase Storage bucket
```bash
# Does the bucket the spec references (Sprint 9's) exist + is it reachable with current creds?
grep -rn "bucket\|storage.from\|STORAGE" lib/ app/ | grep -iE "report\|pdf\|supabase" | head
# What bucket name does the PDF upload target?
grep -rn "\.from(['\"]" lib/communication/ inngest/functions/generate-narrative-report.ts | head
```
Report: what bucket does the code upload to? Does it exist / is it reachable in this env? (If the bucket doesn't
exist or storage isn't configured, the upload fails → pdf_url null.)

## VERDICT (report one)
- **PDF step NOT IMPLEMENTED** — the function writes narrative + inserts the row but has no renderToBuffer→upload→
  set-pdf_url code. → Fix: implement the PDF render + Supabase upload + pdf_url update (per §4 / LLD 8369).
- **PDF step EXISTS but errors, swallowed** — renderToBuffer or the storage upload throws inside a try/catch that
  doesn't surface it → 'Completed' but pdf_url null. → Fix: surface the error + fix the underlying cause (storage
  config / render bug).
- **Storage not configured in this env** — the bucket/creds aren't set locally (local/prod-mixed) → upload fails.
  → Fix: configure Supabase Storage for this env (or point at the Sprint 9 bucket), OR accept pdf_url null is an
  ENV limitation (but then the UI should say so, not stick on 'generating' forever).
- Report which, with evidence (the run trace + whether the code exists + storage config).

## REPORT
- STEP 1: does the PDF render/upload/set-pdf_url code EXIST in the function? (the decisive question)
- STEP 2: if it exists, is it erroring (swallowed)? Is Supabase Storage configured/reachable here?
- STEP 3: the run's step trace — what happened after the narrative step (render? upload? error? absent?).
- STEP 4: the target bucket — exists/reachable?
- **Verdict** (not implemented / errors-swallowed / storage-not-configured) + fix direction. No source/data changed;
  which DB + which env (is storage available?).

## NOTE
The report CONTENT works (narrative + Sprint 3 data — a real win). The remaining gap is the PDF, and the spec is
clear it's SUPPOSED to populate (row first, pdf_url after; 'generating' = render in flight, transient). So permanent
'generating' is a real bug. The most likely causes: (1) the PDF render/upload step errors and is swallowed (function
'Completes' green but pdf_url null), or (2) Supabase Storage isn't configured in this local/prod-mixed env (same
class as the Inngest-for-prod gap). STEP 1 (does the code exist) + STEP 3 (the run trace) pinpoint it. Don't accept
'pdf_url null is expected' without confirming — the PDF IS the deliverable.
