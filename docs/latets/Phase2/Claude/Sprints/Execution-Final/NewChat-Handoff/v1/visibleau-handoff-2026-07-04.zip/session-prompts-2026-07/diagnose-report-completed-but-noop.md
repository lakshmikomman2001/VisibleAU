# Claude Code — DIAGNOSE (report-first, NO fixes): generate-narrative-report "Completed" in ~1s but no report produced

**New evidence flips the earlier theory.** The Inngest dashboard shows `generate-narrative-report` runs as
**"Completed"** (green), NOT failed — and they complete in **~1 second** (queued 9:48:30 → ended 9:48:31). A real
narrative-gen + PDF render would take longer. A ~1s "Completed" run = the function **early-returned and exited
successfully by doing nothing** (returning `{ skipped: true }` is a successful completion). So the PDF/storage-failure
theory is WRONG — the function isn't erroring, it's **no-op-completing**, which means the `manual: true` schedule-gate
bypass we added is likely NOT taking effect. ALSO: there appear to be **TWO Inngest dev servers running** (port
conflict) — must resolve that first.

**DIAGNOSE ONLY. Change NO source.**

## ⚠️ STEP 0 — TWO Inngest servers (port conflict) — resolve before trusting anything
The terminal shows `inngest-cli dev` hit a **port conflict on 8288 → started on 8290** instead. So there's an OLD
Inngest server on :8288 (the dashboard being viewed) AND a NEW one on :8290. Events/registration may split between
them → unreliable diagnosis.
```bash
# What's listening on the Inngest ports?
netstat -ano | findstr ":8288 :8290 :8289 :8291" 2>/dev/null || lsof -i :8288 -i :8290 2>/dev/null
# Which Inngest is the APP actually pointed at? (the serve endpoint URL + INNGEST_BASE_URL / dev URL)
grep -rnE "8288|8290|INNGEST_DEV|INNGEST_BASE_URL|localhost:8288" .env.local .env.test.local .env inngest/ lib/inngest* 2>/dev/null | head
```
Report: how many Inngest servers are running, on which ports, and which one the app's serve endpoint + the browser
dashboard correspond to. **Recommend killing the duplicate so exactly ONE Inngest runs**, and confirm which port the
app registers with. (Until this is clean, "Completed" runs on :8288 may not be the runs the app is actually
triggering.)

## STEP 1 — Is the `manual: true` flag actually REACHING the function? (the likely bug)
We added `manual: true` to the route's event and `if (!manual)` around the gate. But the runs still complete in ~1s
(early-return). Check the flag path end-to-end:
```bash
# The route: is manual:true in the event data, at the right path?
sed -n '50,70p' "app/api/brands/[id]/reports/generate/route.ts"
# The function: how does it READ manual? (event.data.manual? destructured? correct path?)
sed -n '35,60p' inngest/functions/generate-narrative-report.ts
grep -n "manual\|event.data\|const {.*} = event" inngest/functions/generate-narrative-report.ts
```
Report: 
- Does the route emit `manual: true` inside `data` (i.e. `data: { ..., manual: true }`)?
- Does the function read it from the SAME path (`event.data.manual`)? Is the destructure correct (e.g. does it
  destructure from `event.data` and actually include `manual`)?
- Is the gate `if (!manual)` using the value that was actually read, or a stale/undefined one?
**A path mismatch (route puts it in data.manual, function reads it elsewhere — or the destructure misses it) → manual
is undefined → `!manual` is true → gate still applies → early-return → "Completed" no-op.** This is the prime suspect.

## STEP 2 — Confirm WHICH branch the run took (schedule gate vs generated)
```bash
# The report rows — narrative_text + pdf_url NULL? (if BOTH null → never generated → early-returned)
psql "$DATABASE_URL" -c "SELECT id, pdf_url, narrative_text IS NOT NULL AS has_narrative, created_at FROM generated_reports WHERE brand_id='026acf75-188f-4a9f-9126-6ed2fb324f91' ORDER BY created_at DESC;"
```
Wait — the report ROW exists (2 rows), but was it INSERTed by the route or the function? Clarify:
- Does the **route** INSERT the generated_reports row (status generating) THEN emit the event, and the **function**
  fills in narrative+pdf? OR does the **function** INSERT the row?
- If the row exists but narrative_text + pdf_url are BOTH NULL → the function early-returned before doing anything
  (the row was inserted by the route as a placeholder, or the function inserted-then-skipped). Confirm who inserts
  the row and what the function does after the gate.
Report: are narrative_text AND pdf_url both NULL on the 2 rows? (Expected if early-returning.) Who INSERTs the row?

## STEP 3 — Look at the actual run detail in Inngest (the step trace)
In the Inngest dashboard (the CORRECT single server — see STEP 0), click a `generate-narrative-report` run and read
its **step output**:
- Did it run `check-schedule-and-template` and RETURN there (the skip), or did it proceed to generate + render?
- What did the step return? (`{ skipped: true, reason: "no_active_delivery_schedule" }` → the gate still fired
  despite manual → confirms STEP 1's path-mismatch theory.)
```bash
curl -s "http://localhost:8288/v1/runs" 2>&1 | head -40   # or :8290 — whichever the app uses
```
Report: the step trace — did it skip at the gate (returning skipped:true) or generate? What was the return value?

## VERDICT (report one)
- **manual flag not reaching the function (path mismatch)** → the gate still fires → early-return → "Completed"
  no-op. Fix: correct the flag path (route emits data.manual, function reads event.data.manual, destructure includes
  it). MOST LIKELY given ~1s completion + our recent gate change.
- **Two Inngest servers confusion** → the app registered with :8290 but you're watching :8288 (or vice versa), so
  the "Completed" runs you see aren't the manual ones / registration split. Fix: run exactly ONE Inngest server on
  the port the app expects.
- **Function generates but doesn't set pdf_url** (narrative_text present, pdf_url null) → a PDF-render/upload issue
  after all (less likely given 1s timing). Report if so.
- **Combination** (e.g. two servers AND a flag path mismatch).

## REPORT
- STEP 0: how many Inngest servers (ports), which one the app uses + the browser shows; recommend the single-server
  cleanup.
- STEP 1: the manual-flag path in route (emit) vs function (read) — do they MATCH? Is manual actually true at the
  gate?
- STEP 2: narrative_text + pdf_url on the 2 rows (both NULL?); who INSERTs the row.
- STEP 3: the run's step trace — skipped at the gate (skipped:true) or generated?
- **Verdict** (flag path mismatch / two-servers / pdf issue) + fix direction. No source/data changed; which DB.

## NOTE
The ~1-second "Completed" runs are the key clue: the function is SUCCEEDING by doing nothing (early-return), not
failing. So this is NOT the PDF/storage failure I suspected — it's that the manual bypass isn't taking effect (the
gate still fires), most likely a `manual` flag path mismatch between the route's emit and the function's read. Plus a
real environment issue: two Inngest servers from a port conflict. Resolve the duplicate server, confirm the flag path,
and read the run's step trace to see it skip at the gate. This is why reading the ACTUAL run trace matters — "stuck
Generating" looked like a PDF failure, but the runs are Completed-no-op, a completely different cause.
