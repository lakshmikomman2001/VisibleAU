# Claude Code — DIAGNOSE (report-first, NO fixes): report stuck on "Generating..." (chain dies after INSERT)

The on-demand fix worked at the trigger level — clicking "Generate report" now CREATES a report row ("AI Visibility
Report", 2026-W01). But the status is stuck on **"Generating..." after 60+ seconds** and never flips to "Ready".
Derived status (CM-01) = "Generating" means **`pdf_url` is still NULL** — so the row was INSERTed but the generation
chain (narrative → PDF render → set pdf_url → emit report/generated) **started then FAILED after the INSERT**, before
setting pdf_url. This is a NEW bug in the generation BODY (not the schedule gate we just fixed).

**DIAGNOSE ONLY. Find where the chain died. Change NO source.** The error is server-side (Inngest), not in the
browser console.

## STEP 1 — The Inngest run: WHERE did it die? (this is the decisive evidence)
```bash
# Inngest dashboard shows each function run + the exact step that failed. Query the Inngest dev API:
curl -s "http://localhost:8288/v1/events?limit=10" 2>&1 | head -60
curl -s "http://localhost:8288/v1/runs?limit=10" 2>&1 | head -80
# Or check the app/inngest terminal logs for the generate-narrative-report run error + stack trace.
```
Report: did `generate-narrative-report` run? Which **step** failed (the function has steps:
check-schedule-and-template → generate narrative → render PDF → update pdf_url → emit report/generated)? What's the
**exact error + stack trace**? (This single thing likely identifies the bug.)

## STEP 2 — The report row's actual state in the DB
```bash
psql "$DATABASE_URL" -c "SELECT id, brand_id, period_label, pdf_url, narrative_text IS NOT NULL AS has_narrative, email_sent_at, created_at FROM generated_reports WHERE brand_id='026acf75-188f-4a9f-9126-6ed2fb324f91' ORDER BY created_at DESC LIMIT 3;"
```
Report: is `pdf_url` NULL (yes — that's why it's 'Generating')? Is `narrative_text` populated or NULL? This tells us
HOW FAR the chain got:
- **narrative_text NULL** → died during/before narrative generation (STEP 3 area).
- **narrative_text present but pdf_url NULL** → narrative succeeded, died during PDF render (STEP 4 area — react-pdf
  renderToBuffer, or the Supabase upload / pre-signed URL).

## STEP 3 — If narrative failed: the generation body
```bash
sed -n '60,140p' inngest/functions/generate-narrative-report.ts
grep -n "selectModel\|getLLMService\|generateNarrative\|renderToBuffer\|pdf\|upload\|supabase\|storage\|update.*pdf_url\|report/generated" inngest/functions/generate-narrative-report.ts
```
Check likely failure points in the body (post-gate):
- **narrative generation** — `selectModel(tier, engine, 'narrative_generation')` + the LLM call: does it error?
  Reading Sprint 3 data (SoV/trends/fan-out/gaps for the sections) — a query error there? (real-LLM vs mock?)
- **RULES 1-11 / section rendering** — a null/undefined from a missing Sprint 3 table row?

## STEP 4 — If PDF render/upload failed (MOST LIKELY for react-pdf)
```bash
sed -n '1,60p' lib/communication/pdf-builder.tsx
grep -n "renderToBuffer\|@react-pdf\|Document\|Page\|supabase\|storage\|upload\|createSignedUrl\|pdf_url" lib/communication/pdf-builder.tsx inngest/functions/generate-narrative-report.ts
# Is Supabase storage configured (the PDF has to be uploaded + a pre-signed URL created)?
grep -nE "SUPABASE_URL|SUPABASE_SERVICE|SUPABASE_ANON|STORAGE" .env.local .env.test.local .env 2>/dev/null
```
react-pdf `renderToBuffer()` + Supabase storage upload are common failure points:
- **renderToBuffer throws** — a react-pdf component error (unsupported style, a null value in a section, a bad
  font/asset). 
- **Supabase storage upload fails** — bucket doesn't exist, storage not configured for this env (you're on a
  local/prod-mixed setup), no service key, or the pre-signed URL creation throws → pdf_url never set.
Report which: does the code render the PDF then upload to Supabase storage then set pdf_url? Is Supabase storage
actually configured/reachable in this env? (If storage isn't set up locally, the upload would fail → stuck
'Generating'.)

## STEP 5 — Did the run ERROR, or is it still retrying / hung?
```bash
# Inngest retries on failure (retries: 2 typical). Is the run failed-permanently, still-retrying, or hung?
curl -s "http://localhost:8288/v1/runs?limit=5" 2>&1 | grep -iE "status|error|failed|completed|running" | head
```
Report: is the run **Failed** (with the error from STEP 1), still **Running/Retrying**, or **Completed** (in which
case pdf_url should be set and the UI just isn't refreshing — a different, lesser bug)?

## VERDICT (report one, with the error as evidence)
- **Narrative generation failed** (narrative_text NULL) → the LLM call / Sprint 3 data read / selectModel errored.
  Report the exact error.
- **PDF render failed** (narrative present, pdf_url NULL) → react-pdf renderToBuffer threw. Report the component/style
  error.
- **PDF upload/storage failed** → Supabase storage not configured/reachable in this env, or bucket/pre-signed URL
  error. Report the storage error. (LIKELY if storage isn't set up locally.)
- **Completed but UI not refreshing** (pdf_url IS set) → generation worked; the list/status just doesn't
  auto-update → a polling/refresh bug, not a generation bug.
- Report the exact failing step + error + the fix direction (for approval).

## REPORT
- STEP 1: which Inngest step failed + the exact error/stack.
- STEP 2: the report row's pdf_url (NULL?) + narrative_text (NULL or present?) — how far the chain got.
- STEP 3/4: the failure point (narrative vs PDF render vs storage upload) + the specific error.
- STEP 5: run status (Failed / Retrying / Completed).
- **Verdict** (which step, which error) + fix direction. No source/data changed; which DB.

## NOTE
The gate-bypass fix succeeded (report row created — real progress). This is a SEPARATE bug in the generation body,
newly reachable now that generation actually runs. The most likely culprits, in order: (1) Supabase storage not
configured in this local/prod-mixed env → PDF upload fails → pdf_url never set → stuck 'Generating'; (2) react-pdf
renderToBuffer throwing on a section's data; (3) the narrative LLM call erroring. STEP 1 (the Inngest run error) +
STEP 2 (narrative_text present-or-null) together pinpoint it. This is exactly why "watch it actually run" matters —
the report row inserting looked like success, but the PDF (the real artifact) never rendered.
