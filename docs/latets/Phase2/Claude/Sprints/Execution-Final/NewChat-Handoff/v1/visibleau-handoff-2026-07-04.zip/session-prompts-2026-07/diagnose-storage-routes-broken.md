# Claude Code — DIAGNOSE (report-first, NO fixes): storage changes broke the report routes (404 + 500)

After the storage-adapter implementation, two report routes that worked BEFORE now fail:
- `POST /api/brands/[brandId]/reports/generate` → **404 (Not Found)**
- `GET /api/brands/[brandId]/reports` → **500 (Internal Server Error)** — this route WORKED before (reports rendered
  on it); now it crashes.
Testing in **local mode** (`STORAGE_DRIVER=local`), so this is NOT a Supabase-connectivity issue — it's the storage
code breaking the routes. The GET route was modified to call `getStorage().getDownloadUrl()`; the likely culprit is
the storage import chain throwing/failing at import or init.

**DIAGNOSE ONLY. Change NO source. Report the root cause.**

## STEP 1 — The 500 on GET reports: what's the ACTUAL server error?
The browser only shows "500". Get the real server-side stack trace:
```bash
# Check the dev-server terminal output for the stack trace when GET /reports is hit.
# Then read the modified route + trace the getStorage import chain:
cat "app/api/brands/[brandId]/reports/route.ts"
```
Look specifically at: does the route call `getStorage()` at module top-level or inside the handler? Does importing
it pull in the Supabase adapter/client eagerly? Report the exact error the route throws (from the terminal), and the
line.

## STEP 2 — Does the storage import chain throw when SUPABASE_* is unset/at import time? (prime suspect)
Even in `STORAGE_DRIVER=local`, if the factory or the barrel imports the SUPABASE adapter, and the supabase client
(`lib/supabase.ts`) runs `createClient()` EAGERLY at module load (not lazily), it throws when SUPABASE_URL /
SUPABASE_SERVICE_ROLE_KEY are missing/blank → any route importing the chain 500s.
```bash
cat lib/storage/index.ts          # the factory — does it import BOTH adapters at top-level?
cat lib/storage/supabase-adapter.ts   # does it import lib/supabase.ts at top-level?
cat lib/supabase.ts               # does createClient() run at MODULE LOAD, or lazily inside a function/getter?
grep -n "createClient\|SUPABASE_URL\|SUPABASE_SERVICE_ROLE_KEY\|throw\|!process.env" lib/supabase.ts lib/storage/supabase-adapter.ts lib/storage/index.ts
# What are the actual env values loaded? (local mode — SUPABASE_* may be blank/placeholder)
grep -nE "STORAGE_DRIVER|SUPABASE_URL|SUPABASE_SERVICE_ROLE_KEY|STORAGE_LOCAL_DIR" .env.local
```
Report:
- Does `lib/storage/index.ts` import BOTH adapters at top-level (so the supabase adapter loads even in local mode)?
- Does `lib/supabase.ts` create the client EAGERLY at import (throws if keys missing), or LAZILY (only when actually
  used)? **If eager → that's the bug: the supabase client throws at import even in local mode.**
- Are SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY actually set in .env.local, or blank/placeholder? (In local mode they
  may be empty → eager client init throws.)

## STEP 3 — The 404 on POST generate: did the route break/fail to compile?
```bash
ls -la "app/api/brands/[brandId]/reports/generate/route.ts"   # does it still exist?
cat "app/api/brands/[brandId]/reports/generate/route.ts" | head -30
# Does this route ALSO import the storage chain (→ same import-time throw → route fails to register → 404)?
grep -n "getStorage\|storage\|import" "app/api/brands/[brandId]/reports/generate/route.ts"
# Any compile error in the dev-server terminal for this route?
```
Report: does the generate route file still exist + compile? Does it import the storage chain? Is there a
compile/import error in the terminal making Next fail to serve it (→ 404)? (A module-load throw anywhere in the
import graph can make the route 404 rather than 500.)

## STEP 4 — Confirm the new render-report-pdf function didn't break serve()
```bash
grep -n "renderReportPdf\|render-report-pdf\|serve(" app/api/webhooks/inngest/route.ts
cat inngest/functions/render-report-pdf.ts | head -40   # does IT import the storage chain eagerly too?
```
Report: does the inngest serve route import the storage chain (→ if it throws at import, the whole inngest endpoint /
related routes break)? Does render-report-pdf import lib/storage eagerly?

## VERDICT (report one, with evidence)
- **Eager Supabase client init** (lib/supabase.ts calls createClient at module load) → throws when SUPABASE_* unset
  → every route importing the storage chain 500s/404s, EVEN in local mode. Fix: make the Supabase client + adapter
  LAZY (only init when STORAGE_DRIVER=supabase AND actually used), so local mode never touches it. MOST LIKELY.
- **Factory imports both adapters at top-level** → the supabase adapter (and its eager client) loads even in local
  mode. Fix: lazy-import the chosen adapter inside getStorage(), or guard the supabase client init.
- **A route file broke/compile error** → the generate route 404s because it fails to compile. Report the error.
- **Missing/blank SUPABASE_* in local mode** triggering the eager throw → confirm the env values.
- Report the exact failing module + line + the terminal stack trace.

## REPORT
- STEP 1: the real server stack trace for the GET /reports 500 + the line.
- STEP 2: is lib/supabase.ts eager or lazy? does the factory import both adapters at top-level? are SUPABASE_* set or
  blank in local mode?
- STEP 3: does the generate route still exist/compile? does it import the storage chain? the 404 cause.
- STEP 4: does the inngest serve / render-report-pdf import the chain eagerly?
- **Verdict** (eager-client-init / both-adapters-imported / route-broke) + fix direction (make supabase client +
  adapter lazy so local mode never initializes it). No source/data changed; STORAGE_DRIVER + which DB.

## NOTE
Testing in LOCAL mode, so Supabase shouldn't even be touched — yet routes that worked before now 404/500. The
classic cause: the Supabase client is initialized EAGERLY at module import (throws on missing keys), and the storage
factory/adapters are imported by the routes, so importing the chain throws even when STORAGE_DRIVER=local. The fix is
LAZY initialization — only construct the Supabase client when STORAGE_DRIVER=supabase AND it's actually used — so
local mode never initializes it. This is a common adapter-pattern pitfall. Confirm via the actual stack trace before
fixing.
