# Claude Code — ENHANCE (visual only): Visibility tiles rich look-and-feel, aligned to the prototype + design standard

**Goal:** make the four Visibility hub tiles richer and more legible — the SoV chart especially (currently a hard-to-
read donut with weak segment differentiation). This is a **visual enhancement only.** It must NOT change any data
logic, and must PRESERVE every fix from the recent manual pass (brands.domain resolution, engine aggregation,
{location} substitution, latest-audit scoping, unique React keys, CPR-01 degradation, tier-gating).

## AUTHORITY & CONTEXT (read first)
- **Design standard:** `shared-docs/visibleau-ux-design-standard.md` — follow it as the bar. Key rules: every visual
  element must ENCODE information (not decorate); **reuse the existing token system, never invent** colours/spacing;
  WCAG AA (contrast ≥4.5:1 text / ≥3:1 UI; **never colour alone** — position/shape/icon/text carry meaning too);
  restraint (rich ≠ loud; one focal element, semi-transparent accents); honesty (never imply more certainty/quality
  than the data supports); consistency (same score-viz language everywhere).
- **The SoV chart is a known DRIFT:** the **prototype specifies SoV as horizontal BARS** (`phase-2/02-prototype/
  visibleau-phase2-prototype-FIX17.jsx` ~line 1683: "SoV bars — each brand gets a horizontal bar with pct label"),
  but the shipped `sov-donut.tsx` renders a DONUT. Donuts compare few similar shares poorly — the bars are both the
  prototype intent AND more legible. **This enhancement brings SoV back to ranked bars** (the approved mockup shown
  to Sri) + a richer treatment. This is alignment-to-prototype, not a new redesign.
- **Real design tokens (from §2 of the standard — use these, confirm exact names in the codebase/prototype, never
  hardcode hex):** surfaces `--bg-base/-subtle/-elevated/-hover/-active`; text `--text-primary/-secondary/-tertiary`;
  borders `--border-subtle/-default/-strong`; layer theming `--layer-visibility` (+ `-soft`); score quality ramp
  `--health-poor/-moderate/-good/-great`; semantic `--success/-warning/-danger/-info` (+ `-soft`); `--font-mono` for
  numbers; `--focus-ring`, `--elevation`. **RT-01: use `color-mix(in srgb, var(--x) N%, transparent)` for faint
  fills — NEVER hex-alpha on a var().**

> Investigate-first: read the four shipped components + the prototype's SoV bars + Mention-Source matrix so the
> enhancement matches the real props/data shape and the prototype's visual intent.
```bash
cat components/domain/visibility/sov-donut.tsx
cat components/domain/visibility/mention-source-matrix.tsx
cat components/domain/visibility/fan-out-tree.tsx
cat components/domain/visibility/topical-gap-list.tsx
sed -n '1665,1775p' /path/to/prototype/visibleau-phase2-prototype-FIX17.jsx   # prototype SoV bars + matrix (visual reference)
```

## TILE 1 — `sov-donut.tsx`: donut → enhanced ranked bars (the main change)
Replace the donut rendering with **ranked horizontal bars** (keep the file name to avoid import churn; only the
render changes). Match the prototype's bar pattern + the approved mockup:
- **One bar per distinct domain**, sorted by share DESC (the engine-aggregation fix already produces one row per
  domain — reuse it; do NOT re-introduce per-engine duplicate segments).
- **The brand's bar** uses `--layer-visibility` (fill) + a "you" chip (`--layer-visibility-soft` bg); **competitor
  bars** use a muted fill (`--bg-active`). Brand identity is carried by the fill colour AND the "you" chip AND its
  rank/position — not colour alone (WCAG).
- **Each row:** a small square swatch + the domain label (brand in `--text-primary`, competitors `--text-secondary`)
  on the left; the **percentage in `--font-mono` tabular-nums** on the right; the bar below/inline (h ~8px, rounded).
- **Header:** the headline SoV % big in `--font-mono` (brand's share) top-right, with the delta pill (reuse the
  existing IntelCard delta pattern — TrendingUp/Down, zero-delta neutral).
- **Engine tabs** (All engines / ChatGPT / Claude / Perplexity) styled as the prototype: active =
  `--layer-visibility-soft`+`--layer-visibility`, inactive = `--bg-hover`+`--text-secondary`.
- **HONESTY:** if there are no real competitors (mock/degenerate data), show the brand bar honestly (e.g. brand at
  its real share) — do NOT fabricate competitor bars or imply a distribution the data doesn't have. Keep the
  existing empty/insufficient-data states.
- **A subtle left accent strip** (`--layer-visibility`, ~3px, low opacity via color-mix) on the card signals the
  Visibility layer — restrained, information-bearing (which layer this is), not decorative.

## TILE 2 — `mention-source-matrix.tsx`: richer 2×2 (keep the archetype logic)
- Keep the 2×2 archetype matrix + the correct MS-01 logic (do NOT touch the thresholds or the NULL→'N/A' handling).
- **Enhancement:** the ACTIVE archetype quadrant lit with the semantic colour (`--success`/`--warning`/`--info`/
  `--danger` `-soft` bg + a solid dot + coloured label); inactive quadrants muted (`--bg-hover`, `--text-tertiary`).
  Colour = meaning (the archetype's quality) + the dot + the label text (not colour alone).
- The three metric chips (Mention / Citation / Ratio) in small `--bg-subtle` cards, numbers in `--font-mono`
  tabular-nums. **Ratio NULL still shows 'N/A'** (the div-by-zero contract — do not regress).

## TILE 3 — `fan-out-tree.tsx`: richer rows (keep the data + the unique keys)
- Keep the {location}-substituted prompts, the latest-audit scoping, and the UNIQUE React keys (do NOT regress the
  fixes).
- **Enhancement:** each sub-query row in a subtle `--bg-subtle` pill; a **left accent border** whose presence marks
  `above_threshold` (e.g. `--layer-visibility` when above threshold, muted `--bg-active` when not — the spec's
  "above_threshold highlighted"); the similarity score in `--font-mono` with a **small quality dot** coloured by the
  `--health-*` ramp (so 0.50 reads as "moderate" via colour + the number, not number alone). Rank in `--font-mono`.

## TILE 4 — `topical-gap-list.tsx`: richer leverage cues (keep the sort + the badge)
- Keep the sort by `cross_prompt_impact DESC` and the "HIGH LEVERAGE — fix this → improves N prompts" badge (≥2).
- **Enhancement:** each gap row in a `--bg-subtle` pill; the **leverage badge coloured by impact** (`--danger`/
  `--warning` `-soft` for high leverage, muted for low) — the "fixes N" cue reads via colour + the number + the
  badge text; the impact number in `--font-mono` tabular-nums. Keep the graceful "No topical gaps detected" empty
  state.

## CROSS-CUTTING (all four tiles)
- **Card treatment:** `--bg-elevated` bg, `--border-default` border, 12px radius, the subtle `--layer-visibility`
  left accent strip (color-mix, low opacity). Consistent across all four so they read as one family.
- **Numbers:** `--font-mono` + `tabular-nums` everywhere (metrics, %, scores) — the standard's rule.
- **NO decorative effects:** no gradients, glows, neon, heavy shadows (the standard's anti-patterns). Every colour
  encodes something (layer identity, score quality, archetype, leverage, brand-vs-competitor).
- **Accessibility:** WCAG AA contrast on the dark base; **never colour alone** (chips/labels/icons/position carry
  meaning); `--focus-ring` on interactive elements; honour `prefers-reduced-motion` (the S2 reset is present — don't
  add motion that ignores it); keep ARIA per FIX 13.
- **Responsive:** keep the hub's `grid-cols-1 lg:grid-cols-2`; SoV + matrix stack on `<lg`; bars/rows wrap cleanly
  on narrow. The dashboard SoV strip (`dashboard-sov-strip.tsx`) uses the same bar visual — apply the same enhanced
  bar treatment there so the two stay consistent (it's already aggregation/key-fixed).

## INVARIANTS (do NOT break)
- **Visual only** — do NOT change data logic, queries, the Inngest functions, the API routes, or the SoV/fan-out/
  trend calculations. This touches ONLY the four visibility components (+ dashboard-sov-strip for consistency).
- **Preserve every manual-pass fix:** brands.domain resolution, engine aggregation, {location} substitution,
  latest-audit scoping, unique React keys, CPR-01 degradation, tier-gating, NULL→'N/A' ratio, the percentage units
  (MS-01/MS-02 — shares are 0–100, ratio 0–1).
- **Tokens only, never invent** — map every colour to an existing token; color-mix for faint fills (RT-01, no
  hex-alpha on var()). If genuinely nothing fits, FLAG it rather than hardcoding a hex.
- Keep the file names (sov-donut.tsx stays named that even though it now renders bars — avoid import churn / the
  earlier route-404 class of regression). Optionally leave a one-line comment noting it renders bars now.
- Don't touch adjacent non-visibility components (scope tightly).
- 68/68 tests stay green (visual change shouldn't affect them; if a test asserts a donut-specific DOM detail, note
  it — that's a test to update in the automated track, not a reason to keep the donut).

## VERIFY (on the real screen — not just tests)
1. Reload `/brands/6ece067f-063c-436b-ac42-7952c7d7a271/visibility` — the SoV tile now shows **ranked horizontal
   bars** (brand highlighted in the visibility colour + "you" chip, competitors muted), NOT a donut; percentages in
   mono; legible at a glance.
2. Mention-Source: active archetype quadrant lit semantically; Ratio NULL still 'N/A'.
3. Fan-out: rows richer, above_threshold marked, similarity dot coloured by quality; {location} still substituted,
   no duplicate-key errors.
4. Topical gaps: leverage badges coloured; sort + "HIGH LEVERAGE" badge intact; empty state graceful.
5. Dashboard SoV strip: same enhanced bar visual, consistent with the hub.
6. **Console: 0 errors** (no duplicate-key regressions). Accessibility: tab through — focus rings visible; meaning
   readable without colour.
7. Both themes (dark default + `[data-theme=light]`) legible. Responsive: tiles stack/​wrap on narrow.
8. 68/68 tests green (or the only diffs are donut-specific DOM assertions to update — report them).

## REPORT
- Each tile's enhancement (SoV donut→bars aligned to prototype; matrix semantic quadrant; fan-out threshold+quality
  dots; topical leverage colour) — with the exact tokens used (confirm all real, none invented).
- **Screenshots/confirmation** the SoV renders as bars, legible; the other three richer; dashboard strip consistent.
- Confirm: visual-only (no data/logic/route/Inngest changes); every manual-pass fix preserved; color-mix not
  hex-alpha; WCAG AA + colour-not-alone + focus + reduced-motion; 68/68 green; scoped to the visibility components.

## NOTE
This aligns SoV to its own prototype (bars) + adds the restrained rich layer the design standard calls for — it is
NOT a trend-chasing redesign. It also closes a review gap: the donut was an implementation drift from the prototype
that on-screen review caught late. Going forward, UI review should diff shipped screens against the prototype
(`visibleau-phase2-prototype-FIXNN.jsx`), not only the prompt/LLD text — visual drift is the visual equivalent of
schema drift. After this, the visibility tiles are both correct (manual pass) and polished; the automated test track
(Sections 1–5) can proceed and should assert the fixed behaviour.
