# Claude Code — FIX: on-demand "Generate report" button no-ops (schedule gate applied to manual path)

**Confirmed cause (diagnosis):** the "Generate report" button → `POST /api/brands/[id]/reports/generate` emits
`trend/aggregated`; `generate-narrative-report` runs but early-returns `{ skipped: true, reason:
"no_active_delivery_schedule" }` (line 56/91) because there are **zero delivery schedules**. Silent no-op — the
full chain works, but the schedule gate blocks it.

**The real issue:** the ON-DEMAND button is wired to the AUTOMATIC pipeline's event + schedule gate. Those are two
different use cases sharing one path.

## ✅ THREE-SOURCE CHECK (done) — the schedule gate is CORRECT for the automatic path; the button must bypass it
- **LLD (generate-narrative-report spec, ~8480):** the function *"listens on `trend/aggregated`... chains trend
  aggregation → report generation without a separate cron. **Only fires when report_delivery_schedules has an
  active row for this brand (check before generation).**"* + monthly, concurrency 5, *"fired after
  aggregate-visibility-trend completes for a period."* → **the schedule gate is INTENTIONAL and CORRECT for the
  automatic (scheduled monthly) path.** Do NOT remove it (that would violate the LLD — rules out "Option C").
- **§9 (the button):** `POST …/reports/generate` — *"generate a narrative (Growth+); emits the generation path."*
  → implies **on-demand** generation (explicit user click → a report now). But the route currently emits
  `trend/aggregated` (the automatic pipeline's INTERNAL event, normally emitted by `aggregate-visibility-trend`),
  so the on-demand click inherits the schedule gate it shouldn't have.
- **The correct model:** an explicit "Generate report" click IS the authorization — it should NOT require an active
  delivery schedule. The schedule gate governs the AUTOMATIC path only. So: **the manual path must bypass the
  schedule gate; the automatic `trend/aggregated` path keeps it.**
- **Design-gap note:** the LLD detailed the automatic path but §9's on-demand button is thin — it never specified
  HOW on-demand bypasses the gate. This fix makes the LLD-consistent choice (distinguish manual from automatic).

## THE FIX — distinguish the manual (on-demand) trigger from the automatic (scheduled) one
Keep the Inngest architecture (async generation + PDF is slow; don't make the route synchronous — rules out
"Option B" as primary). Make the manual path bypass the schedule gate:

### 1. The route emits a MANUAL-flagged event (or a distinct event)
In `app/api/brands/[id]/reports/generate/route.ts`, the on-demand POST should NOT masquerade as the automatic
pipeline event. Two acceptable ways — pick the cleaner for the codebase:
- **(preferred) Add `manual: true` to the event data:**
  `inngest.send({ name: 'trend/aggregated', data: { brandId, organizationId, periodLabel, periodType, manual: true } })`
  — keeps one function, one event name, but marks manual invocations.
- **OR emit a distinct event** (e.g. `report/generate.requested`) that the function ALSO listens on (add to its
  triggers), reserving `trend/aggregated` for the automatic pipeline. (More explicit, but two triggers to maintain.)
Use the `manual: true` flag approach unless the codebase convention favours distinct events.

### 2. The function bypasses the schedule gate when manual
In `inngest/functions/generate-narrative-report.ts`, the `check-schedule-and-template` step:
- If `event.data.manual === true` → **SKIP the active-delivery-schedule check** and proceed straight to template
  lookup + narrative generation (an explicit user request doesn't need a schedule).
- If NOT manual (the automatic `trend/aggregated` path) → **keep the existing schedule gate** (LLD-correct: only
  generate on an active schedule).
- Either way, still resolve the template (the seeded is_default 'Default Report' if the org has no custom one — the
  fallback to DEFAULT_SECTIONS already exists), run RULES 1–11, INSERT generated_reports, render PDF, emit
  `report/generated`.
```bash
sed -n '40,95p' inngest/functions/generate-narrative-report.ts   # the schedule-gate step to make conditional
sed -n '50,70p' "app/api/brands/[id]/reports/generate/route.ts"  # where the event is emitted
```

### 3. Return honest feedback (no more silent no-op)
- The route already returns 202 "Report generation started" — that's fine for the async manual path (a report WILL
  now be created). But ensure the UI reflects it: after the POST, the reports list re-fetches (it does), and the new
  report appears with a **'generating'** derived status (pdf_url null) → flips to 'ready' when the PDF lands. So the
  user sees a report card appear, not "nothing."
- (Optional polish: if generation is quick in mock/dev, a short poll/refresh shows the 'ready' report. The derived
  status (CM-01) already handles generating→ready.)

## INVARIANTS
- **Do NOT remove the schedule gate** — it's LLD-spec'd for the automatic path. Only BYPASS it for `manual: true`.
- The automatic `trend/aggregated` path (from aggregate-visibility-trend, no manual flag) keeps the gate unchanged.
- Keep `selectModel(tier, engine, 'narrative_generation')` (no hardcoded model — LLD MS-02), concurrency 5, the
  `report/generated` emit after INSERT, the is_default/DEFAULT_SECTIONS template resolution.
- subscriptions.tier for the Growth+ gate (not organizations.tier).
- TS strict; full `tsc --noEmit` clean after (core); don't reintroduce the 3 fixed errors.

## VERIFY (on screen — the real test)
1. **Click "Generate report"** on `/brands/[brandId]/reports` (Agency brand, NO delivery schedule) → a report is
   now CREATED (not skipped): a report card appears in the list with a **'generating'** badge, then **'ready'** when
   the PDF is done. No silent no-op.
2. **Open the generated report** (`/reports/[reportId]`) → it renders the narrative + section summaries, and the
   **PDF downloads** (pre-signed URL). Confirm the narrative pulls Sprint 3 data (the §14 seam — SoV / mention-source
   / fan-out / topical gaps sections render where data exists; the 5 wired sections).
3. **Inngest dashboard** (:8288) → `generate-narrative-report` fired and completed (not skipped) for the manual
   click; emitted `report/generated`.
4. **Automatic path unbroken:** the schedule gate still applies to `trend/aggregated` events WITHOUT manual (i.e.
   an audit-driven trend event for a brand with no schedule still correctly skips). (Confirm the gate logic still
   branches for non-manual.)
5. Full core `tsc --noEmit` clean; 78 tests green (add/adjust a test asserting manual bypasses the gate + automatic
   still gates, if feasible).

## REPORT
- The manual-vs-automatic distinction implemented (manual flag or distinct event) + where.
- The schedule gate now conditional (bypassed for manual, kept for automatic) — with the exact branch.
- **On-screen: a report is now generated on click** (card appears, generating→ready), the report detail + PDF
  render, the narrative includes Sprint 3 data.
- Inngest fired + completed (not skipped); report/generated emitted.
- Automatic path still gates on schedule (unchanged for non-manual).
- Confirm: schedule gate NOT removed (only bypassed for manual); selectModel kept; subscriptions.tier; core tsc
  clean; 78 green.

## NOTE — design gap this closed
The LLD fully spec'd the AUTOMATIC path (trend → scheduled monthly report, schedule-gated) but §9's on-demand button
was underspecified ("emits the generation path") — it never said how on-demand should bypass the schedule gate, and
the implementation wired the button to the automatic event, so it inherited the gate → silent no-op. This fix
separates the two use cases (manual bypasses, automatic gates) per the LLD's clear intent for the automatic path.
Worth noting in canon that the on-demand generate path needs its own spec line (manual bypasses schedule) so it's
not ambiguous for future sprints.
