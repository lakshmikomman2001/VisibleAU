# Claude Code — FIX (Tier 3, defense-in-depth): explicit org checks on RLS-only routes — BATCHED, confirm-first

Final security tier. RLS now genuinely enforces (Tier 2 wrapper + Tier 1A non-superuser role + table policies +
WITH CHECK). Tier 3 adds **explicit `organization_id = currentUser.organizationId` (and brand-ownership-via-org)
checks** to the ~20 routes that currently rely on RLS ALONE — as **defense-in-depth** (a second line, so isolation
holds even if RLS context is ever wrong). The 3 task routes already have this (FE-4). Extend the same pattern to
the rest.

**This is belt-and-suspenders, NOT the primary defense** — RLS is now the primary. So these checks must **fail
closed the SAME way RLS does: cross-org → 404, never 401** (CLAUDE.md §8: returning 401 on wrong-org access leaks
org membership).

> ⚠️ **BATCH THIS to avoid a crash.** A prior ~all-routes pass crashed Claude Code (exit 3221226505 / OOM). So:
> **STEP 1 = confirm-first (read-only enumeration + report the classified route list) and STOP for the list.**
> Then apply the checks in **WAVES of ≤7 routes**, running tests + reporting after each wave, rather than editing
> ~20 files in one pass. If told to proceed, do Wave 1 (≤7), report, then Wave 2, etc.

---

## STEP 1 — CONFIRM-FIRST: enumerate + classify the RLS-only routes (read-only, then report)
```bash
# All routes that call withRlsContext (rely on RLS):
grep -rln "withRlsContext" app/api/ --include=*.ts
# Of those, which ALREADY have an explicit org/brand ownership check vs which are RLS-only:
for f in $(grep -rln "withRlsContext" app/api/ --include=*.ts); do
  if grep -qE "organizationId|organization_id|getBrandForOrg|assertBrandAccess|brands.*organizationId" "$f"; then
    echo "HAS-CHECK: $f"
  else
    echo "RLS-ONLY:  $f"
  fi
done
```
Build the **classified list**. For each **RLS-ONLY** route, determine its scoping shape:
- **(O) org-scoped:** operates on rows with `organization_id` → add
  `organization_id = currentUser.organizationId` check (or verify the queried row's org).
- **(B) brand-scoped:** operates on a specific brand (`brandId` param) → verify the brand belongs to the user's
  org: `brands.organizationId = currentUser.organizationId` (the `getBrandForOrg`/inner-join pattern, LLD ~6581) →
  404 if not.
- **(G) global/service:** routes touching only global/seed tables (vertical_packs, lookup) OR Inngest/service_role
  paths that bypass RLS by design → **NO check, EXCLUDE** (adding an org check would be wrong).
- Exclude the 3 task routes (already have checks) and any HAS-CHECK route.

**Report the classified list** — RLS-ONLY routes needing checks, each tagged (O)/(B), grouped into waves of ≤7 —
then STOP and await "proceed with Wave 1" (or apply Wave 1 and report if instructed to run straight through in
waves). Do NOT edit all ~20 in one pass.

## STEP 2 — Apply checks in WAVES (≤7 routes each; test + report per wave)
For each RLS-ONLY route in the wave, add the explicit check matching its shape, preserving the **404 convention**:

**(O) org-scoped route:**
```ts
// after getCurrentUser() + inside/around the withRlsContext query:
// If the route loads a resource, verify its org matches (or the query already scopes by org).
// If a resource is found but belongs to another org → 404 (NOT 401, NOT 403).
if (resource && resource.organizationId !== currentUser.organizationId) {
  return NextResponse.json({ error: "Not found" }, { status: 404 });
}
```

**(B) brand-scoped route (brandId param):**
```ts
// Verify the brand belongs to the caller's org BEFORE operating on it:
const brand = await withRlsContext(currentUser.organizationId, (tx) =>
  tx.select().from(brands)
    .where(and(eq(brands.id, brandId), eq(brands.organizationId, currentUser.organizationId)))
    .limit(1)
);
if (!brand.length) {
  return NextResponse.json({ error: "Not found" }, { status: 404 }); // cross-org or missing → 404
}
```
(Or reuse the existing `getBrandForOrg(brandId, orgId)` helper if present — prefer the canonical helper over
hand-rolling.)

- **404 on cross-org, never 401/403** (CLAUDE.md §8 — don't leak org membership). Keep the 401-if-unauthenticated
  guard (that's for NO session, distinct from wrong-org).
- The check is IN ADDITION to RLS/`withRlsContext`, not a replacement — keep the wrapper.
- Reuse existing helpers (`getBrandForOrg`, `getCurrentUser`) — don't introduce new patterns.

## STEP 3 — Do NOT touch
- (G) global/seed routes (vertical_packs, lookup/enum) and Inngest/service_role paths (bypass RLS by design).
- The 3 task routes + any HAS-CHECK route (already done).
- The Tier 2 wrapper, the app role, the table policies — unchanged.
- Do NOT change route behaviour beyond adding the ownership guard (same responses for legitimate same-org calls).

## INVARIANTS — do not violate
- Cross-org → **404** (never 401/403); unauthenticated → 401 (unchanged). Don't leak org membership.
- Checks are defense-in-depth ON TOP of RLS — keep `withRlsContext`; don't remove RLS reliance.
- (O) uses org-id match; (B) uses brand→org ownership; (G) gets NO check.
- Reuse canonical helpers; no new isolation patterns.
- Same-org legitimate requests behave identically (no over-restriction, no new 404s for valid access).
- Batched: ≤7 routes/wave, tests + report per wave. Don't edit ~20 files in one pass (crash risk).

## VERIFY — per wave
1. Each patched route: legitimate **same-org** request still returns correct data (no regression / no false 404).
2. Each patched route: **cross-org** request (another org's resource / brandId) returns **404** (not 401, not the
   data). Test as `visibleau_app` (non-superuser) so both RLS AND the explicit check are exercised.
3. (B) routes: a brandId belonging to another org → 404.
4. Full suite green after each wave; E2E RLS isolation still 11/11; no new permission/404 failures for valid
   same-org access.
5. After the FINAL wave: `grep` confirms every intended RLS-ONLY route now HAS an explicit check (re-run the STEP 1
   classifier — the RLS-ONLY list should be empty except (G) globals/service paths).

## REPORT
- **STEP 1 classified list:** all `withRlsContext` routes → HAS-CHECK / RLS-ONLY / (G)-excluded; the RLS-ONLY set
  needing checks, tagged (O)/(B), grouped into waves.
- Per wave: which routes patched, the check added (O org-match vs B brand-ownership), 404 convention preserved,
  test results.
- Final: the STEP 1 classifier re-run shows no remaining RLS-ONLY tenant routes (only (G) globals/service remain);
  full suite green; E2E RLS 11/11.
- Confirm invariants: 404-not-401 on cross-org, defense-in-depth (wrapper kept), globals/service untouched, helpers
  reused, no same-org regression, batched execution.

## NOTE — after Tier 3, the cross-tenant security remediation is COMPLETE
All layers closed: RLS context pinned to connection (Tier 2), app runs as non-BYPASSRLS role so RLS actually
enforces (Tier 1A), all tenant tables have read+write RLS policies (policies + WITH CHECK), and every tenant route
has an explicit org/brand ownership check as defense-in-depth (Tier 3). The cross-tenant exposure the E2E test
uncovered — which turned out to be RLS fully bypassed in production incl. the subscriptions/billing table — is
sealed at every layer.

**Go-live items still banked (NOT code — track separately):** (1) the hand-applied prod migrations
(`rls-missing-tables.sql`, `tier1a-app-role.sql`, `rls-with-check.sql`, `tier1a-app-role`) must be in the MIGRATION
PIPELINE, not ad-hoc; (2) deployed prod app must use the non-superuser role; (3) prod Inngest Cloud keys + serve
endpoint; (4) prod test-data cleanup; (5) `llm_response_cache` RLS-disabled sanity check; (6) Section 5 (QA) to
finish the test track; (7) the LLD v8.70 version bump. Consider consolidating these into one go-live checklist.
