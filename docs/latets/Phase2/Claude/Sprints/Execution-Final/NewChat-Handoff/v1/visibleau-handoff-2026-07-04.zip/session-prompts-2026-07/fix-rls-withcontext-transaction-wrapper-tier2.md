# Claude Code — FIX (Tier 2, security root cause): `withRlsContext` transaction wrapper — pin RLS context to the query connection

**This fixes the ROOT CAUSE of the cross-org leak.** Diagnosis confirmed: `setRlsContext` sets
`app.current_org_id` at the **session level** on a pooled connection, but the subsequent `db` queries may run on a
DIFFERENT pooled connection that never received the `SET` → `current_setting('app.current_org_id', true)` returns
empty/stale on the query connection → RLS policy (`USING (organization_id::text = current_setting('app.current_org_id',
true))`) fails open → cross-org data access.

**The fix:** make the context-set and the queries it guards run on the **SAME connection, in one transaction,
using `SET LOCAL`** (transaction-scoped — dies with the transaction, cannot leak to the next borrower of that
pooled connection). This makes `setRlsContext`/RLS actually work at the connection level for every table that has
an RLS policy.

> **Scope: Tier 2 ONLY.** This prompt does the transaction wrapper + retrofits routes to use it. It does NOT (yet):
> add RLS policies to the 13 unprotected tables (separate prompt), add explicit org checks to the 20 routes
> (Tier 3, separate), or change the DB role (Tier 1A, separate). The 3 task-route explicit checks already applied
> stay as defense-in-depth — do NOT remove them. The wrapper is the foundation the other tiers build on.

> **Investigate-first. Confirm the current implementation before changing.** Read:
> - `db/client.ts` (or `src/db/client.ts`) — the current `setRlsContext` impl + the db client/pool type (Drizzle
>   over node-postgres `Pool`? postgres.js? Supabase pooler?). Confirm whether `setRlsContext` uses session-level
>   `set_config(..., false)` / plain `SET`, and whether it shares a connection with the queries.
> - `lib/db/rls.ts` (canon references this for RLS context) if present.
> - 2-3 representative routes (a task route already patched, a Phase 1 route, a Phase 2 route) to see the current
>   `getCurrentUser() → setRlsContext(db, orgId) → db.<queries>` shape, including the cross-org-404 convention.
> - How Drizzle exposes transactions in this setup (`db.transaction(async (tx) => {...})`) and whether a `tx` runs
>   all its statements on one connection (it must — that's the point).
> Report the current impl + pool type + how transactions pin a connection, then implement.

---

## THE FIX

### 1. Implement `withRlsContext` (transaction-scoped, one connection)
Create a wrapper that opens a transaction, sets the org context with `SET LOCAL` on that transaction's connection,
runs the caller's queries on the SAME `tx`, and returns the result. Conceptually (adapt to the actual client/
Drizzle API):
```ts
// db/client.ts (or wherever setRlsContext lives)
export async function withRlsContext<T>(
  orgId: string,
  fn: (tx: TxType) => Promise<T>,
): Promise<T> {
  return db.transaction(async (tx) => {
    // SET LOCAL: transaction-scoped, on THIS connection only. Dies with the txn — cannot leak
    // to the next pool borrower. Parameterised safely (orgId is a UUID; validate/escape — do NOT
    // string-concat raw user input into SQL; use set_config with a bound param).
    await tx.execute(sql`SELECT set_config('app.current_org_id', ${orgId}, true)`); // 3rd arg true = LOCAL
    return fn(tx);
  });
}
```
- **`set_config(..., true)`** (or `SET LOCAL`) = transaction-local. NOT `false` / plain `SET` (session-level — the
  bug). Confirm the SDK runs this on the transaction's pinned connection.
- **`orgId` is bound, not concatenated** — pass as a parameter to `set_config` (no SQL injection). It's a UUID;
  optionally validate it's a UUID before use.
- All queries inside `fn` use the provided `tx`, so they're on the SAME connection that has the `SET LOCAL`.

### 2. Retrofit routes to use `withRlsContext`
Convert the route pattern from:
```ts
await setRlsContext(db, currentUser.organizationId);
const rows = await db.select()...;   // ← may run on a different connection (the bug)
```
to:
```ts
const rows = await withRlsContext(currentUser.organizationId, async (tx) => {
  return tx.select()...;   // ← same connection as the SET LOCAL
});
```
- Preserve the **cross-org-404 convention** (CLAUDE.md §8): if a resource is found-but-other-org, RLS returns
  empty → return **404**, never 401 (don't leak org membership). The empty-check stays.
- Keep the `getCurrentUser()` → 401-if-unauthenticated guard.
- Retrofit the org-scoped routes that currently call `setRlsContext` so their queries run inside the wrapper. (The
  3 task routes: keep their explicit org checks AND route them through the wrapper.)
- **Inngest functions** that call `setRlsContext` server-side: route them through `withRlsContext` too (same
  vulnerability, same fix) — their `db` work must run on the context-pinned connection.

### 3. Keep `setRlsContext` working OR deprecate cleanly
- If many call sites exist, either (a) reimplement `setRlsContext` to be a thin shim that's only safe inside a
  transaction, OR (b) replace call sites with `withRlsContext`. Prefer `withRlsContext` as the canonical API; if
  `setRlsContext` remains, document that it MUST be used within a transaction or it's unsafe. Report which approach
  you took and how many call sites were converted.

## INVARIANTS — do not violate
- **Transaction-scoped `SET LOCAL` / `set_config(..., true)` ONLY** — never session-level `SET` / `set_config(...,
  false)` (that's the bug). Context + queries MUST share one pinned connection (the transaction).
- `orgId` bound as a parameter (no string concatenation into SQL).
- Preserve the cross-org-404 convention and the 401-if-unauthenticated guard.
- Do NOT remove the 3 task-route explicit org checks (defense-in-depth stays).
- Tier 2 scope only — do NOT add RLS policies to the 13 tables, do NOT add org checks to the 20 routes, do NOT
  change the DB role here.
- Global/seed tables (`vertical_packs`, lookup/enum tables — no `organization_id`) are NOT tenant-scoped; the
  wrapper is harmless for them but don't add org logic to them.
- Don't regress existing passing tests (1285+).

## VERIFY — prove the leak is CLOSED (the reproduction that found it must now pass)
1. **The definitive proof — `current_setting` on the query path now returns the org, not empty:**
   ```ts
   // inside withRlsContext(orgA, tx => ...), run:
   //   SELECT current_setting('app.current_org_id', true)
   // → must return orgA (NOT empty). Empty was the bug; non-empty on the SAME tx connection = fixed.
   ```
   Run this and confirm it returns the org id.
2. **Cross-org isolation holds under the pool:** the Sprint 2 E2E brand-isolation test (user 2 cannot see user 1's
   brand/tasks) — the one that EXPOSED this — now passes via RLS (not just the explicit task-route checks). If
   possible, temporarily test a route that relies on RLS-only (has a policy, no explicit check) and confirm
   cross-org returns empty/404, not foreign rows.
3. **Concurrent/pooled stress (if feasible):** fire concurrent requests for different orgs and confirm no
   cross-contamination (org A's request never sees org B's data) — proving the `SET LOCAL` doesn't leak across pool
   borrowers.
4. **No regression:** the full suite (backend unit/E2E, frontend unit/E2E — 1285+ tests) stays green. Routes still
   return correct data for the CORRECT org (the wrapper didn't over-restrict). Cross-org still 404s.
5. **RLS role caveat:** these RLS checks must be validated under a NON-superuser role (`rls_test_role`) — superuser
   bypasses RLS and gives a false pass. Confirm the role used.

## REPORT
- Current `setRlsContext` impl + pool/client type + why it leaked (session-level SET not pinned to query
  connection).
- The `withRlsContext` wrapper implemented (`SET LOCAL`/`set_config(...,true)`, bound orgId, tx-pinned); how many
  route + Inngest call sites converted; whether `setRlsContext` was deprecated or shimmed.
- **Reproduction proof:** `current_setting('app.current_org_id', true)` on the query path now returns the org (was
  empty); the E2E brand-isolation test passes via RLS; (if run) concurrent-org stress shows no cross-contamination.
- No regression: full suite green; correct-org data still returned; cross-org 404s preserved.
- Confirm invariants: tx-scoped SET LOCAL only, orgId bound, 404 convention kept, task-route explicit checks
  retained, Tier 2 scope only (13 tables / 20 routes / DB role NOT touched). RLS validated under non-superuser role.

## NOTE — this is the foundation; tiers follow
With the wrapper in place, RLS actually works for every table that HAS a policy. Remaining, as separate reviewed
passes: (Tier "13 tables") add RLS policies to the org-scoped tables that have none — until then those tables are
protected only by explicit checks, not RLS, so this wrapper doesn't cover them; (Tier 3) explicit org checks on the
20 remaining routes as defense-in-depth; (Tier 1A) non-superuser app DB role so the app can't bypass RLS even if
something's wrong. Recommended next: the 13-tables RLS prompt (with an explicit confirmed list of which 13), since
those tables are exposed regardless of this wrapper.
