# Claude Code — DIAGNOSE + FIX: SoV bar fill colours are wrong (a competitor is highlighted, the brand isn't)

On the enhanced SoV bars (`sov-donut.tsx`, now rendering ranked bars), the **fill colour is assigned to the wrong
rows.** Observed on the Agency brand (`026acf75-188f-4a9f-9126-6ed2fb324f91`, brand = agencyseo.com.au):
- **bondiplumbing.com.au (100%)** — bar fill is MUTED/grey
- **hipages.com.au (50%)** — bar fill is BLUE (`--layer-visibility`)  ← a COMPETITOR is highlighted in the brand colour
- **agencyseo.com.au (0%, the actual brand, has the "you" chip + blue dot)** — bar fill is muted

**Intended design (the approved mockup + prototype FIX17 ~L1683):** the BRAND's bar = `--layer-visibility` (blue,
highlighted); COMPETITOR bars = muted (`--bg-active`). Currently a competitor is getting the brand colour and the
brand is muted — the fill logic is not correctly tied to "is this the brand."

> I've mis-read this from screenshots twice — do NOT guess. READ the actual code and report the real logic before
> fixing.

## STEP 1 — Read the current bar-fill logic and REPORT it (no fix yet)
```bash
cat components/domain/visibility/sov-donut.tsx
grep -n "isYou\|isБrand\|isBrand\|layer-visibility\|bg-active\|background\|fill\|brandDomain\|\.domain" components/domain/visibility/sov-donut.tsx
```
Report exactly:
- How each bar's **fill colour** is decided — what boolean/condition selects `--layer-visibility` vs the muted
  fill? (e.g. `isYou`, `row.isBrand`, `domain === brandDomain`, or index 0?)
- How is "the brand row" identified in the data the component receives — is there an `isYou`/`isBrand` flag per row,
  or is it derived by matching a domain, or is it assuming the first/highest row is the brand?
- **Why is hipages (a competitor) getting blue while agencyseo (the brand) is muted?** Likely causes:
  - (a) the fill is keyed off **position/rank** (e.g. highest share = highlighted) instead of **is-brand** — so the
    top competitor gets blue, not the brand;
  - (b) the `isYou`/brand flag isn't set correctly on the rows (the brand row's flag is false / a competitor's is
    true);
  - (c) the brand-row detection matches the wrong domain (the contaminated-data domain-variant issue bleeding into
    the highlight logic).
Classify which, and report the exact line.

## STEP 2 — FIX: fill colour must follow IS-BRAND, never rank/position
Make the bar fill unambiguous:
- **Brand row** (the row whose domain === the brand's own `brands.domain`, i.e. the `isYou`/`isBrand` row) → fill
  `--layer-visibility`; label `--text-primary`; the "you" chip.
- **Every competitor row** → muted fill `--bg-active`; label `--text-secondary`; no chip.
- The highlight is driven by **is-this-the-brand**, NOT by share magnitude or list position. A competitor with 100%
  share must still render MUTED; the brand at 0% must still render in `--layer-visibility` (blue) with the "you"
  chip. (On this contaminated Agency brand that means: agencyseo = blue+you even at 0%; bondiplumbing + hipages =
  muted even at 100%/50%.)
- Reuse the SAME is-brand determination the rest of the component already uses for the "you" chip / blue dot — the
  chip is on the correct row (agencyseo), so bind the FILL to that same condition. The bug is almost certainly that
  the chip uses is-brand but the bar fill uses something else (rank/index) — unify them onto is-brand.
- Keep everything else from the enhancement (bars, sort by share DESC, mono percentages, engine tabs, accent strip,
  unique keys, empty state).

## INVARIANTS
- Fill colour follows IS-BRAND only — never rank/position/share magnitude.
- `--layer-visibility` (your real BLUE token) for the brand; `--bg-active` muted for competitors. Do NOT introduce
  any new colour (no purple, no invented hex) — tokens only.
- The "you" chip + blue dot + blue bar fill must all be on the SAME row (the brand) — consistent.
- Sort stays by share DESC (so bondiplumbing 100% is still top of the list — it's just muted, not highlighted).
- Visual/logic-of-highlight only — do NOT change the SoV data, aggregation, or which rows appear. Don't regress the
  manual-pass fixes.
- Apply the same fix to `dashboard-sov-strip.tsx` if it has the same rank-vs-brand fill bug (keep them consistent).
- 68/68 tests green.

## VERIFY (on screen)
1. Reload `/brands/026acf75-188f-4a9f-9126-6ed2fb324f91/visibility` — the **agencyseo.com.au** row (the brand, with
   "you") is now the BLUE/highlighted bar; **bondiplumbing.com.au and hipages.com.au** (competitors) are MUTED —
   even though they have higher shares. No competitor is blue.
2. Cross-check on the Growth Bondi (`6ece067f-...`): the brand bar (bondiplumbing.com.au, "you") is blue;
   hipages is muted.
3. The "you" chip, blue dot, and blue bar fill are all on the same (brand) row.
4. Dashboard SoV strip: same corrected highlight.
5. No new colours (still your blue token); no duplicate-key errors; 68/68 green.

## REPORT
- STEP 1: the exact current fill logic + why a competitor was highlighted (rank-based vs is-brand; the line).
- STEP 2: the fix — fill now bound to is-brand, matching the "you" chip's condition.
- VERIFY: screenshot/confirm the brand row is blue and competitors muted on BOTH the Agency and Growth brands,
  regardless of share magnitude.
- Confirm: your real `--layer-visibility` blue used (no invented colour); is-brand drives the highlight; data/
  aggregation untouched; strip consistent; 68/68 green.

## NOTE
The enhancement's colours are correct (your blue `--layer-visibility` token — not purple); the bug is that the bar
FILL was keyed to the wrong condition (rank/position) so a high-share competitor got highlighted instead of the
brand. This is a highlight-logic fix, not a colour/token change. After it, the SoV bars correctly show the brand as
the focal (blue) bar with competitors muted — the intended design.
