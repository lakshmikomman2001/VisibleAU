# Claude Code — VERIFY + FIX (dead-event risk): Sprint 3 visibility functions — `audit.completed` (dot) vs `audit/completed` (slash)

**This is the SAME slash-vs-dot trap that caused the audit/start saga** (four functions that passed all tests but
emitted/listened on dead events — including scheduled audits silently never firing in prod). The Sprint 3 **prompt**
wrote **`audit/completed` (slash)** in 7 places (§8 + the §10 paste-block), but the **LLD canon is `audit.completed`
(dot)** — unambiguous: LLD line 2139 states *"delivery=dot ('audit.completed'). Phase 2 matches the BUILT
convention,"* and the Sprint 8 VALID_EVENTS list uses `audit.completed` (dot). `audit/completed` (slash) appears
ZERO times in the LLD.

The 6 Sprint 3 Inngest functions were just built. **If they listen on `audit/completed` (slash) while the audit
pipeline emits `audit.completed` (dot), all 6 visibility functions are DEAD** — SoV, visibility trends, fan-out,
topical gaps, citation classification silently never fire on real audits, despite 68/68 green tests (tests mock the
event system — the exact false-negative that hid the audit/start bug). **Verify against the built code first, then
fix only if there's a real mismatch.**

> ⚠️ Green tests do NOT confirm this is fine — the audit/start functions also had green tests while dead. Only the
> actual emit-vs-listen string comparison in the built code settles it.

---

## STEP 1 — VERIFY: what do the 6 functions LISTEN on, and what does the pipeline EMIT?
```bash
# What event do the 5 audit-triggered visibility functions listen on? (dot or slash)
grep -rnE "audit\.completed|audit/completed" \
  inngest/functions/calculate-share-of-voice.ts \
  inngest/functions/aggregate-visibility-trend.ts \
  inngest/functions/simulate-query-fan-out.ts \
  inngest/functions/calculate-topical-gaps.ts \
  inngest/functions/classify-citation-sources.ts
# (track-brand-web-mentions is a weekly cron — not audit-triggered; check separately if relevant)

# What event does the audit pipeline actually EMIT on completion?
grep -rnE "audit\.completed|audit/completed|inngest.send|step.sendEvent" \
  inngest/functions/run-audit*.ts lib/audit/ app/api/audits/ | grep -iE "completed|send"

# Also: does ANYTHING emit audit.completed at all? (if nothing emits it, that's a separate gap)
grep -rnE "'audit\.completed'|\"audit\.completed\"|name:.*audit\.completed" inngest/ lib/ app/ --include=*.ts
```

**Report the exact event strings** the functions listen on vs what the pipeline emits, then classify:
- **(A) MATCH on dot** — functions listen on `audit.completed` (dot), pipeline emits `audit.completed` (dot). ✅
  The build correctly used the LLD convention (LLD won over the prompt's slash typo). No fix — Sprint 3 functions
  will fire. Report clean.
- **(B) MISMATCH — functions on slash, pipeline on dot** — 🔴 the 6 functions inherited the prompt's slash typo and
  are DEAD (audit/start saga, round two). Fix required (STEP 2).
- **(C) BOTH SLASH** — functions AND pipeline both use `audit/completed` (slash). They'd match each other and fire,
  BUT diverge from canon's dot convention + the Sprint 8 VALID_EVENTS dot list → will break when those cross. Fix
  to dot for consistency (STEP 2), lower urgency but still correct.
- **(D) NOTHING EMITS `audit.completed`** — if the audit pipeline never emits any completion event, then these
  functions never fire regardless of dot/slash. Report this as a separate, bigger gap (the trigger event doesn't
  exist) — do NOT fix blindly; report for review.

## STEP 2 — FIX (only if B or C): normalize all Sprint 3 triggers to `audit.completed` (dot)
If there's a mismatch or slash usage, change the 5 audit-triggered visibility functions to listen on the canonical
**`audit.completed` (dot)**:
- In each function's `createFunction({ ... }, { event: "..." }, ...)` (or trigger config), set the event to
  **`audit.completed`** (dot).
- Confirm the audit pipeline EMITS `audit.completed` (dot). If the pipeline currently emits slash (case C), fixing
  the listeners to dot would break the match — in that case the PIPELINE emit is what's wrong vs canon; align BOTH
  to dot (the LLD/Sprint-8 convention), and check no OTHER existing consumer relies on the slash (grep for other
  listeners before changing the emit).
- Do NOT touch `audit.run` (that's the separate, already-correct audit-trigger event from this session's fix) or
  the cron trigger for track-brand-web-mentions.
- Match the exact string the LLD + Sprint 8 VALID_EVENTS use: `audit.completed`.

## STEP 3 — Correct the Sprint 3 PROMPT doc too (so a re-run doesn't reintroduce it)
The prompt file (`visibleau-p2-sprint-3-prompt.md`) has `audit/completed` (slash) in 7 spots (lines ~362, 366,
370, 375, 379, 383, 438). Correct them to `audit.completed` (dot) so re-running the prompt doesn't rebuild the bug.
(Also re-pin the prompt's §0.3 version gate + §10 authority line to accept **v8.70** while in there — currently
says v8.69/v8.65, but live canon is v8.70.) Doc-only edits.

## INVARIANTS — do not violate
- Canonical completion event is **`audit.completed`** (dot) — LLD line 2139 + Sprint 8 VALID_EVENTS. Never
  `audit/completed` (slash).
- Do NOT change `audit.run` (the separate audit-run trigger, already fixed this session) or the weekly cron.
- If fixing the emit side (case C), grep for ALL existing listeners first — don't break another consumer that
  currently matches the slash.
- Functions must remain registered in `serve()`; only the event string changes.
- Don't alter the functions' logic, UPSERT idempotency, or the tables — only the trigger event name.

## VERIFY — prove the functions actually FIRE (not just string-match)
1. After the fix (or if case A confirmed clean): the 5 functions listen on `audit.completed` (dot) and the pipeline
   emits `audit.completed` (dot) — string-for-string identical. Re-run STEP 1 greps to confirm.
2. **Behavioural proof (the real test — string-match isn't enough, per the audit/start lesson):** with the Inngest
   dev server running (dev mode, synced), complete/run an audit for a test brand and confirm in the Inngest
   dashboard (`localhost:8288` → Runs) that the visibility functions ACTUALLY FIRE — `calculate-share-of-voice`,
   `aggregate-visibility-trend`, `simulate-query-fan-out`, `calculate-topical-gaps`, `classify-citation-sources`
   each appear as a run and complete. Then confirm the tables got rows:
   ```bash
   psql "$DEV_DATABASE_URL" -c "SELECT COUNT(*) FROM share_of_voice_snapshots;"
   psql "$DEV_DATABASE_URL" -c "SELECT COUNT(*) FROM visibility_trends;"
   psql "$DEV_DATABASE_URL" -c "SELECT COUNT(*) FROM query_fan_out_results;"
   psql "$DEV_DATABASE_URL" -c "SELECT COUNT(*) FROM topical_coverage_gaps;"
   ```
   Non-zero rows after a real audit = the functions genuinely fire (not just pass mocked tests). This is the check
   that would have caught the audit/start saga.
3. 68/68 Sprint 3 tests still green; no regression.

## REPORT
- **STEP 1 result:** the exact event string the 5 functions listen on vs what the pipeline emits; the classification
  (A match-dot / B mismatch / C both-slash / D nothing-emits).
- If A: confirmation clean, no code fix (only the doc re-pin in STEP 3).
- If B/C/D: the fix applied (or, for D, the gap reported for review).
- **Behavioural proof:** after a real audit, the 5 visibility functions FIRE in the Inngest dashboard AND the
  tables get rows (not just string-match / green tests).
- Prompt doc corrected to `audit.completed` (dot) + re-pinned to v8.70.
- Confirm invariants: dot convention, audit.run/cron untouched, no other consumer broken, functions still
  registered.

## NOTE — why this matters (the audit/start lesson, applied)
The audit/start saga was four functions dead in production while passing all tests, found only by manually checking
real behaviour. This is the identical risk on six MORE functions, and Sprint 4 CONSUMES Sprint 3's data (SoV,
trends, gaps feed the report generator) — so if these are dead, the tables stay empty and Sprint 4 gets built/
tested on empty data, compounding the bug across sprints. Catching it now (via the behavioural proof, not green
tests) prevents exactly that cascade.
