# Claude Code — FIX (3 real bugs + 1 optional): Sprint 4 core TypeScript errors

A full project typecheck found **17 TS errors** (earlier "0" was a per-file/filtered check — always run full
`tsc --noEmit`). 13 are benign test-file noise. **4 are in core files; 3 are REAL bugs, 2 of which block "Generate
report," and 1 was introduced by this session's fan-out wiring fix.** Fix the 3 real ones; the 4th is optional
cleanup.

> Report-first was already done (diagnosis). These are confirmed real bugs with known fixes — apply them. **Run a
> FULL `tsc --noEmit` after, not per-file**, and LOAD the affected screens/flows to verify at runtime (per this
> session's lesson: per-file green ≠ project green ≠ works).

## ✅ THREE-SOURCE / codebase check (done)
- **ERROR 1 (Inngest arity):** every other Inngest fn in the repo uses the **2-arg** `createFunction(config,
  handler)` with triggers INSIDE config (run-audit.ts, simulate-query-fan-out.ts:15). generate-narrative-report.ts
  is the odd one out (3-arg). Fix = match the codebase's 2-arg pattern.
- **ERROR 2 (column name):** LLD/schema — `queryFanOutResults` column is **`runAt`** (`run_at`), there is no
  `createdAt`. Confirm the Drizzle schema for the correct column before changing.
- **ERROR 3 (BudgetPolicy params):** `BudgetPolicyService.estimate()` requires `AuditParams` = {brandId,
  organizationId, promptCount, engineCount} (all 4). Our session's fan-out wiring passed only 2. Both missing values
  are in `context`.

## FIX 1 (REAL, blocks Generate Report) — generate-narrative-report.ts:28 — Inngest 2-arg API
`inngest.createFunction` is called with the OLD 3-arg form (config, trigger, handler). Inngest v4.5 uses **2-arg**
(config, handler) with triggers inside config → currently the trigger object is passed AS the handler and the real
handler is ignored → `trend/aggregated` never triggers report generation (the function is effectively dead).
```bash
sed -n '20,45p' inngest/functions/generate-narrative-report.ts
grep -n "createFunction" inngest/functions/run-audit.ts inngest/functions/simulate-query-fan-out.ts  # the correct 2-arg pattern to match
```
Fix — merge the trigger into config's `triggers` array (match the codebase pattern):
```ts
inngest.createFunction(
  { id: "generate-narrative-report", concurrency: { limit: 5 }, triggers: [{ event: "trend/aggregated" }] },
  async ({ event, step }) => { /* ...existing handler... */ }
)
```
Confirm the event name is what the emitter actually sends (`trend/aggregated` per §8.1) and matches how the other
fns declare triggers.

## FIX 2 (REAL, blocks Generate Report) — narrative-generator.ts:76 — wrong column
`.orderBy(desc(queryFanOutResults.createdAt))` references a non-existent column. The column is **`runAt`**.
```bash
grep -n "createdAt\|runAt\|run_at" lib/db/schema*/*.ts | grep -i fanout   # confirm the real column name
sed -n '70,82p' lib/communication/narrative-generator.ts
```
Fix: `queryFanOutResults.createdAt` → **`queryFanOutResults.runAt`**. (Confirm `runAt` is the intended ordering
column — it's the fan-out run timestamp; that's the sensible order-by for "latest fan-out results".)

## FIX 3 (REAL, our fan-out wiring introduced it) — simulate-query-fan-out.ts:58 — incomplete BudgetPolicy call
This session's fan-out wiring passed only `{ organizationId, promptCount: 5 }` to `BudgetPolicyService.estimate()`,
but `AuditParams` requires all 4: `brandId, organizationId, promptCount, engineCount`. Both missing values are in
`context`.
```bash
sed -n '50,65p' inngest/functions/simulate-query-fan-out.ts
grep -n "AuditParams\|estimate(" lib/budget/*.ts lib/**/budget*.ts 2>/dev/null | head   # confirm the 4 required fields
```
Fix — pass all 4:
```ts
BudgetPolicyService.estimate({
  organizationId: context.organizationId,
  brandId: context.brandId,
  promptCount: 5,               // (or the real sub-query count if it should be dynamic — confirm)
  engineCount: context.engines.length,
})
```
Note: confirm `promptCount: 5` is correct here (is it the fan-out sub-query count? the budget cap default?) — if it
should reflect the actual count, use that; otherwise keep 5 if that's the intended estimate basis. Don't hardcode
anything the budget policy should govern.

## FIX 4 (OPTIONAL, benign) — run-audit-inline.ts:358 — PgTransaction vs DbClient
`buildRecommendations(ctx, tx)` expects `DbClient` (= `typeof db`) but gets a `PgTransaction` (lacks `$client`).
Runtime-safe (only `.select()/.insert()` used; `$client` never accessed) — a type-annotation gap, not a bug.
**Optional cleanup** (do if quick, else leave + note):
- Widen `buildRecommendations`'s param type to `PgTransaction | DbClient` (or a shared narrower interface both
  satisfy), so passing a transaction typechecks. Don't change runtime behaviour.

## INVARIANTS
- Fixes 1-3 are real; Fix 4 optional. Don't change runtime behaviour beyond making the calls correct.
- Confirm real column/param names against the schema/interface before editing (runAt; the 4 AuditParams fields).
- ERROR 1: match the codebase's existing 2-arg Inngest pattern exactly.
- Don't hardcode anything BudgetPolicy/selectModel should govern (Fix 3's promptCount — confirm it's intended).
- TS strict, no `any`, no `@ts-ignore` to paper over.

## VERIFY (full typecheck + runtime)
1. **`npx tsc --noEmit`** — the 3 core real errors GONE (Fixes 1-3). Report the new total (should drop from 17 by
   3, plus 1 if Fix 4 done → the remaining should be only the benign test-file noise). Confirm no NEW errors.
2. **Runtime — the flows that were blocked now work:**
   - **Generate report** (the Reports "Generate report" CTA) → generation actually runs now (Fixes 1+2 unblock it):
     the `trend/aggregated`/generation path triggers, reads the fan-out results ordered by runAt, produces a report
     row (+ PDF). No "expected 2 args" dead-function, no `createdAt` property error.
   - **Fan-out after an audit** (`audit.complete`) → fan-out simulation runs with a complete BudgetPolicy estimate
     (Fix 3): no missing-params error; budget estimate uses brandId + engineCount.
3. 78 Sprint 4 tests still green (+ the 263 backend if run); no regression.

## REPORT
- Each fix applied (file:line, before→after) — Fixes 1-3 real; Fix 4 done-or-left.
- **Full `tsc --noEmit` new total** (from 17 → down by 3-4; remaining = benign test noise only). No new errors.
- **Runtime confirmation:** Generate report now runs (produces a report); fan-out runs post-audit with full budget
  params.
- Confirm: real column/param names verified; codebase Inngest pattern matched; no `any`/`@ts-ignore`; 78 tests green.

## NOTE — process (important)
1. **Full typecheck, not per-file:** "0 TS errors" earlier was per-changed-file; the project had 17. Two
   generation-BLOCKING bugs (Errors 1+2) hid under that. From now, verify with a FULL `tsc --noEmit`.
2. **Error 3 was introduced by this session's fan-out wiring fix** — the fix delegated to the library + added
   BudgetPolicy correctly, but the estimate() call was type-incomplete, and a per-file check let it through (tests
   went green anyway). This is why a real fix needs a full typecheck AND runtime load, not per-file green + reading
   the diff. After these fixes, LOAD Generate-report to confirm it actually runs.
