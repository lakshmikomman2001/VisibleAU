# Claude Code — FIX (spec drift, LOW severity): topical-gap badge + competitive-benchmark null copy → match §6U/LLD

Section-4 E2E revealed two components render copy that DRIFTED from the spec. Section 4's tests were loosened to
match the components — but per canon **LLD/spec wins over implementation**, so the CORRECT fix is to update the
COMPONENTS to the spec wording (then the tests assert the spec text). Both are LOW severity (copy only; the
behaviour is correct) — but they're real drifts to correct.

## ✅ THREE-SOURCE CHECK (done) — both confirmed drifted; spec wording:
### Drift 1 — Topical-gap "HIGH LEVERAGE" badge
- **§6U (prompt L314-315):** `"HIGH LEVERAGE — fix this → improves N prompts"` badge when cross_prompt_impact ≥ 2.
- **LLD (authority, L3139 + L6357):** `"HIGH LEVERAGE — fix this gap → improves N prompts"` (with "gap"; N = the
  actual cross_prompt_impact count, e.g. "improves 7 prompts").
- **Shipped (`topical-gap-list.tsx`):** renders `"prompts affected"` — **lost the "HIGH LEVERAGE" framing.** DRIFT.
- **Target:** `"HIGH LEVERAGE — fix this gap → improves {N} prompts"` where {N} = cross_prompt_impact, shown when
  ≥ 2. (LLD's "fix this gap" wording is authoritative over §6U's "fix this".)

### Drift 2 — Competitive-benchmark null copy
- **§6U (prompt L340/L344) + LLD (L1336, L9086):** when comparisonData is null → a **"Coming soon"** placeholder
  card (NOT an error).
- **LLD L9084 (the intended UI string):** `"Head-to-head comparison available after next audit cycle"` +
  `dataAvailableFrom: 'Sprint 7'`.
- **Shipped (`competitive-benchmark-panel.tsx`):** renders `"No competitor data available"` — DRIFT.
- **Target:** a **"Coming soon"** card with the LLD's message — heading/label "Coming soon" and body
  `"Head-to-head comparison available after next audit cycle"` (and it may surface `dataAvailableFrom: 'Sprint 7'`).
  The graceful-not-error behaviour (CPR-01) is ALREADY correct — only the COPY changes.

> Investigate-first: read both components + confirm the current strings, then change ONLY the copy (no logic/behaviour
> change).
```bash
grep -n "prompts affected\|HIGH LEVERAGE\|cross_prompt_impact\|crossPromptImpact\|improves" components/domain/visibility/topical-gap-list.tsx
grep -n "No competitor data\|Coming soon\|comparisonData\|dataAvailableFrom\|Head-to-head\|next audit cycle" components/domain/visibility/competitive-benchmark-panel.tsx
```

## THE FIX
### 1. topical-gap-list.tsx
- Where the badge renders for `cross_prompt_impact >= 2`, change the text to
  **`HIGH LEVERAGE — fix this gap → improves {N} prompts`** (N = the row's cross_prompt_impact). Keep the ≥2 gate,
  the sort, the leverage-colour styling — only the string changes.
- (Singular/plural nicety optional: "improves 1 prompt" vs "improves N prompts" — match if the codebase does that
  elsewhere; not required.)

### 2. competitive-benchmark-panel.tsx
- Where `comparisonData === null` renders (currently "No competitor data available"), change to a **"Coming soon"**
  card: a "Coming soon" heading/label + the body **"Head-to-head comparison available after next audit cycle"**
  (per LLD 9084). Keep it a graceful placeholder card (NOT an error) — behaviour unchanged, copy corrected.
- If `dataAvailableFrom` is available in the props/response, it may be shown; do not invent new fields.

## 3. Update the Section-4 E2E assertions to the SPEC text (reverse the loosening)
The FE-1 tests were changed to accept the drifted copy:
- FE-1 test 5: assert **"HIGH LEVERAGE"** (or "improves … prompts") — the spec badge, not "prompts affected".
- FE-1 test 7: assert **"Coming soon"** (or "Head-to-head comparison available") — the spec copy, not "No competitor
  data available".
Also update any Section-3 component unit test that asserted the drifted strings, so unit + E2E both assert the spec
wording.

## INVARIANTS
- COPY ONLY — no logic/behaviour change. The ≥2 leverage gate, sort, CPR-01 graceful-null behaviour, tier gating all
  stay exactly as-is.
- Match the LLD wording (authority): "HIGH LEVERAGE — fix this gap → improves N prompts"; "Coming soon" +
  "Head-to-head comparison available after next audit cycle".
- Tokens/tabular-nums/ARIA unchanged. Don't touch other components.

## VERIFY
1. Topical gap with impact ≥2 renders **"HIGH LEVERAGE — fix this gap → improves {N} prompts"** (real N); <2 shows no
   badge (unchanged).
2. Competitive-benchmark with comparisonData null renders the **"Coming soon"** card with the head-to-head message —
   still graceful, NOT an error/500.
3. The updated FE-1 tests (5, 7) assert the SPEC text and pass; any Section-3 unit test updated similarly.
4. Full suite green (was 328 + 16 E2E) — no regression; only the copy + those assertions changed.

## REPORT
- The two strings changed (before → after) with the component + line.
- FE-1 tests 5/7 (and any unit test) updated to assert the spec text; all green.
- Confirm: copy-only (behaviour/logic unchanged); LLD wording used; suite green.

## NOTE (why fix the component, not the test)
Per canon, LLD/spec wins over implementation. Section 4 loosened the tests to the drifted copy to get green — but the
right resolution is to correct the COMPONENTS to the §6U/LLD wording and assert THAT. This closes the drift at the
source (same principle as the donut-vs-prototype correction) rather than baking the drift into the tests.
