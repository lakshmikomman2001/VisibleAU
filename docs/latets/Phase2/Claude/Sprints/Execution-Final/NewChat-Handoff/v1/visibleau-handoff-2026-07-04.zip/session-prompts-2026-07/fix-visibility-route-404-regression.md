# Claude Code — DIAGNOSE + RESTORE (regression): visibility route now 404s after the dashboard SoV strip fix

**REGRESSION.** The visibility hub (`/brands/[brandId]/visibility`) worked perfectly minutes ago (SoV showing brand
+ hipages, fan-out with "Bondi, NSW"). After the **dashboard SoV strip fix** (which was supposed to only touch
`app/(auth)/dashboard/page.tsx`), the visibility route now returns **404** — a CLEAN 404 with **NO compile error**
in the terminal (`GET /brands/.../visibility 404`, no red trace). The parent brand route still works
(`GET /brands/[brandId] 200`) — only the `/visibility` child vanished.

**A clean 404 with no compile error = Next.js does not see a valid route there** — the route's `page.tsx` is
missing, renamed, moved, or lost its default export. This strongly indicates the dashboard fix **touched more than
`dashboard/page.tsx`** — likely the visibility page file or a shared route file.

> This is the priority — a working feature regressed. Diagnose what the fix changed, then restore the route.

## STEP 1 — See EXACTLY what the dashboard fix changed (the key diagnostic)
```bash
git status
git diff --stat
# The full diff of anything touched outside dashboard/page.tsx:
git diff -- ':!app/(auth)/dashboard/page.tsx' | head -100
```
Report every file the fix changed. If it touched anything under
`app/(auth)/brands/[brandId]/visibility/` or a shared layout/route file, that's the culprit.

## STEP 2 — Confirm the visibility route file exists + is valid
```bash
ls -la "app/(auth)/brands/[brandId]/visibility/"
ls -la "app/(auth)/brands/[brandId]/visibility/citation-failure/" 2>/dev/null
# Does page.tsx exist and have a default export?
head -20 "app/(auth)/brands/[brandId]/visibility/page.tsx" 2>/dev/null
grep -n "export default" "app/(auth)/brands/[brandId]/visibility/page.tsx" 2>/dev/null
```
Determine which:
- **(a) `page.tsx` is GONE / renamed / moved** → the fix deleted or moved it. Restore it.
- **(b) `page.tsx` exists but the default export was removed/broken** → the fix corrupted it. Fix the export.
- **(c) `page.tsx` is fine, but a shared file it imports broke** → less likely (would usually be a compile error,
  not a clean 404), but check: does the visibility page import something the dashboard fix moved/renamed (e.g.
  `dashboard-sov-strip.tsx` relocated, a shared component path changed)?
- **(d) a parent `layout.tsx` or route group got altered** → check the `(auth)` / `[brandId]` layout files weren't
  touched.

## STEP 3 — RESTORE the route
Based on STEP 2:
- **(a) file gone/moved:** restore `page.tsx` to `app/(auth)/brands/[brandId]/visibility/page.tsx`. The cleanest
  restore is from git — the file was working and committed/known-good before the dashboard fix:
  ```bash
  git log --oneline -- "app/(auth)/brands/[brandId]/visibility/page.tsx" | head
  git checkout <last-good-commit> -- "app/(auth)/brands/[brandId]/visibility/page.tsx"
  ```
  OR if the fix moved it elsewhere, move it back to the correct route path.
- **(b) broken export:** restore the `export default` for the page component.
- **(c) broken shared import:** fix the import path (point it back at where the shared component actually is, or
  restore the moved file).
- **(d) altered layout:** revert the unintended layout/route-group change.

Whatever the cause: the goal is `/brands/[brandId]/visibility` returns **200** and renders the hub AGAIN, exactly as
it did before the dashboard fix — while KEEPING the dashboard SoV strip fix (don't undo that; just stop it from
breaking the visibility route).

## STEP 4 — Ensure the dashboard fix and the visibility route COEXIST
The dashboard SoV strip fix (moving the strip out of the `progress.totalTasks > 0` guard) is CORRECT and should
stay. The regression is a SIDE EFFECT, not the strip logic itself. So:
- Keep the dashboard strip fix (strip renders on `/dashboard` independent of workflow tasks).
- Restore the visibility route so BOTH work.
- If the fix moved/renamed a SHARED file (e.g. `dashboard-sov-strip.tsx`) that both the dashboard AND the
  visibility hub use, ensure BOTH import paths are correct after the restore.

## INVARIANTS
- Restore the visibility route to working (200 + renders) — do NOT lose the SoV/fan-out fixes already applied
  (brands.domain resolution, engine aggregation, {location} substitution, latest-audit scoping, unique keys — all
  must remain).
- KEEP the dashboard SoV strip fix (strip renders independent of tasks).
- Do NOT touch unrelated routes/files.
- No new regressions — the brand detail page, dashboard, and other routes must all still work.

## VERIFY — both routes work
1. `/brands/6ece067f-063c-436b-ac42-7952c7d7a271/visibility` → **200**, renders the hub with SoV (brand + hipages),
   fan-out ("Bondi, NSW"), Mention-Source, etc. — exactly as before the regression. **No 404.**
2. `/brands/6ece067f-063c-436b-ac42-7952c7d7a271/visibility/citation-failure` → still renders (CPR-01 graceful
   state).
3. `/dashboard` → the SoV strip STILL renders (the dashboard fix is intact).
4. `/brands/6ece067f-063c-436b-ac42-7952c7d7a271` (brand detail) → still 200 with the Visibility card.
5. Terminal: no 404 for the visibility route, no compile errors.
6. 68/68 tests green.

## REPORT
- STEP 1: every file the dashboard fix actually changed (git diff --stat) — confirm whether it touched the
  visibility route / a shared file beyond dashboard/page.tsx.
- STEP 2: the cause ((a) file gone/moved / (b) broken export / (c) broken shared import / (d) layout change).
- STEP 3: how the route was restored.
- **VERIFY proof:** visibility hub returns 200 and renders again; dashboard strip still renders; both coexist;
  brand detail + citation-failure still work; 68/68 green.
- Confirm: SoV/fan-out fixes retained, dashboard strip fix retained, no new regressions.

## NOTE
This is why post-change verification matters — the dashboard strip fix passed its own tests (68/68) but broke the
visibility route (a clean 404 the tests didn't cover, since route existence isn't unit-tested). Same lesson as the
whole manual pass: a green test suite doesn't catch a route that stopped rendering. After restoring, re-confirm on
screen (not just tests) that the visibility hub loads, then the manual pass is finally clean and we proceed to the
automated test track.
