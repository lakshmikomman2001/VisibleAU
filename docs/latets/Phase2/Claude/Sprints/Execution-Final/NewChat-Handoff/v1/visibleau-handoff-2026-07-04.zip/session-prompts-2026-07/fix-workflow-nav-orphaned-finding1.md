# Claude Code — FIX: Workflow surfaces are orphaned from nav (Finding 1) — add the brand-scoped entry points

Sprint 2 manual testing: the Workflow surfaces (`/brands/[brandId]/workflow`, `/workflow/tasks`,
`/workflow/drafts`) are reachable **only by typing the URL** — there is NO link to them anywhere in the UI. The
flagship Phase 2 feature is invisible to users. This is the Sprint 9 "built but unlinked" pattern: the screens
exist and work, but the navigation entry points were lost in prototype→build translation. The LLD records this
explicitly: *"/workflow surfaces are URL-only, not in brand nav (Sprint 9 orphaned-nav pattern)."*

The prototype DOES specify the intended nav (it just wasn't built):
- **A tab strip on the brand detail page** — `BrandIntelTabs` (prototype ~line 1046): Overview · Visibility ·
  Trust · Retrieval · **Workflow** · Discovery · Reports, each with a `minTier` and tier-gate logic.
- **A brand-scoped sidebar group** (prototype ~line 880): an "INTELLIGENCE" section with Visibility / Trust /
  Retrieval / **Workflow** / Discovery items, shown when a brand is selected.

This fix adds the entry point(s) so users can reach Workflow without editing the URL. **Workflow is the
must-have** (it's the only Phase 2 layer built so far). Wire the others' entries only if their pages exist; do
NOT create links to pages that 404.

> **Investigate-first. Report before building.** Read, in order:
> - `app/(auth)/brands/[brandId]/page.tsx` (or the brand detail layout) — how is the brand detail page
>   structured today? Is there a tab strip / sub-nav component already, or just the overview content? Where would
>   a "Workflow" tab slot in?
> - The app's sidebar/nav component (wherever the left nav — Overview / Brands / Vertical packs / Action Center /
>   Drift Alerts / Agency Dashboard — is defined). Is there any brand-scoped section, or is the sidebar purely
>   workspace-level today?
> - Confirm which Phase 2 layer pages ACTUALLY EXIST as routes right now (workflow definitely; visibility/trust/
>   retrieval/discovery/reports — check `app/(auth)/brands/[brandId]/`). Only link to ones that exist.
> - `lib/auth` / wherever `subscriptions.tier` is read for the current org (for the tier gate below).
> Report the brand-detail structure + which layer routes exist, then build.

---

## WHAT TO BUILD — the brand-scoped navigation to Workflow

Pick the approach that fits the existing brand-detail structure (report which you chose):

### APPROACH A (PREFERRED if the brand detail page is tab-based or can be) — a tab strip on the brand page
- Add a **tab strip** to the brand detail page matching the prototype's `BrandIntelTabs`:
  `Overview · Visibility · Trust · Retrieval · Workflow · Discovery · Reports`.
- **Only render tabs whose route exists.** Workflow is required. For layers not yet built, either omit the tab
  or render it disabled with a "coming soon"/locked affordance — do NOT link to a 404. (Report which you did.)
- Clicking **Workflow** navigates to `/brands/[brandId]/workflow` (the hub).
- Active tab styling per the existing app conventions (the prototype: active = layer-accent underline/text;
  inactive = text-secondary, hover bg).

### APPROACH B (if a tab strip doesn't fit) — a brand-scoped sidebar section + an on-page entry card
- Add an **"INTELLIGENCE" section** to the sidebar that appears when a brand is selected, with a **Workflow**
  item (icon GitBranch) → `/brands/[brandId]/workflow`. (Mirror the prototype's brand-scoped group; include only
  layers whose routes exist.)
- AND/OR add an **entry card** on the brand overview page ("Workflow — manage remediation tasks & drafts →")
  that links to the hub. (This is the lowest-risk minimal fix if sidebar surgery is too invasive — same idea as
  the Sprint 9 dashboard entry-point cards.)

**Minimum bar:** from the brand detail/overview page, a user can reach `/brands/[brandId]/workflow` in one click
without touching the URL. Everything else (the full tab set, the sidebar group) is a bonus if the structure
supports it cleanly.

## TIER GATE (match the prototype's logic — do NOT hardcode)
The prototype gates tabs by `minTier` with `tierRank = { Free:0, Starter:1, Growth:2, Agency:3, 'Agency Pro':4 }`.
- **Workflow is `minTier: 'Starter'`** — visible to Starter and above; locked/hidden for Free.
- Read the current org's tier from **`subscriptions.tier`** (NOT `organizations.tier` — locked invariant). Use
  the same tier-read helper the rest of the app uses.
- Below-tier layers: show the tab/item in a locked state (lock icon + upgrade affordance) OR omit it — match
  however the app already handles tier-gated UI (reuse the existing TierGate/lock pattern; don't invent a new one).
- (Bondi/VisibleAU Dev is Agency tier, so Workflow will show unlocked for testing.)

## INVARIANTS — do not violate
- Tier source-of-truth is **`subscriptions.tier`**, never `organizations.tier`.
- Do NOT create nav links to routes that don't exist yet (no 404s). Workflow exists; verify the others before
  linking.
- Use existing shared components, icons (GitBranch for Workflow per the prototype), and design tokens — don't
  invent new primitives. Active/locked states follow existing conventions.
- The Workflow hub, kanban, drafts pages, and their data all already work — this fix touches ONLY navigation
  (the brand-detail tab strip / sidebar / entry card). Don't change the workflow pages themselves.
- ARIA: tablist uses role="tablist"/role="tab"/aria-selected (per the app's FIX 13 build rules); sidebar items
  are proper links.

## VERIFY (behavioural — reach Workflow without the URL bar)
On Bondi Plumbing (Agency tier):
1. Open the brand detail page (`/brands/8f59b2a2-6aa0-4318-9848-b33ed520ca36` — via Brands → Bondi Plumbing).
   Confirm there is now a visible **Workflow** entry (tab, sidebar item, or card) — WITHOUT typing a URL.
2. Click it → land on `/brands/8f59b2a2-.../workflow` (the hub with Open/In progress/Done cards + Generate
   draft / New task). Confirm one-click navigation works.
3. From the hub, the kanban (`/workflow/tasks`) and drafts (`/workflow/drafts`) remain reachable as before.
4. Tier gate: if quick, confirm a Free-tier brand shows Workflow locked/hidden (not an active link), while
   Starter+ shows it unlocked. (Workflow is minTier Starter.)
5. No link points to a non-existent route (no 404s from the new nav).
6. Full Sprint 2 suite still green; no regression to the brand detail page's existing content.

## REPORT
- The brand-detail structure you found (tab-based? overview-only?) + which Phase 2 layer routes actually exist
  today.
- Which approach you built (A tab strip / B sidebar section / entry card) and why.
- How below-tier layers are handled (omitted vs locked) and how the tier is read (`subscriptions.tier`).
- Behavioural confirmation: Workflow reachable from the brand page in one click (no URL editing); hub → kanban →
  drafts still navigable; no 404 links; tier gate correct.
- Confirm invariants (subscriptions.tier source, no dead links, workflow pages unchanged) + suite green.

## NOTE (scope boundary)
This is the navigation half of the orphaned-nav finding. It is independent of the draft-generation entry-point
fix (`build-content-draft-generation-entrypoint.md`) — that one wires the "Generate draft" action; this one
makes the whole Workflow area reachable. They can be applied in either order, but doing this one first makes the
draft-generation testing far less painful (no more URL editing).
