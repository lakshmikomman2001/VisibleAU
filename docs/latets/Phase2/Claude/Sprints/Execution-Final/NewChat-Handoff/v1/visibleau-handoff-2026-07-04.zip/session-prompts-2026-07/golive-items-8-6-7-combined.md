# Claude Code — Go-Live Checklist: Items 8 + 6 + 7 (do in this order)

Three code-actionable items from `docs/go-live-checklist.md`. Each has a specific caveat — do NOT rubber-stamp any
of them. Order: **8 first (real security investigation), then 6, then 7.**

---

## ITEM 8 (FIRST — treat as a SECURITY investigation, NOT a rubber-stamp)
`llm_response_cache` was left RLS-disabled during the 14-tables fix as "system cache, no org scoping column." The
real question: **can cached LLM responses leak org-specific content between tenants via a shared cache key?**
Investigate and report a verdict with evidence — do NOT just confirm it's disabled and move on.

**Investigate:**
```bash
# The cache table schema + how keys are built + what's stored
psql "$DEV_DATABASE_URL" -c "\d llm_response_cache"
grep -rnE "llm_response_cache|responseCache|cache_key|cacheKey|getCached|setCached|cache.*prompt|prompt.*hash" lib/ db/ --include=*.ts | head -30
# Where the cache is written/read — what goes into the key and the value?
```
**Answer these specifically:**
1. **What is the cache KEY?** Is it keyed purely on `(prompt, model)` / a prompt hash with NO tenant/brand/org
   component? Or does the key include org/brand?
2. **Does the PROMPT contain org-specific data?** (e.g. a specific brand name, a brand's URL, an org's audit
   content baked into the prompt text.) If the prompt embeds one org's data AND the key is prompt-only, then two
   orgs asking about DIFFERENT brands get different keys (safe) — BUT if two orgs could ever produce the SAME key
   for org-specific content, Org B could be served Org A's cached response (leak).
3. **What is stored in the VALUE?** Generic model output (same for anyone asking the same prompt — safe to share)
   vs content derived from / containing a specific org's data (not safe to share cross-org).
4. **The concrete risk:** is there any code path where Org B's request produces a cache-key COLLISION with Org A's
   cached entry AND the cached value contains Org A's tenant data? Trace an example.

**Verdict (report ONE with evidence):**
- **SAFE** — the cache is a pure generic prompt→response cache (key = prompt/model, value = generic model output,
  no tenant data can be served cross-org because identical prompts legitimately share a response). → RLS-disabled
  is correct. **Document the decision** in the schema/LLD notes (a comment on the table + a line in the go-live
  checklist) so it's not re-flagged as a false positive later.
- **NOT SAFE** — cached entries can contain org-specific content that could be served to another org via a shared/
  collidable key. → This is a REAL leak. Do NOT fix blindly — REPORT the exact leak path and a proposed fix
  (org/brand component in the cache key, OR an `organization_id` column + RLS policy) for review. Flag it as a new
  security finding.

Report the key structure, what's stored, the collision analysis, and the verdict. No source changes for item 8
unless the verdict is NOT SAFE and the fix is reviewed first.

---

## ITEM 6 (version bump — VERIFY the correction is actually IN the repo first)
The audit/start canon correction was mislabelled v8.69 (collision with the prior TC-01 v8.69). The bump prompt is
`fix-lld-version-collision-v8.70.md`. **BUT first confirm the correction actually landed in the repo LLD** — do not
re-label a version whose content might not be present.

**Verify first:**
```bash
grep -nE "audit\.run|CORRECTED.*v8\.(69|70)|D-05" <path-to-repo-LLD>.md | head -20
grep -nE "^# Version:" <path-to-repo-LLD>.md
```
- **If the correction IS present** (`audit.run` as the contract, the D-05 rewrite, `[CORRECTED]` stamps): proceed
  with the bump per `fix-lld-version-collision-v8.70.md` — header → v8.70, re-label the audit/start CHANGELOG entry
  from v8.69 → v8.70 (keep the TC-01 v8.69 entry untouched), update the inline `[CORRECTED ... v8.69]` stamps →
  v8.70. Both LLDs consistent. Update the stored canonical-version note (says "v8.68" — stale).
- **If the correction is NOT present** (LLD still says `audit/start` as canonical, no D-05 correction): STOP and
  report — the canon correction never made it into the repo. Re-labelling would be cosmetic over missing content;
  the correction itself needs applying first (via `canon-correction-audit-run-event.md`). Report which case.

Report which case applied and what was changed.

---

## ITEM 7 (e2e DB-mismatch config — CONFIRM the 34 failures actually clear)
`e2e-rls-fk-services.integration.test.ts` fails with 34 DB-timeout failures, diagnosed as a DB-mismatch (test
points at the wrong DB — `visibleau` vs `visibleau_prod`). Fix the config, BUT do not mark it fixed until the
failures actually disappear.

**Fix + verify:**
- Find where this test loads its `DATABASE_URL` / DB config and correct it to point at the intended test/dev DB
  (consistent with how the other now-passing E2E tests resolve their DB).
- **Re-run the test and confirm all 34 failures clear.**
- **If they clear** → done; the suite is fully green.
- **If they DON'T all clear** → the DB-mismatch was NOT the whole story. Do NOT mark fixed. Re-diagnose the
  remaining failures — and given this is an RLS-FK-services test and heavy RLS/connection-pool/role work was just
  done (Tier 2 wrapper, non-superuser role), check whether the remaining failures relate to the new
  `withRlsContext` transaction wrapper or the `visibleau_app` role (e.g. FK-service operations that now run under
  the constrained role or inside the transaction wrapper and behave differently). Report the remaining root cause.

Report: the config fix, whether all 34 cleared, and (if not) the re-diagnosis.

---

## OVERALL REPORT
- **Item 8 verdict:** cache key structure + stored value + collision analysis + SAFE / NOT-SAFE (with the leak path
  if not safe). Documented if safe; flagged as a new finding if not.
- **Item 6:** which case (correction present → bumped to v8.70; or correction absent → reported, not cosmetically
  re-labelled).
- **Item 7:** config fixed; all 34 failures cleared (or the re-diagnosis if not).
- Confirm no unreviewed source changes (item 8 fix only if NOT-SAFE and reviewed; item 6 docs-only; item 7 test
  config).
