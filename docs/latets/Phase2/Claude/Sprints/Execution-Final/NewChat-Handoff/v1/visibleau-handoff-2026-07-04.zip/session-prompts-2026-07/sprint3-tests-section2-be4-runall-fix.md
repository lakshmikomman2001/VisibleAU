# Claude Code — Sprint 3 Section 2 · BE-4: RUN-ALL + FIX + FULL ACCEPTANCE (Definition-of-Done closeout)

Final pass of Section 2. BE-1 (72) + BE-2 (62) + BE-3 (cross-sprint) done; the two BE-3 bugs are FIXED
(wins-feed sql<Date>→string+new Date(); fan-out Inngest wired to the library + selectModel + BudgetPolicy). Suite is
263 passed / 1 todo. BE-4 = **run everything + fix any red (only pass allowed to change source) + verify the Sprint 3
prompt's actual §11/§12/§13 acceptance gates.** This turns "tests green" into "Sprint 3 Definition-of-Done met."

> **Anchored to the REAL acceptance criteria** (verified against LLD v8.70 + Sprint 3 prompt §11–§14 + prototype),
> not a generic closeout. Where the prompt and LLD disagree, **the LLD wins**.
> **Dev DB only.** RLS under **`rls_test_role` (non-superuser)**.

## ✅ THREE-SOURCE ANCHOR (checked before writing)
- **§11 (prompt):** the 12 required test files (below). **§12 (prompt):** the verification greps (below) — concrete
  and checkable. **§13 (prompt):** the anti-patterns each test/grep exists to prevent. **§14:** Sprint 4 consumes
  this sprint's data, so the DoD must be real before S4.
- **LLD v8.70 (authority):** the unit rule (percentages ×100, ratio NULL-guard — LLD 5980), source columns
  (scoreSentimentNumeric/scoreContextNumeric — LLD 5953/5960), CPR-01 degradation (LLD 1336 + v8.38), the two FK
  ALTERs SET NULL + pg_constraint guard (LLD 7591/7600), BudgetPolicy-bounded fan-out (LLD 1640/1684), Phase-A wins
  types (LLD 7947-7960), RLS on tenant tables / prompt_volume_estimates global.
- **Prototype:** VisibilityHub / CitationFailureDiagnosis / CompetitiveBenchmark / dashboard SoV strip — all
  reviewed on screen already; the tests here are backend/data, UI is Section 3.

## STEP 1 — Run the WHOLE Sprint 3 suite; report the fresh full result
```bash
npx vitest run tests/phase2/sprint3/ --reporter=verbose 2>&1 | tail -160
```
Report total pass/fail/todo, and every failure (name, file, expected vs actual). Both BE-3 fixes must be green
(wins-feed multi-engine case; fan-out wired). The 1 todo (go-live #12 TLD-variant) STAYS a todo — not silently
"fixed."

## STEP 2 — §11 completeness: confirm every REQUIRED test file exists and passes
The prompt §11 requires these 12 — confirm each is present AND green:
```
sov-calculator.test.ts · mention-source-divide.test.ts · fan-out-simulator.test.ts ·
topical-gap-calculator.test.ts · citation-failure-diagnosis.test.ts · visibility-trend-aggregator.test.ts ·
competitive-benchmark.integration.test.ts · wins-feed.test.ts · task-fk.migration.test.ts ·
citation-source-classifier.test.ts · visibility-rls.test.ts
```
Report any §11 file that is MISSING (not just failing) — a missing required test is a gap to fill in BE-4.

## STEP 3 — §12 VERIFICATION GREPS: run them all, report pass/fail per grep
Run the Sprint 3 prompt's §12 greps verbatim and report each result vs its expected value:
```bash
grep -c "CREATE TABLE IF NOT EXISTS" db/migrations/*sprint3_visibility.sql            # expect 7
grep -c "DROP POLICY IF EXISTS" db/migrations/*sprint3_visibility.sql                 # expect 6 (all but prompt_volume_estimates)
grep -cE "ADD CONSTRAINT fk_(fan_out|topical)_gap" db/migrations/*sprint3_task_fks.sql # expect 2
grep -c "ON DELETE SET NULL" db/migrations/*sprint3_task_fks.sql                      # expect 2
grep -c "pg_constraint" db/migrations/*sprint3_task_fks.sql                           # expect 2 (MI-01 re-runnable)
grep -RnE ">= ?20|>= ?10" lib/visibility/mention-source-divide.ts                     # expect >=2 (pp thresholds)
grep -Rc "scoreSentimentNumeric\|scoreContextNumeric" lib/visibility/visibility-trend-aggregator.ts  # expect >=2
grep -RnE "AVG\(.*scoreSentiment\b|AVG\(.*scoreContext\b" lib/visibility/             # expect 0 (never AVG text cols)
grep -Rc "selectModel(" lib/visibility/fan-out-simulator.ts                           # expect >=1
grep -RnE "'claude-3|'gpt-4|'gemini-" lib/visibility/                                 # expect 0
grep -cE "calculateShareOfVoice|aggregateVisibilityTrend|simulateQueryFanOut|calculateTopicalGaps|classifyCitationSources|trackBrandWebMentions" app/api/webhooks/inngest/route.ts  # expect 6
grep -Rc "comparisonData" "app/api/brands/[id]/competitive-benchmark/route.ts"        # expect >=1
grep -Rc "dataAvailableFrom" "app/api/brands/[id]/competitive-benchmark/route.ts"     # expect >=1
ls "lib/communication/wins-feed.ts" "app/api/brands/[id]/wins/route.ts"               # both exist
grep -REc "var\(--[a-z-]+\)[0-9a-fA-F]{2}" components/domain/visibility/              # expect 0 (RT-01 no hex-alpha on var())
grep -RcE "sm:grid-cols|lg:grid-cols|md:" "app/(auth)/brands/[brandId]/visibility/"   # expect >=1 (responsive)
grep -RnE "organizations\.tier|org\.tier" lib/visibility/ | grep -iv subscriptions    # expect 0
grep -Rc "Clerk\|@clerk" lib/visibility/ db/ "app/api/brands/"                        # expect 0
```
Also run the §12 unit-rule greps for the ×100 percentage + div-by-zero guard on sov-calculator +
visibility-trend-aggregator (expect the multiply present and a `mentionRate > 0 ?` style guard).
Report each grep: PASS (matches expected) or FAIL (with the actual number). A failing §12 grep is a real
acceptance-gate miss.

> NOTE on the fan-out §12 grep: after the BE-3 fix, `selectModel` is called INSIDE the library
> (`fan-out-simulator.ts`), and the Inngest function DELEGATES to the library. So `grep selectModel(
> fan-out-simulator.ts` should be >=1 (library has it). The Inngest function satisfies the intent transitively
> (it calls the library). Confirm both: library has selectModel; Inngest function has BudgetPolicy + delegates.

## STEP 4 — §13 anti-pattern spot-checks (the traps these gates guard)
Confirm none of the §13 anti-patterns are present:
- Rates stored 0–1 instead of 0–100 (unit rule); ratio=0 instead of NULL on mention_rate=0.
- AVG-ing the text score columns.
- Inconsistent period_label (one helper, exact format).
- Missing hyphen→underscore on topic_cluster.
- Task FKs in the wrong migration / without pg_constraint guard.
- citation-failure / competitive-benchmark erroring (not degrading) when S5/S7 empty → must be CPR-01 (200,
  comparisonData null, "Coming soon", no generateText).
- Hardcoded fan-out model/engine instead of selectModel + TIER_ENGINES (fixed in BE-3 — confirm it holds).
- wins-feed asserting cause instead of "likely linked to:".
- Missing RLS on a tenant table / RLS enabled on the global prompt_volume_estimates.

## STEP 5 — TRIAGE + FIX (only pass allowed to change source, post-review)
For any red test, missing §11 file, failing §12 grep, or §13 anti-pattern found:
- **Code bug** → fix source (minimal, correct); note file + change + why.
- **Missing required test** → add it (§11).
- **Wrong test / env-tooling** (e.g. the earlier require()→await import(), bad UUID fixture) → fix the test/setup.
- Do NOT force green by weakening a gate or matching a wrong assertion. Do NOT "fix" the go-live #12 todo.

## INVARIANTS (must hold after BE-4)
The full track's regression guards stay green — no fix may erode them:
- `audit.complete` wiring (5 fns fire + UPSERT) + MI-01 idempotency; SoV brands.domain (not metadata.domain) + own
  domain excluded + engine aggregation; fan-out {location} substituted + region-less fallback + latest-audit scope +
  **wired to library (selectModel + BudgetPolicy, budget cap not hardcoded 3)**; routes behavioural 401/404/400/200
  + tier gates; CPR-01 (comparisonData null + no generateText + 200); numeric score columns; ratio NULL; pp
  thresholds; RLS isolation (6 tenant tables) + prompt_volume_estimates global; the two FK SET NULL + pg_constraint
  guard; wins-feed 5 Phase-A types + "likely linked to:" + multi-engine no-crash + LIMIT 20 / max 50;
  subscriptions.tier only; TS strict no any; go-live #12 stays a todo.

## VERIFY / REPORT — Section 2 closeout
- Final counts: total passed / failed / todo.
- **§11:** all 12 required test files present + green (list any missing/added).
- **§12:** each grep PASS/FAIL vs expected (call out any FAIL as a real acceptance miss).
- **§13:** anti-pattern spot-checks all clean.
- Any source change BE-4 made + why (should be minimal — BE-1/2 found 0 source bugs; BE-3's 2 already fixed).
- Confirm all INVARIANT guards green; dev-DB only; RLS non-superuser; test data torn down; #12 still a todo.
- **Section 2 (Backend E2E) status: COMPLETE — Sprint 3 §11/§12/§13 acceptance MET** — or list blocked/failing gates.

## NEXT — Section 3 (Frontend Unit)
Components with mock data. ⚠️ `sov-donut.tsx` now renders **ranked BARS, not a donut** (BE-3-era enhancement) —
update/replace any donut-specific DOM assertions to assert the bars: **brand row highlighted via `--layer-visibility`
+ "you" chip (highlight follows IS-BRAND, not rank), competitors muted, percentages in mono, engine tabs, sorted by
share DESC, brand bar visible even at 0% share**. Also mention-source-matrix (active archetype quadrant + N/A ratio),
fan-out-tree (threshold accent + quality dot), topical-gap-list (leverage badge), dashboard-sov-strip (same bars).
Then Section 4 (Frontend E2E) and Section 5 (QA / batch-script run).
