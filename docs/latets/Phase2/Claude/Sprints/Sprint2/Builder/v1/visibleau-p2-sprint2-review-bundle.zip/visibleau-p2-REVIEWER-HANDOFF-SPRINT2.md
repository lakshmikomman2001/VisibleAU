# VisibleAU Phase 2 — REVIEWER HANDOFF: SPRINT 2 PROMPT (Gate 2)
# Date: June 2026 | Written by: the BUILDER chat (original chat)
# Reviewing: visibleau-p2-sprint-2-prompt.md v1.0 (Workflow Intelligence)

YOUR ROLE. Independent reviewer of a SPRINT PROMPT before it is fed to Claude Code to
build ~4 weeks of Phase 2 work. The builder wrote this prompt from the LLD; your job is to
catch anything that would make Claude Code build the wrong thing. Derive your own view from
the LLD first, then compare — never accept a cited line number without opening it.
Respond in English only (Telugu only if Sri explicitly asks).

NOTE ON PROCESS: there is no separate master-plan Gate 1 ruling in front of you — Sri has
chosen to review prompt-by-prompt directly. That is fine; just apply the checks below to
this prompt on its own merits against the LLD.

---

## SECTION A — VERIFY INPUTS (run BEFORE reviewing; STOP on failure)

You should have TWO zips from Sri:

A1. visibleau-phase2-v8.65-complete-REVIEWED.zip (canon)
    • grep -m1 "^# Version:" visibleau-7layer-lld.md → "# Version: 8.65 | Date: June 2026"
    • grep -c "ATTRIBUTION CORRECTED IN CROSS-REVIEW" visibleau-7layer-lld.md → 1
      (without this marker the LLD is stale — STOP)
    • Read the bundled handoff's Section D (locked facts) and F (do-not-fix) — binding.

A2. visibleau-p2-sprint1-review-bundle.zip (under review)
    • visibleau-p2-sprint-2-prompt.md (v1.0) — the deliverable
    • visibleau-p2-SPRINT-PROMPT-PLAYBOOK-v1.0.md — the standard (§3 template, §4 specs,
      §7 reviewer checklist, §9 anti-patterns)
    • SPRINT-MASTER-PLAN.md — context: Sprint 1 owns tables 1–7, 0 Inngest functions,
      no UI; §7 of the plan is the shared conventions block this prompt must echo.

---

## SECTION B — WHAT SPRINT 2 IS (so you can judge scope)
Workflow Intelligence (Layer 5) — the first user-facing Phase 2 sprint. 3 new tables
(remediation_tasks #29, workflow_runs #30, content_drafts #31), 3 Inngest functions, the
SHARED UI component foundation (tokens + base components every later sprint reuses), the
Workflow/Tasks/Drafts screens + the dashboard base shell, 5 workflow libs + shared
progress-summary & wins-feed helpers, and the task/draft/wins/progress API routes. GAP 8
(content_format) lands here. LLD authority: Layer 5 (~7567) + Sprint 2 plan (~8825).

## SECTION C — GATE 2 CHECKS (your task)

C1. SCHEMA FIDELITY — for each of the 3 tables, open the LLD definition (anchors in prompt
    §5) and confirm columns/types/defaults/constraints are reproduced EXACTLY. Specifically:
    • remediation_tasks: recommendation_id/reaudit_id ON DELETE SET NULL; **fan_out_gap_id
      and topical_gap_id are PLAIN UUID with NO FK this sprint** (BD-01, LLD ~7587) — verify
      the prompt does NOT add REFERENCES to them and DOES note Sprint 3 adds the FKs;
      linkedin_gap_source / consensus_gap_source slug enums; priority INTEGER; wont_fix_reason
      Zod refine; users(id) UUID refs.
    • workflow_runs: status enum includes **'completed' (-ed)**; result_summary typed as
      WorkflowRunResult (not `any`, RS-01).
    • content_drafts: task_id ON DELETE SET NULL; content_format GAP 8 enum; draft_type
      underscores; status draft|approved|published|rejected.

C2. THE LOCKED ENUMS + NAMING TRAPS. Confirm the prompt copies and DISAMBIGUATES:
    • remediation_tasks.status = open|in_progress|ready_for_review|complete|wont_fix (never
      'done'); workflow_runs.status 'completed' (-ed) ≠ audits 'complete' (call-out present);
      content_drafts.status set.
    • recommendation_key (hyphen) → draft_type (underscore) translation is owned by
      content-generator.ts, not assumed equal (LLD ~7926).
    • PriorityBadge = DERIVED high/med/low band, NOT the raw INTEGER priority column.

C3. INNGEST CORRECTNESS (highest-risk area). Verify against LLD ~7991–8060:
    • generate-content-draft: event 'draft/generate', concurrency 5, selectModel(tier,
      engine,'content_draft') — NOT a hardcoded model (MS-01).
    • trigger-validation-reaudit: event 'task/completed' + step.sleep('14 days') (NOT a
      cron, TR-01); **quota gate** checkQuota + markReauditDeferred on over-quota (U-14) —
      never fires 'audit/start' outside the gate, never silently drops.
    • schedule-workflow-runs: daily cron, quota-gated before 'audit/start'.
    • all 3 registered in serve() alongside Phase 1 (none removed).

C4. MIGRATION + RLS. MI-01 idempotency: CREATE TABLE/INDEX IF NOT EXISTS + DROP POLICY IF
    EXISTS before CREATE POLICY (LLD ~8645). RLS USING + WITH CHECK on all 3 tables (all
    carry organization_id).

C5. UI FIDELITY (§6U). Spot-check 3 components against prototype anchors: the shared
    foundation (tokens 84–490 incl [data-theme="light"], --focus-ring, --elevation;
    IntelCard unit prop + ±0 pill; TierGate backdropFilter; PriorityBadge derived band);
    WorkflowHub (2096; stat cards match the task list); ContentDraftEditor (2231;
    contentEditable = role="textbox" with names); dashboard two-state Work Completed /
    Measured Impact card (honesty rule: Measured Impact only counts score_after IS NOT NULL).
    Both themes addressed; no hex-alpha on var() (RT-01); ARIA per FIX 13.

C6. WINS FEED + PROGRESS. Phase A wins-feed = 5 types (LLD ~7807), degrades gracefully when
    S3 tables absent, LIMIT 20 / ?limit max 50 (PA-01); progress-summary SUM excludes
    score_after IS NULL (honesty rule, LLD ~7745). No new tables (both are derived).

C7. TEMPLATE + DEPTH (Playbook §3, §4). Sections 0–14 + §6U present; no unspecified files;
    §12 greps runnable; §10 Claude Code block self-contained. (Sprint 2 HAS UI, so §6U is
    expected and the prompt should clear the ~900-line depth floor.)

C8. ANYTHING MISSING from the LLD Layer 5 / Sprint 2 region that the prompt omits — e.g.
    the Action Progress Tracker 4-surface placement (LLD ~7723), the outreach_brief draft
    type (deferred to S6 — confirm it's correctly NOT built here), the wins-feed Phase B
    trust_improved (correctly deferred to S5).

## SECTION D — FINDINGS FORMAT (send back)
Produce SPRINT2-FINDINGS.md: (1) verdict PASS / PASS-WITH-FIXES / FAIL; (2) numbered
findings S2-01, S2-02 … with severity, the claim, the LLD line checked, the required fix;
(3) any rulings if the prompt flagged OPEN QUESTIONS; (4) your independently-derived
results; (5) a clean pass is valid — don't manufacture findings. Zip for Sri. The builder
applies fixes, bumps the prompt to v1.1, and only then is Sprint 2 ready for Claude Code.

## SECTION E — WHAT YOU MUST NOT DO
• Do not edit the prompt/LLD/prototype/plan — findings go back through Sri.
• Do not generate Sprint 3 (builder's job).
• Do not bump any version; a genuine LLD gap is escalated, not patched here.
• Do not re-litigate handoff §F do-not-fix items.

— End of reviewer handoff. Run Section A, then Gate 2 per Section C.
