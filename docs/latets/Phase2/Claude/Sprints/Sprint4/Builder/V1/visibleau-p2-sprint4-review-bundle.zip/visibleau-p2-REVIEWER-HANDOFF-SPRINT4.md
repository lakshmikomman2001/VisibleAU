# VisibleAU Phase 2 — REVIEWER HANDOFF: SPRINT 4 PROMPT (Gate 2)
# Date: June 2026 | Written by: the BUILDER chat (original chat)
# Reviewing: visibleau-p2-sprint-4-prompt.md v1.0 (Communication Intelligence)

YOUR ROLE. Independent reviewer of a SPRINT PROMPT before it drives ~4 weeks of Claude Code
work. Derive your own view from the LLD/prototype first, then compare — never accept a cited
line without opening it. Respond in English only (Telugu only if Sri explicitly asks).

## SECTION A — VERIFY INPUTS (run BEFORE reviewing; STOP on failure)
A1. visibleau-phase2-v8.66-complete-REVIEWED.zip (canon — NOTE: now v8.66)
    • grep -m1 "^# Version:" visibleau-7layer-lld.md → "# Version: 8.66 | Date: June 2026"
    • grep -c "FIX 15 (v8.66)" visibleau-prototype-phase2.jsx → 1
    • grep -cE "ATTRIBUTION CORRECT(ED IN CROSS-REVIEW|ION)" → ≥1 (r2 marker "ATTRIBUTION CORRECTION")
    • Read the bundled handoff Sections D (locked facts) + F (do-not-fix). v8.66 changed ONLY
      the prototype reduced-motion reset + LLD changelog — schema/Inngest/GAP regions are
      identical to v8.65 r2, so a v8.65 r2 canon is also acceptable for this review.
A2. visibleau-p2-sprint4-review-bundle.zip (under review)
    • visibleau-p2-sprint-4-prompt.md (v1.0) — status "Awaiting Gate 2"
    • visibleau-p2-SPRINT-PROMPT-PLAYBOOK-v1.0.md — the standard (§3 template, §4 specs, §6/§7)
    • SPRINT-MASTER-PLAN.md — context: S4 owns tables 32–34, 2 Inngest fns, no new GAP.

## SECTION B — WHAT SPRINT 4 IS
Communication Intelligence (Layer 6): evidence-bounded narrative reports, white-label PDF,
scheduled email delivery, and the alert composer (hallucination/drift/consensus/volatility).
3 tables (32–34), the per-org is_default template seed, 2 Inngest fns, 4 lib modules, the
Reports/template/schedule screens, and the report/template/schedule API routes. It SURFACES
S3 data; the LinkedIn/consensus/knowledge-panel/entity-home report sections + the
hallucination/consensus alerts are specified but DORMANT until their S5/S6 tables exist
(CPR-01 self-activation). LLD authority: Layer 6 (~8129) + Sprint 4 plan (~8939).

## SECTION C — GATE 2 CHECKS
C1. SCHEMA FIDELITY (3 tables) — open each LLD def (anchors in prompt §5): report_templates
    8143, generated_reports 8201, report_delivery_schedules 8247. Verify verbatim. Watch the
    FK ON DELETE rules: generated_reports.audit_id + template_id SET NULL (E-03/v8.28);
    report_delivery_schedules.brand_id has its FK (R-01) + template_id SET NULL.
C2. THE STRUCTURAL TRAPS (highest-value) — confirm the prompt enforces, in spec + pitfalls +
    greps: (a) generated_reports has **NO status column** — status is UI-DERIVED from pdf_url +
    email_sent_at (CM-01, LLD 8225); (b) generated_reports is **APPEND-ONLY** — no UNIQUE, no
    ON CONFLICT (U-13, LLD 8232); (c) report_templates.sections is **typed ReportSection[]**
    with the 12-value type enum (TS-01, LLD 8147); (d) report_delivery_schedules weekly/monthly
    **mutual exclusivity** + the Zod refine, time_of_day in **UTC** (LLD 8278).
C3. NARRATIVE HONESTY (RULES 1–11, LLD 8290) — confirm all 11 reproduced, especially RULE 1
    (no causal language at quality_status='insufficient'), RULE 3 (key win needs score_delta>0
    AND sample_quality>='Likely'), RULE 8 (evidence snapshots Agency+), and that each section
    is included ONLY when its nullable source table has a row (so S5/S6 sections self-activate).
C4. MODEL + EVENT CHAIN + REUSE — selectModel(tier,engine,'narrative_generation') not hardcoded
    (MS-02); generate-narrative-report listens on 'trend/aggregated' (NR-01) and emits
    'report/generated' (WH-01a), concurrency 5 (CC-05), only when an active delivery schedule
    exists; send-scheduled-reports reuses the Phase 1 Resend singleton (NOT new Resend); the PDF
    builder imports lib/pdf/theme.ts (NOT duplicated); both registered in serve() (total → 11).
C5. EM-01 DEDUP — confirm the prompt adds the guard so the Phase 1 send-weekly-digest skips a
    brand that has an active weekly Phase 2 schedule (no double Monday email, LLD 8264).
C6. THE SEED — per-org is_default 'Default Report' template (5 core sections included, 7
    optional excluded), ON CONFLICT DO NOTHING (LLD 8170).
C7. MIGRATION + RLS — MI-01 idempotency (CREATE TABLE/INDEX IF NOT EXISTS, DROP POLICY IF
    EXISTS); RLS USING + WITH CHECK on all 3 (all carry organization_id).
C8. UI (§6U) — Reports list (ReportsList 2682; derived status badge, NEVER a status column),
    report detail + PDF, template editor (12 toggles + tone), schedule manager (conditional
    weekly/monthly matching the refine). Each screen: STATES matrix + RESPONSIVE line; both
    themes; reduced-motion consumed from S2; reports Growth+, schedules Agency+.
C9. TEMPLATE + DEPTH — sections 0–14 + §6U; no unspecified files; §12 greps runnable; §10
    self-contained. §1 module list should be the COMPLETE enumeration of the §4 tree (the
    recurring S1-02/S2b-01/S3-01 pattern — verify it doesn't recur).
C10. ANYTHING MISSING / WRONGLY BUILT — the LinkedIn/consensus/knowledge-panel/entity-home
    sections + hallucination/consensus alerts must be specified-but-dormant (NOT built against
    non-existent S5/S6 tables); confirm that's framed as correct, not a gap.

## SECTION D — FINDINGS FORMAT
Produce SPRINT4-FINDINGS.md: verdict PASS / PASS-WITH-FIXES / FAIL; numbered S4-01… with
severity + the LLD line checked + required fix; rulings on any OPEN QUESTIONS the prompt
flags; your independently-derived results; a clean pass is valid. Zip for Sri. Builder applies
fixes, bumps to v1.1, then Sprint 4 is ready for Claude Code.

## SECTION E — WHAT YOU MUST NOT DO
• Do not edit the prompt/LLD/prototype/plan — findings go back through Sri.
• Do not generate Sprint 5 (builder's job). • Do not bump any version (escalate real LLD
  gaps). • Do not re-litigate handoff §F do-not-fix items.

— End of reviewer handoff. Run Section A, then Gate 2 per Section C.
