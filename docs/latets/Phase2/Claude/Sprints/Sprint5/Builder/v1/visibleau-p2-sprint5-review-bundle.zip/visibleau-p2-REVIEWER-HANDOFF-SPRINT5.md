# VisibleAU Phase 2 — REVIEWER HANDOFF: SPRINT 5 PROMPT (Gate 2)
# Date: June 2026 | Written by: the BUILDER chat (original chat)
# Reviewing: visibleau-p2-sprint-5-prompt.md v1.0 (Trust Intelligence)

YOUR ROLE. Independent reviewer of a SPRINT PROMPT before it drives ~4 weeks of Claude Code
work. Derive your own view from the LLD/prototype first, then compare — never accept a cited
line without opening it. Respond in English only (Telugu only if Sri explicitly asks). Sprint
5 is large (7 tables incl an ALTER, 7 Inngest fns, 6 GAPs) AND it carries the S4→S5 wiring
contract — review both the new surface and that contract.

## SECTION A — VERIFY INPUTS (run BEFORE reviewing; STOP on failure)
A1. visibleau-phase2-v8.66-complete-REVIEWED.zip (canon — v8.66)
    • grep -m1 "^# Version:" visibleau-7layer-lld.md → "# Version: 8.66 | Date: June 2026"
    • grep -c "FIX 15 (v8.66)" visibleau-prototype-phase2.jsx → 1
    • grep -cE "ATTRIBUTION CORRECT(ED IN CROSS-REVIEW|ION)" → ≥1
    • v8.66 changed ONLY the prototype reduced-motion reset + LLD changelog; the Layer 3
      regions are identical to v8.65 r2, so a v8.65 r2 canon is also acceptable.
A2. visibleau-p2-sprint5-review-bundle.zip (under review)
    • visibleau-p2-sprint-5-prompt.md (v1.0) — status "Awaiting Gate 2"
    • visibleau-p2-SPRINT-PROMPT-PLAYBOOK-v1.0.md · SPRINT-MASTER-PLAN.md (S5 owns tables
      19–25 incl the brand_entity_scores ALTER #21, 7 Inngest fns, GAPs 4/7/10/11/13/16).

## SECTION B — WHAT SPRINT 5 IS
Trust Intelligence (Layer 3): hallucination detection + read-time risk, the immutable evidence
archive, monthly entity-authority scoring (registry + Wikipedia + directories + Knowledge Panel
+ Wikidata via the brand_entity_scores ALTER), citation source intelligence (GAP 4 L3),
LinkedIn presence (GAP 7), cross-platform consensus (GAP 10), Knowledge Panel (GAP 11),
Wikidata (GAP 13), YouTube presence (GAP 16). 6 new tables + the brand_entity_scores ALTER, 7
Inngest fns, 11 lib modules, 8 screens. **Plus the S4→S5 wiring contract: it must wire the new
tables' reads into S4's narrative-generator slots + the alert-composer triggers.** LLD: Layer 3
(~6716) + Sprint 5 plan (~8946).

## SECTION C — GATE 2 CHECKS
C1. SCHEMA FIDELITY (6 tables + ALTER) — open each LLD def (anchors in prompt §5):
    hallucination_incidents 6755, evidence_snapshots 6826, brand_entity_scores ALTER 6850,
    citation_source_intelligence 6897, linkedin_presence_audits 6974, brand_consensus_checks
    7024, youtube_presence_audits 7082. Verify verbatim.
C2. THE READ-TIME + STRUCTURAL TRAPS (highest-value) — confirm in spec + pitfalls + greps:
    (a) hallucination_incidents has **NO risk column** — risk is read-time CT-04
    LEAST(100,15c+5w+1i) over **is_false_positive=false** rows (acknowledging does NOT close),
    fixture 1crit+1warn→20 (LLD 6793); (b) citation_source_intelligence uses **TWO partial
    unique indexes** (audit_id nullable, NULL≠NULL — NOT one UNIQUE; LLD 6960); (c)
    brand_consensus_checks UNIQUE(brand_id, source_type) + the cron **UPSERTs** (CU-01, LLD
    7244); (d) the ALTER does **NOT** add entity_score (D-01 — score_of_10 canonical) or
    scored_at (checked_at exists); (e) FK ON DELETE: hallucination.citation_id +
    evidence.audit_id SET NULL, citation_source_intelligence.audit_id CASCADE.
C3. SCORE FORMULAS — linkedin-auditor (30/40/30 with the threshold breakdown, LLD 7000),
    consensus consistency_score, youtube-auditor (15/20/35/20/10, channel-absent→0, LLD 7110)
    reproduced from the LLD, not invented.
C4. INNGEST (7 fns) — detect-hallucinations (audit/complete, emits hallucination/detected),
    capture-evidence-snapshot (audit/complete, Agency+), refresh-entity-score (technical-audit/
    complete SLASH — and the note that S7 must emit BOTH dot+slash; RE-01), build-citation-
    source-intelligence (citations/classified, NOT audit/complete — CI-02),
    audit-linkedin-presence (cron 0 3 2 * *), check-cross-platform-consensus (cron 0 3 4 * *,
    UPSERT), audit-youtube-presence (cron 0 3 3 * *, YouTube Data API v3). All 7 in serve()
    (running total 18). (LLD 7140+.)
C5. THE S4→S5 WIRING CONTRACT (critical — the point of the sprint) — confirm §0.2/§6.6/§10/§5
    wire: linkedin_presence_audits→linkedin_performance, brand_consensus_checks→consensus_score,
    brand_entity_scores knowledge_panel cols→knowledge_panel_status, citation_source_intelligence
    →source_type_gaps, evidence_snapshots→evidence_snapshots (Agency+) in the S4 narrative-
    generator; and detect-hallucinations + check-cross-platform-consensus → the S4 alert-composer
    hallucination/consensus triggers. (entity_home + agent_readiness correctly remain S6.)
C6. SEED — citation-source-affinity (8 source_type notes), ON CONFLICT DO NOTHING (LLD 6905).
C7. MIGRATION + RLS — MI-01 (CREATE TABLE/INDEX IF NOT EXISTS, ADD COLUMN IF NOT EXISTS for
    the ALTER + the organization_id backfill, DROP POLICY IF EXISTS); RLS on all 6 new tables;
    brand_entity_scores follows the LLD RLS spec (~8629), not an invented posture.
C8. UI (§6U) — TrustHub 2370 + the 8 sub-screens + 14 components; the read-time Hallucination
    Risk card (never a column), distinct acknowledge vs false-positive actions, citation-source
    affinity note prominent, the score formulas matching §6.5; each screen STATES + RESPONSIVE;
    Trust hub Growth+, evidence Agency+.
C9. TEMPLATE + DEPTH — sections 0–14 + §6U; no unspecified files; §12 greps runnable; §10
    self-contained. §1 module list = complete enumeration of the §4 tree (verify the
    S1-02/S2b-01/S3-01 pattern doesn't recur).
C10. ANYTHING MISSING / WRONGLY BUILT — the entity-home + agent_readiness S4 slots must remain
    S6 (not wired here); refresh-entity-score must read abn_verified before re-checking (no
    duplicate S7 ABN call); evidence_snapshots retention-exclusion noted for S12.

## SECTION D — FINDINGS FORMAT
Produce SPRINT5-FINDINGS.md: verdict PASS / PASS-WITH-FIXES / FAIL; numbered S5-01… with
severity + the LLD line checked + required fix; rulings on any OPEN QUESTIONS; your
independently-derived results; a clean pass is valid. Zip for Sri. Builder applies fixes,
bumps to v1.1, then Sprint 5 is ready for Claude Code.

## SECTION E — WHAT YOU MUST NOT DO
• Do not edit the prompt/LLD/prototype/plan — findings go back through Sri.
• Do not generate Sprint 6 (builder's job). • Do not bump any version (escalate real LLD gaps).
• Do not re-litigate handoff §F do-not-fix items.

— End of reviewer handoff. Run Section A, then Gate 2 per Section C.
