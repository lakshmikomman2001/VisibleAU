# VisibleAU Phase 2 — REVIEWER HANDOFF: SPRINT 6 PROMPT (Gate 2)
# Date: June 2026 | Written by: the BUILDER chat (original chat)
# Reviewing: visibleau-p2-sprint-6-prompt.md v1.0 (Retrieval Intelligence + Agent Readiness)

YOUR ROLE. Independent reviewer of a SPRINT PROMPT before it drives ~4 weeks of Claude Code
work. Derive your own view from the LLD/prototype first, then compare — never accept a cited
line without opening it. Respond in English only (Telugu only if Sri explicitly asks). Sprint 6
introduces a PUBLIC unauthenticated route (a new security surface) AND closes the last two S4
slots — review both carefully.

## SECTION A — VERIFY INPUTS (run BEFORE reviewing; STOP on failure)
A1. visibleau-phase2-v8.66-complete-REVIEWED.zip (canon — v8.66)
    • grep -m1 "^# Version:" visibleau-7layer-lld.md → "# Version: 8.66 | Date: June 2026"
    • grep -c "FIX 15 (v8.66)" visibleau-prototype-phase2.jsx → 1
    • grep -cE "ATTRIBUTION CORRECT(ED IN CROSS-REVIEW|ION)" → ≥1
    • v8.66 changed ONLY the prototype reduced-motion reset + LLD changelog; the Layer 1
      regions are identical to v8.65 r2, so a v8.65 r2 canon is also acceptable.
A2. visibleau-p2-sprint6-review-bundle.zip (under review)
    • visibleau-p2-sprint-6-prompt.md (v1.0) — status "Awaiting Gate 2"
    • visibleau-p2-SPRINT-PROMPT-PLAYBOOK-v1.0.md · SPRINT-MASTER-PLAN.md (S6 owns tables 8–11,
      5 Inngest fns, GAPs 2/3/8/12).

## SECTION B — WHAT SPRINT 6 IS
Retrieval Intelligence + Agent Readiness (Layer 1): AI crawler visit logging (via a PUBLIC
Visit API + a customer middleware snippet), per-page content-structure auditing (format
detection GAP 8, freshness, the citation_probability headline), llms.txt version tracking, the
5-dimension Agent Readiness Score (GAP 2) incl the MCP check (GAP 3), the content-format
advisor (GAP 8), and the Entity Home audit (GAP 12). 4 new tables + the brands.brand_token
ALTER, 5 Inngest fns, 8 lib modules + local-ai-trust-scorer, 5 screens. **Plus the S4→S6
wiring: it closes the LAST TWO S4 narrative-generator slots** (content_structure_audits →
entity_home_status; agent_readiness_scores → agent_readiness). LLD: Layer 1 (~5115) + Sprint 6
plan (~8966).

## SECTION C — GATE 2 CHECKS
C1. SCHEMA FIDELITY (4 tables + the brand_token ALTER) — open each LLD def (anchors in §5):
    crawler_visit_logs 5148, content_structure_audits 5225 (incl the entity-home cols),
    llmstxt_versions 5371, agent_readiness_scores 5387; brands.brand_token ALTER 5662. Verify
    verbatim, incl the partial indexes (crawler_logs_purpose_idx WHERE visit_purpose IS NOT
    NULL; llmstxt_one_current_per_brand WHERE is_current=true).
C2. THE STRUCTURAL TRAPS (highest-value) — confirm in spec + pitfalls + greps: (a)
    agent_readiness_scores is **APPEND-ONLY** (no UNIQUE/ON CONFLICT; latest by scored_at DESC;
    U-13, LLD 5475); (b) llmstxt_versions **partial unique index** one-current-per-brand + the
    transaction that sets others false (LLD 5380); (c) content_structure_audits **UPSERT** on
    UNIQUE(brand_id, page_url) (LLD 5710); (d) **entity_clarity_score is NOT
    brand_entity_scores.score_of_10** — different scale/table/meaning (LLD 5432); (e)
    **local_ai_trust_score is NULL for SaaS** brands (LLD 5460).
C3. THE 5 AGENT-READINESS DIMENSION FORMULAS — each /20 reproduced verbatim from the LLD
    (5404–5468): tech_score, entity_clarity_score, verify_score, authority_score, task_score →
    total /100; plus citation_probability_score contributions (LLD 5260) and the
    FORMAT_BY_ENGINE map + 3:1 listicle:how-to rule (LLD 5800). Not invented.
C4. THE PUBLIC VISIT API ROUTE (the new security surface — VA-01/BT-01/MW-01, LLD 5684) —
    confirm: '/api/visit' is added to the middleware isPublic matcher (MW-01); brandToken
    validation (SELECT brand WHERE brand_token → 401 if absent; never process without it,
    BT-01); rate-limit per token; emit 'visit/ingested'; return 202. The brands.brand_token
    ALTER (nanoid(32) + backfill) backs it. The snippet (public/visibleau-snippet.js) is
    specified.
C5. INNGEST (5 fns) — crawler-log-ingest ('visit/ingested'), content-structure-audit (cron
    0 22 * * 3, **REUSES lib/crawler/index.ts** — not a second crawler, UPSERT), llmstxt-refresh
    (cron 0 3 1 * *, one-current transaction), score-agent-readiness ('technical-audit/complete'
    slash, emits 'agent/readiness-scored', score-drop alert), audit-entity-home
    ('technical-audit/complete' slash, Action Center when sameAs<3). Plus the retention-cron
    extension for crawler_visit_logs (guarded). All 5 in serve() (running total 23). (LLD 5656+.)
C6. THE S4→S6 WIRING (closes the LAST TWO slots) — confirm §0.2/§6.7/§10 wire
    content_structure_audits entity_home_* → entity_home_status and agent_readiness_scores →
    agent_readiness in the S4 narrative-generator. After this all 12 S4 sections are wired.
C7. THE EXPLAINABILITY CONTRACT + RLS — confirm: every score-bearing response carries rationale
    + confidence_label + confidence_note + top_action via ExplainabilityService.annotate (LLD
    5490); every protected route calls setRlsContext (LLD 5620); cross-org → 404 not 401; the
    Visit route is the ONE documented public exception.
C8. MIGRATION + UI — MI-01 idempotency (CREATE TABLE/INDEX IF NOT EXISTS, ADD COLUMN IF NOT
    EXISTS, DROP POLICY IF EXISTS); RLS on all 4 new tables. UI: RetrievalHub 2537 + the 5
    sub-screens + 9 components; citation_probability as the HEADLINE (green/amber/red, not
    buried); the crawler-log visit_purpose badges; the agent-readiness spider gauge + MCP card +
    local-AI-trust (NULL/hidden for SaaS); each screen STATES + RESPONSIVE; Retrieval hub
    Starter+, is_active_agent tracking Growth+.
C9. TEMPLATE + DEPTH — sections 0–14 + §6U; no unspecified files; §12 greps runnable; §10
    self-contained. §1 module list = complete enumeration of the §4 tree (verify the
    S1-02/S2b-01/S3-01 pattern doesn't recur).
C10. ANYTHING MISSING / WRONGLY BUILT — content-structure-audit must REUSE the Sprint 7 crawler
    (not fork one); the retention extension must be guarded by table-presence; verify the
    event graph (visit/ingested producer=the Visit route; agent/readiness-scored consumer=S8
    fanout-webhooks forward; technical-audit/complete producer=S7 forward).

## SECTION D — FINDINGS FORMAT
Produce SPRINT6-FINDINGS.md: verdict PASS / PASS-WITH-FIXES / FAIL; numbered S6-01… with
severity + the LLD line checked + required fix; rulings on any OPEN QUESTIONS; your
independently-derived results; a clean pass is valid. Zip for Sri. Builder applies fixes,
bumps to v1.1, then Sprint 6 is ready for Claude Code.

## SECTION E — WHAT YOU MUST NOT DO
• Do not edit the prompt/LLD/prototype/plan — findings go back through Sri.
• Do not generate Sprint 7 (builder's job). • Do not bump any version (escalate real LLD gaps).
• Do not re-litigate handoff §F do-not-fix items.

— End of reviewer handoff. Run Section A, then Gate 2 per Section C.
