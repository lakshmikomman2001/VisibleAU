# VisibleAU Phase 2 — REVIEWER HANDOFF: SPRINT 7 PROMPT (Gate 2)
# Date: June 2026 | Written by: the BUILDER chat (original chat)
# Reviewing: visibleau-p2-sprint-7-prompt.md v1.0 (Conversational Discovery Intelligence)

YOUR ROLE. Independent reviewer of a SPRINT PROMPT before it drives ~4 weeks of Claude Code
work. Derive your own view from the LLD/prototype first, then compare — never accept a cited
line without opening it. Respond in English only (Telugu only if Sri explicitly asks). Sprint 7
carries THREE cross-sprint contracts (the technical-audit-run dual-emit that S5/S6 depend on,
crawler reuse, and completing the S3 benchmark) — review those as carefully as the new tables.

## SECTION A — VERIFY INPUTS (run BEFORE reviewing; STOP on failure)
A1. visibleau-phase2-v8.67-complete-REVIEWED.zip (canon — NOW v8.67)
    • grep -m1 "^# Version:" visibleau-7layer-lld.md → "# Version: 8.67 | Date: June 2026"
    • grep -c "FIX 15 (v8.66)" visibleau-prototype-phase2.jsx → 1 (prototype unchanged since v8.66)
    • grep -cE "ATTRIBUTION CORRECT(ED IN CROSS-REVIEW|ION)" → ≥1
    • v8.67 was a hygiene+security pass (S4-02 DDL comma, S5-02 webhook severity, S6-02 freshness
      tier, SEC-A/SEC-B Visit-route hardening) touching only those five spots — NONE in Layer 4 —
      so a v8.66 or v8.65 r2 canon is equally valid for this review.
A2. visibleau-p2-sprint7-review-bundle.zip (under review)
    • visibleau-p2-sprint-7-prompt.md (v1.0) — status "Awaiting Gate 2"
    • visibleau-p2-SPRINT-PROMPT-PLAYBOOK-v1.0.md · SPRINT-MASTER-PLAN.md (S7 owns tables 26–28,
      2 new Inngest fns + the technical-audit-run edit, completes the L4 half of GAP 4).

## SECTION B — WHAT SPRINT 7 IS
Conversational Discovery Intelligence (Layer 4): multi-turn conversation journeys + head-to-head
competitor comparison prompts. 3 tables (26–28), the journey runner + scorer, the comparison
runner, 2 Inngest fns, 3 discovery screens. **It is ALSO the infrastructure sprint S5/S6 depend
on:** it makes the Phase 1 technical-audit-run.ts emit BOTH technical-audit.complete (dot) AND
technical-audit/complete (slash) — the slash event is what S5's refresh-entity-score and S6's
score-agent-readiness + audit-entity-home listen on — and it completes the S3 Competitive
Benchmark by filling comparison_prompt_results (the CPR-01 "Coming soon" data goes live).
LLD: Layer 4 (~7457) + Sprint 7 plan (~9032).

## SECTION C — GATE 2 CHECKS
C1. SCHEMA FIDELITY (3 tables) — open each LLD def (anchors in §5): conversation_journeys 7469,
    journey_run_results 7500, comparison_prompt_results 7530. Verify verbatim, incl the indexes.
C2. THE STRUCTURAL TRAPS (highest-value) — confirm in spec + pitfalls + greps: (a)
    conversation_journeys.prompt_sequence is **typed JourneyTurn[]** (TS-01, LLD 7480) with Zod
    .min(2).max(8) on create; (b) the **vertical CHECK** = tradies|allied_health|saas|
    professional_services|real_estate; (c) **journey_run_results.journey_id is ON DELETE CASCADE**
    (NOT NULL parent — SET NULL impossible; LLD 7505); (d) **comparison_prompt_results.audit_id is
    ON DELETE CASCADE** (Sprint 12 retention depends on it; LLD 7535); (e) brand_won is NULLABLE.
C3. THE journey_score FORMULA (LLD 7515) — base (brand_appeared_in_n_turns/total_turns)×100 +
    early-mention bonus (turn1 +10 / turn2 +5 / ≥3 +0), cap 100.0; the LLD example 3/5 first@1 →
    70.0. Reproduced, not invented.
C4. THE THREE CROSS-SPRINT CONTRACTS (the point of the sprint) — confirm:
    (i) **THE DUAL-EMIT** (LLD 1064): §8.3 edits the Phase 1 technical-audit-run.ts to emit BOTH
        'technical-audit.complete' (dot, webhooks) AND 'technical-audit/complete' (slash, internal)
        — without the slash form, S5's refresh-entity-score and S6's score-agent-readiness +
        audit-entity-home never fire. This is the #1 thing to verify.
    (ii) **CRAWLER REUSE**: S7 must NOT recreate lib/crawler/index.ts (Sprint 6 built it full);
        reuse/extend only.
    (iii) **S3 BENCHMARK COMPLETION**: run-comparison-prompts fills comparison_prompt_results so
        the S3 Competitive Benchmark route returns real data and the CPR-01 "Coming soon" card
        becomes the live comparison view (the comparisons screen reuses the S3 shell, prototype 2001).
C5. INNGEST (2 new fns + the edit) — run-journey (event-driven, Agency+, concurrency 3,
    **STEP.RUN per turn×engine with STABLE names** so retries skip completed steps — SN-01, LLD
    7560; engine-gate via isEngineEnabled with the ENGINE_TO_PROVIDER map — PROVIDER names not
    engine names), run-comparison-prompts (on **audit/complete** — PC-05, concurrency 3, reads
    brands.competitors, TIER_ENGINES + engine-gate). serve() running total → 25 (the full set).
C6. TIER GATING (v8.19 — easy to get wrong) — the conversation_journeys UX is **Agency+ only**
    (Growth sees the locked teaser with the exact v8.19 copy); comparison_prompt_results / the
    Competitive Benchmark is **Growth+**. The full data model + Inngest functions are built
    regardless of tier — only the journey UX is gated.
C7. SEED + RLS — 3 pre-built journeys per vertical (15 rows, valid JourneyTurn[], ON CONFLICT DO
    NOTHING; LLD 9046 acceptance); RLS on all 3 tables; setRlsContext on every protected route;
    cross-org → 404.
C8. UI (§6U) — DiscoveryHub 2944 (Agency launcher+cards / Growth teaser), the journeys screen
    (flow chart + result cards, Agency+ TierGate), the comparisons screen (verdict cards reusing
    the S3 CompetitiveBenchmark shell 2001). Each screen STATES + RESPONSIVE; both themes.
C9. TEMPLATE + DEPTH — sections 0–14 + §6U; no unspecified files; §12 greps runnable; §10
    self-contained. §1 module list = complete enumeration of the §4 tree (verify the
    S1-02/S2b-01/S3-01/S6-03 pattern doesn't recur — it slipped in S6).
C10. ANYTHING MISSING / WRONGLY BUILT — the dual-emit must NOT change Phase 1 scoring logic (only
    add the two emits); the crawler must not be recreated; verify the event graph (run-comparison
    on audit/complete=Phase 1 producer; the dual-emit now feeds the S5/S6 listeners).

## SECTION D — FINDINGS FORMAT
Produce SPRINT7-FINDINGS.md: verdict PASS / PASS-WITH-FIXES / FAIL; numbered S7-01… with
severity + the LLD line checked + required fix; rulings on any OPEN QUESTIONS; your
independently-derived results; a clean pass is valid. Zip for Sri. Builder applies fixes,
bumps to v1.1, then Sprint 7 is ready for Claude Code.

## SECTION E — WHAT YOU MUST NOT DO
• Do not edit the prompt/LLD/prototype/plan — findings go back through Sri.
• Do not generate Sprint 8 (builder's job). • Do not bump any version (escalate real LLD gaps).
• Do not re-litigate handoff §F do-not-fix items.

— End of reviewer handoff. Run Section A, then Gate 2 per Section C.
