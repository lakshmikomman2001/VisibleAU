# VisibleAU Phase 2 — REVIEWER HANDOFF: SPRINT 8 PROMPT (Gate 2)
# Date: June 2026 | Written by: the BUILDER chat (original chat)
# Reviewing: visibleau-p2-sprint-8-prompt.md v1.0 (Governance Intelligence)

YOUR ROLE. Independent reviewer of a SPRINT PROMPT before it drives ~3 weeks of Claude Code
work. Derive your own view from the LLD/prototype first, then compare — never accept a cited
line without opening it. Respond in English only (Telugu only if Sri explicitly asks). Sprint 8
carries the fanout-webhooks extension (the consumer that completes the S3–S7 webhook chain —
the mirror of S7's dual-emit) AND raises an OPEN QUESTION (local_seo_results) — review both with
care, plus the RBAC/auth-layering correctness.

## SECTION A — VERIFY INPUTS (run BEFORE reviewing; STOP on failure)
A1. visibleau-phase2-v8.67-complete-REVIEWED.zip (canon — v8.67)
    • grep -m1 "^# Version:" visibleau-7layer-lld.md → "# Version: 8.67 | Date: June 2026"
    • grep -c "FIX 15 (v8.66)" visibleau-prototype-phase2.jsx → 1 (prototype unchanged since v8.66)
    • grep -cE "ATTRIBUTION CORRECT(ED IN CROSS-REVIEW|ION)" → ≥1
    • v8.67 was a hygiene+security pass (S4-02/S5-02/S6-02/SEC-A/SEC-B) touching five spots —
      NONE in Layer 7 — so a v8.66 or v8.65 r2 canon is equally valid for this review.
A2. visibleau-p2-sprint8-review-bundle.zip (under review)
    • visibleau-p2-sprint-8-prompt.md (v1.0) — status "Awaiting Gate 2"
    • visibleau-p2-SPRINT-PROMPT-PLAYBOOK-v1.0.md · SPRINT-MASTER-PLAN.md (S8 owns tables 35–38;
      the master plan lists EXACTLY those 4 governance tables for S8).

## SECTION B — WHAT SPRINT 8 IS
Governance Intelligence (Layer 7): audit trail, team RBAC with brand-scoped access + invite
lifecycle, data-residency disclosure, per-org feature flags. 4 tables (35–38), 4 lib/governance
modules + the Phase 1 feature-flags edit, 3 settings screens. **Plus the #1 cross-sprint payoff:
the fanout-webhooks extension** (WH-01) — wiring the 5 Phase 2 internal slash-events (emitted by
S3–S6 + the S5 acknowledge API) into outbound delivery so subscribed customers receive them
(today they're configurable-but-undeliverable). NO new Inngest function (fanout is Phase 1,
extended); serve() stays 25/25. LLD: Layer 7 (~8493) + the fanout extension (~3850) + Sprint 8
plan (~9038).

## SECTION C — GATE 2 CHECKS
C1. SCHEMA FIDELITY (4 tables) — open each LLD def (anchors in §5): audit_trail 8507, org_members
    8545, data_residency_log 8599, org_feature_flags 8647. Verify verbatim, incl the UNIQUE
    constraints (org+user, org+data_type, org+flag_key) and audit_trail.user_id NULLABLE.
C2. THE STRUCTURAL/SEMANTIC TRAPS (highest-value) — confirm in spec + pitfalls + greps: (a) the
    Phase 2 audit_trail action/resource_type enums (AT-01, LLD 8512); (b) org_members FKs to the
    **users mirror NOT auth_members** + the role enum + brand_access null=all + the invitation
    single-use token + the **IC-01 cancel rule** (delete only unaccepted); (c) data_residency_log
    is a **declarative UPSERT** with the DR-01 writer (record-data-residency.ts) + the DR-02
    retention/encryption columns; (d) org_feature_flags **operator-set only** + the canonical
    flag_key set + the **priority order org_feature_flags > env > defaults** (the Phase 1
    lib/feature-flags/index.ts edit).
C3. THE 3-LAYER AUTH MODEL + RBAC MATRIX (LLD 8533/8556) — confirm access-control checks in order
    Better Auth session → users.role (org-level) → org_members (brand-level), and the matrix is
    reproduced (analyst runs audits but can't approve drafts; viewer read-only; only owner deletes
    a brand; invite = owner/admin).
C4. THE fanout-webhooks EXTENSION (the #1 risk — WH-01, LLD 3850) — confirm §8.1 extends BOTH the
    trigger array (5 events) AND the deliveryEventName map (5 internal slash → external dot), names
    each producer (S3 aggregate-visibility-trend, S4 generate-narrative-report, S5 detect-
    hallucinations + the acknowledge API, S6 score-agent-readiness), requires { organizationId } in
    each emit, AND adds retry-idempotency (webhook_deliveries dedup + step.run per endpoint so a
    retry doesn't double-POST — the S7-pass-2 theme). serve() stays 25 (fanout is Phase 1, extended).
C5. OQ-1 — local_seo_results (the JUDGMENT call) — the prompt RAISES local_seo_results as an OPEN
    QUESTION rather than inventing it: the canon has NO CREATE TABLE for it (only a prose "Sprint 8"
    tag at LLD 3822, two referenced columns in the local_ai_trust_score formula at LLD 5488, and two
    lib filenames), and the master plan + Layer 7 + the S8 plan entry scope this sprint as
    governance-only (35–38). VERIFY this is correct (grep `CREATE TABLE local_seo_results` → 0) and
    that flagging-not-inventing is the right call — S6's local_ai_trust_score was set NULL until it
    exists (S6b-02), so deferring is consistent. If you think the LLD intends it built here, say so.
C6. SEED/WRITER + RLS + barrel — the residency writer is a runtime UPSERT (not a seed file); RLS on
    all 4 tables; setRlsContext on every protected route; cross-org → 404; the phase2-governance
    barrel exports added to db/schema/index.ts (TS build breaks otherwise).
C7. UI (§6U) — TeamManagement 2800 + DataResidency 3034 + the audit-trail viewer; role badges,
    invite form, the GV-2 residency columns (DR-02); owner/admin gating vs analyst/viewer read-only;
    each screen STATES + RESPONSIVE; both themes.
C8. AUDIT-TRAIL WIRING — confirm recordAction is called on the 7 Phase 2 audited actions (draft
    approve/dismiss, journey trigger, hallucination acknowledge, flag change, residency view,
    benchmark view).
C9. TEMPLATE + DEPTH — sections 0–14 + §6U + the §0.6 OPEN QUESTIONS block; no unspecified files
    (besides the deliberately-deferred local_seo_results); §12 greps runnable; §10 self-contained.
    §1 module list = complete enumeration of the §4 tree (verify the S1-02/S2b-01/S3-01/S6-03
    pattern doesn't recur).
C10. ANYTHING MISSING / WRONGLY BUILT — the fanout extension must not be half-done (both trigger +
    map); the feature-flag priority edit must not break S7's engine-gate; verify the webhook
    producers (S3–S6) actually emit the slash events the extension expects.

## SECTION D — FINDINGS FORMAT
Produce SPRINT8-FINDINGS.md: verdict PASS / PASS-WITH-FIXES / FAIL; numbered S8-01… with
severity + the LLD line checked + required fix; **a RULING on OQ-1** (build now with a defined
schema / defer — your recommendation to Sri); your independently-derived results; a clean pass
is valid. Zip for Sri. Builder applies fixes, bumps to v1.1, then Sprint 8 is ready for Claude Code.

## SECTION E — WHAT YOU MUST NOT DO
• Do not edit the prompt/LLD/prototype/plan — findings go back through Sri.
• Do not generate Sprint 9 (builder's job). • Do not bump any version (escalate real LLD gaps).
• Do not re-litigate handoff §F do-not-fix items. • Do not resolve OQ-1 unilaterally — recommend.

— End of reviewer handoff. Run Section A, then Gate 2 per Section C.
