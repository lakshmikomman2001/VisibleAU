# VisibleAU Phase 2 — REVIEWER HANDOFF: SPRINT 9 PROMPT (Gate 2) — THE FINAL SPRINT
# Date: June 2026 | Written by: the BUILDER chat (original chat)
# Reviewing: visibleau-p2-sprint-9-prompt.md v1.0 (AI Visibility Autopilot UX)

YOUR ROLE. Independent reviewer of the FINAL sprint prompt before it drives ~3 weeks of Claude
Code work. Derive your own view from the LLD/prototype first, then compare — never accept a cited
line without opening it. Respond in English only (Telugu only if Sri explicitly asks). Sprint 9 is
STRUCTURALLY DIFFERENT from S1–S8: it adds NO tables, NO migration, NO Inngest function — it's
pure frontend + 2 read-only GET routes that make the Autopilot loop VISIBLE over existing S1–S8
data. So the usual schema-fidelity checks don't apply; the weight is on the UI surfaces, the two
read queries (esp. the v8.16 citations/audits join), and the cross-sprint contracts S9 consumes.

## SECTION A — VERIFY INPUTS (run BEFORE reviewing; STOP on failure)
A1. visibleau-phase2-v8.67-complete-REVIEWED.zip (canon — v8.67)
    • grep -m1 "^# Version:" visibleau-7layer-lld.md → "# Version: 8.67 | Date: June 2026"
    • grep -c "FIX 15 (v8.66)" visibleau-prototype-phase2.jsx → 1 (prototype unchanged since v8.66)
    • grep -cE "ATTRIBUTION CORRECT(ED IN CROSS-REVIEW|ION)" → ≥1
    • v8.67 (S4-02/S5-02/S6-02/SEC-A/SEC-B) touched none of the Sprint 9 surfaces — a v8.66 or
      v8.65 r2 canon is equally valid here.
A2. visibleau-p2-sprint9-review-bundle.zip (under review)
    • visibleau-p2-sprint-9-prompt.md (v1.0) — status "Awaiting Gate 2"
    • visibleau-p2-SPRINT-PROMPT-PLAYBOOK-v1.0.md · SPRINT-MASTER-PLAN.md (S9 = 0 tables, 0
      Inngest fns, pure frontend personalisation; master plan lines 111/192).

## SECTION B — WHAT SPRINT 9 IS
AI Visibility Autopilot UX — the final sprint, and the aha moment: ONE visible end-to-end loop
(Audit → Prioritize the #1 gap → Explain → Execute/approve → re-audit → Measure) over data the
model ALREADY has (topical_coverage_gaps → remediation_tasks → content_drafts → workflow_runs →
score delta), plus the Action Progress Tracker (one query), the AI Visibility Health Check
packaging, the per-prompt trend chart, and persona-aware dashboards. NO new tables / migration /
Inngest function (serve() stays 25/25); 2 read-only GET routes. Closes GAP 10 (the last GAP).
LLD: Sprint 9 plan (~9050–9090) + the explainability contract (~5556).

## SECTION C — GATE 2 CHECKS (adapted — this is a frontend/read-only sprint)
C1. NO-SCHEMA / NO-PIPELINE DISCIPLINE — verify the prompt adds NO table, migration, barrel
    change, or Inngest function (§5/§6/§8 all say "none"), and serve() stays 25/25. A value that
    isn't displayable is an upstream bug, NOT an S9 table — confirm the prompt says so.
C2. THE v8.16 JOIN (the one high-risk query) — the per-prompt trend route MUST filter by brand via
    citations.audit_id → audits.brand_id (citations has NO brand_id; that was the v8.16 bug). Open
    LLD ~9075 and confirm the query + the "no brand_id" note are reproduced exactly. §12 greps for
    JOIN audits ≥1 AND citations.brand_id = 0.
C3. THE ACTION PROGRESS TRACKER (the retention metric) — one query:
    COUNT(remediation_tasks status='complete' AND updated_at >= period_start)/total + the
    citation-rate delta from visibility_trends (LLD ~9060). Growth+, prominent on the dashboard.
C4. THE AUTOPILOT LOOP (the primary story) — the 5 steps map to the right existing sources (gap →
    remediation_task/topical_coverage_gap; explain → explainability; draft → content_draft, the
    1-click approve RE-USING S2's existing approve action through assertBrandAccess — NOT a new
    write; measure → score delta). CRITICAL: step.status is PRESENTATIONAL ('done'|'current'|
    'pending'), explicitly NOT remediation_tasks.status (the DB enum) — verify the prompt forbids
    conflating them (prototype 3127 has this exact audit note).
C5. THE EXPLAINABILITY CONTRACT — every score-bearing S9 surface RENDERS S6's { score,
    explainability } (rationale/confidence_note/top_action); S9 must NOT call
    ExplainabilityService.annotate() itself (that's the scoring routes' job). The loop's "Explain"
    step IS this contract visualised (LLD 5556, GAP 9).
C6. BRAND-ACCESS GATE (carried from S8b-01) — every brand-scoped S9 route + the Autopilot approve
    must call assertBrandAccess, so the Autopilot can't act outside a member's brands. Verify the
    prompt carries this forward (it's the S8b-01 forward note) and the §11 test enforces it.
C7. UI surfaces — Autopilot 3127, HealthCheck 1399 (traffic-light dims + one action),
    EnhancedDashboard 1089 (the tracker), the per-prompt sparkline, persona dashboards (Agency/SMB/
    tradie). Each STATES + RESPONSIVE; both themes; the animated Autopilot/Health banners honour
    the reduced-motion reset; the ${jsVar}30 hex-alpha borders are VALID (interpolated JS var) —
    don't flag them; reuse the existing chart lib (no second one).
C8. TIER GATING — loop/health/tracker/trend/persona = Growth+; the Agency command centre = Agency+.
C9. TEMPLATE/DEPTH — note the deliberate structural difference (no §5 schema; §6/§8 "none"); the
    §1 surface list = the complete §4-tree enumeration (the S1-02/S6-03 pattern check still
    applies to the component/route tree); §12 greps runnable; §10 self-contained.
C10. CROSS-SPRINT CONSUMPTION — S9 is the consumer of nearly everything; verify it doesn't
    silently assume a value that an owning sprint didn't actually build (the S8-01 lesson — e.g.
    confirm the wins-feed/score-delta/explainability it reads are real outputs, not assumed).

## SECTION D — FINDINGS FORMAT
Produce SPRINT9-FINDINGS.md: verdict PASS / PASS-WITH-FIXES / FAIL; numbered S9-01… with severity
+ the LLD line checked + required fix; your independently-derived results; a clean pass is valid.
Zip for Sri. Builder applies fixes, bumps to v1.1, then Sprint 9 is ready for Claude Code — and
Phase 2 prompt generation is COMPLETE (next is Gate 3, not another sprint).

## SECTION E — WHAT YOU MUST NOT DO
• Do not edit the prompt/LLD/prototype/plan — findings go back through Sri.
• There is no Sprint 10 to generate (Phase 2 ends at S9). • Do not bump any version (escalate
real LLD gaps). • Do not re-litigate handoff §F do-not-fix items, incl the deliberate
local_seo_results deferral (OQ-1) and the Autopilot presentational step states.

— End of reviewer handoff. Run Section A, then Gate 2 per Section C.
