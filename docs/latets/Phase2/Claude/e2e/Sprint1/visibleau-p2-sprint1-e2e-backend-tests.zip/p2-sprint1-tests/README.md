# VisibleAU Phase 2 — Sprint 1 (Platform Foundation) — E2E Backend Tests

End-to-end backend tests for **Phase 2 Sprint 1**, derived from the Sprint 1 prompt (v1.1) and
LLD v8.65 §"PHASE 2 SPRINT 1 — PLATFORM FOUNDATION" (≈4760–5082). Sprint 1 is backend-only —
no UI, no new API routes — so this suite exercises the **schema, seeds, RLS, FK behaviour, the 6
platform services, the config CLI, and the Phase 1 boundary** against a real Postgres.

> ⚠️ **Version note.** These were written against the materials on hand: **LLD v8.65 / Sprint 1
> prompt v1.1**. Your canonical is **v8.68 / S1 v1.5**. The v8.66→v8.68 bumps were in S7b/S8/S9, so
> Sprint 1's schema/services should be unchanged — but if S1 v1.5 altered anything (columns,
> seed values, service signatures), re-pin the affected assertions. The exact-value tests
> (seed thresholds, the provider matrix, FK rules, defaults) are where a spec drift would show.

> ✅ **Clean-audited.** Re-audited against the verbatim LLD v8.65 — see `AUDIT-FINDINGS.md` for the
> 4 conflicts found and fixed (record() USD units, a budget-test `UNIQUE` bug, a vacuous digest
> assertion, fragile fixture SQL) plus 4 advisory notes the build must satisfy.

---

## What's here

```
tests/phase2/sprint1/
├── _harness/
│   ├── test-db.ts        real test-Postgres: applyMigration, runRepoSeeds, truncateAll, withOrgContext (RLS), rlsEnabled
│   ├── fixtures.ts       insert helpers for orgs/subscriptions/audits + all 7 Sprint 1 tables
│   └── services.ts       THE single seam to wire the repo's 6 services (and an Observability spy)
├── schema-and-migration.e2e.test.ts   7 tables, column defaults, uniques, partial active-bundle index, audits ALTER, FK rules, RLS posture, MI-01 idempotency
├── seeds.e2e.test.ts                  7 metric gates (exact thresholds) + 4 providers (incl. anthropic citations=FALSE, perplexity fan_out=FALSE), seed idempotency
├── rls-isolation.e2e.test.ts          audit_cost_snapshots USING (read) + WITH CHECK (write) tenant isolation
├── fk-ondelete.e2e.test.ts            audit delete → CASCADE; budget-policy delete → SET NULL (v8.28)
├── config-bundle.service.e2e.test.ts  activate() one-active invariant + partial index + resolve() + digest
├── budget-policy.service.e2e.test.ts  tier from subscriptions (not organizations), hard-stop, record() snapshot + sample-org skip + USD→AUD
├── sampling-policy.service.e2e.test.ts  getQualityLabel 'Insufficient data' boundary + validate()
├── provider-capability.registry.e2e.test.ts  empty-when-unseeded seed dependency, enabled filtering, matrix lookups, tier-aware getBestProvider
├── quality-gate.service.e2e.test.ts   evaluate() pending→sufficient/insufficient/partial  (skipped — see adapter #3)
├── config-cli.e2e.test.ts             config:validate exit codes (the CI contract)
└── phase1-unchanged.regression.e2e.test.ts  Phase 1 scores identical + runsPerPrompt=5 with services in path (skipped — see adapter #4)
```

Two files ship as `describe.skip` because they need one repo detail each (below); everything else
runs as soon as the harness is wired.

---

## Setup

1. **Test database.** Provision a throwaway Postgres and set `TEST_DATABASE_URL`. The harness
   refuses to run unless the URL contains `test`/`ci`/`tmp`/`scratch` (it TRUNCATEs tables).
   - **RLS gotcha:** connect as the **non-superuser app role**. Postgres bypasses RLS for
     superusers and table owners with `BYPASSRLS`; if you connect as one, `rls-isolation` passes
     for the wrong reason. Mirror the role your Phase 1 RLS tests use.
2. **`LLM_MODE=mock`** in the test environment.
3. **Runner.** Written for Vitest (`describe/it/expect/beforeAll/...`). The API is Jest-compatible;
   if the repo uses Jest, only the import line changes. Run with `pnpm vitest run tests/phase2/sprint1`.

### Adapter seams (the only repo-coupling — wire these)
1. **`test-db.ts` → `applyMigration()`** — set `SPRINT1_MIGRATION_GLOB` to your migration path, or
   swap the body for Drizzle's `migrate(db, { migrationsFolder })`.
2. **`test-db.ts` → `runRepoSeeds()`** — point at your real seed entrypoint so `seeds.e2e.test.ts`
   tests the actual seed files, not a re-implementation.
3. **`services.ts`** — wire the 5 `make*` factories to the repo's service exports (class / singleton
   / module). If services take a Drizzle handle, build one from `TEST_DATABASE_URL` here.
4. **`fixtures.ts` → `seedAuditDimensionSamples()`** — map to whatever source
   `QualityGateService.evaluate()` reads per-dimension sample counts from (the LLD doesn't pin this
   down). Then remove `.skip` in `quality-gate.service.e2e.test.ts`.
5. **`phase1-unchanged.regression.e2e.test.ts`** — import the Phase 1 `runAudit`/`refreshAudit`
   and a score-readback, commit a known-good baseline, remove `.skip`.
6. **Phase 1 fixture columns** — `insertOrganization/Subscription/Audit` use likely column names
   (`organization_id`, `tier`, `slug`, `region`, `total_cost_usd`, `prompts_count`, `total_calls`,
   `quality_status`). Adjust to your actual Phase 1 schema if they differ. **If the `audits` table
   has RLS** (like `audit_cost_snapshots`), wrap `insertAudit()` in `withOrgContext` or run fixtures
   as a role that can write it (advisory A-03).

---

## Coverage vs the Sprint 1 spec

**§11 tests required** — all six are present (budget, sampling, provider, config-bundle, quality-gate
integration, phase1-unchanged regression), expanded to true E2E.

**§12 verification greps** — turned into live assertions: 7 tables created; MI-01 idempotency
(re-apply doesn't throw); `config_bundle_one_active` partial index; the two FK ON DELETE rules;
`anthropic.supports_citations=false`; 4 audits-ALTER columns; tier read from `subscriptions`
(behavioural divergence test, stronger than the grep); no hardcoded engine list (the registry/tier
tests prove TIER_ENGINES governs); both seeds present.

**§13 anti-patterns** — each has a guard: skipping seeds (empty-registry test), reading
`organizations.tier` (divergence test), conflating the two sample knobs (regression asserts
runsPerPrompt=5), RLS on/off posture (schema + isolation tests), changing Phase 1 scoring
(regression), wrong FK ON DELETE (fk-ondelete).

---

## What these tests do NOT cover (out of Sprint 1 scope)
No UI, no Phase 2 API routes (first appear in Sprint 3), no new Inngest functions (§8 — the services
are called by existing Phase 1 functions; that wiring is asserted indirectly by the regression test).
The `config:coverage` and `config:diff` CLI subcommands have lighter coverage than `config:validate`
(the CI-critical one) — add cases if you wire them into CI gating too.
