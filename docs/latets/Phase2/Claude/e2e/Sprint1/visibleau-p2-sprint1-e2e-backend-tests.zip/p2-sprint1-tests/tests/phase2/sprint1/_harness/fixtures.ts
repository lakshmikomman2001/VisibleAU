// tests/phase2/sprint1/_harness/fixtures.ts
//
// Insert helpers for Sprint 1 E2E tests. Raw SQL keeps these independent of the repo's
// exact Drizzle schema exports. Column lists below match the LLD; if your Phase 1
// organizations/subscriptions/audits columns differ, adjust the three Phase 1 helpers
// (insertOrganization / insertSubscription / insertAudit) — the Sprint 1 helpers are exact.

import { sql } from './test-db';

export type Tier = 'free' | 'starter' | 'growth' | 'agency' | string;

// ── Phase 1 rows (ADAPT column names to your schema if needed) ──────────────────

export async function insertOrganization(opts: {
  slug?: string; region?: string; tier?: Tier; // LEGACY org column; services must NOT read it
} = {}): Promise<{ id: string }> {
  const { slug = `org-${rand()}`, region = 'AU', tier } = opts;
  // organizations.tier is OPTIONAL. It exists only as a legacy column some schemas still carry;
  // Sprint 1 services must read subscriptions.tier, never this. The phase1-unchanged regression
  // test sets it adversarially (org.tier ≠ subscription.tier) to prove the CALLER reads the
  // subscription. If your organizations table has no tier column, simply never pass `tier`.
  const [row] = tier === undefined
    ? await sql<{ id: string }[]>`
        INSERT INTO organizations (slug, region) VALUES (${slug}, ${region}) RETURNING id`
    : await sql<{ id: string }[]>`
        INSERT INTO organizations (slug, region, tier) VALUES (${slug}, ${region}, ${tier}) RETURNING id`;
  return row;
}

export async function insertSubscription(opts: {
  organizationId: string; tier: Tier;
}): Promise<{ id: string }> {
  const [row] = await sql<{ id: string }[]>`
    INSERT INTO subscriptions (organization_id, tier)
    VALUES (${opts.organizationId}, ${opts.tier})
    RETURNING id
  `;
  return row;
}

export async function insertAudit(opts: {
  organizationId: string; brandId?: string; totalCostUsd?: number;
  promptsCount?: number; totalCalls?: number; qualityStatus?: string;
}): Promise<{ id: string }> {
  const {
    organizationId, brandId = null, totalCostUsd = 0,
    promptsCount = 0, totalCalls = 0, qualityStatus = 'pending',
  } = opts;
  const [row] = await sql<{ id: string }[]>`
    INSERT INTO audits (organization_id, brand_id, total_cost_usd, prompts_count, total_calls, quality_status)
    VALUES (${organizationId}, ${brandId}, ${totalCostUsd}, ${promptsCount}, ${totalCalls}, ${qualityStatus})
    RETURNING id
  `;
  return row;
}

// ── Sprint 1 rows (exact to the LLD) ────────────────────────────────────────────

export async function insertBudgetPolicy(opts: {
  marketCode?: string; segment?: string; useCase?: string;
  maxModelsPerAudit?: number; maxRepeatedSamples?: number;
  maxEstimatedCostCents?: number; hardStopOnBudget?: boolean;
} = {}): Promise<{ id: string }> {
  const {
    marketCode = 'AU_EN', segment = 'smb', useCase = 'visibility',
    maxModelsPerAudit = 4, maxRepeatedSamples = 5,
    maxEstimatedCostCents = 500, hardStopOnBudget = true,
  } = opts;
  const [row] = await sql<{ id: string }[]>`
    INSERT INTO market_ai_budget_policies
      (market_code, segment, use_case, max_models_per_audit, max_repeated_samples,
       max_estimated_cost_cents, hard_stop_on_budget)
    VALUES (${marketCode}, ${segment}, ${useCase}, ${maxModelsPerAudit}, ${maxRepeatedSamples},
            ${maxEstimatedCostCents}, ${hardStopOnBudget})
    RETURNING id
  `;
  return row;
}

export async function insertSamplingPolicy(opts: {
  marketCode?: string; segment?: string; useCase?: string;
  minimumPromptCount?: number; recommendedPromptCount?: number;
  minimumRepeatedSamples?: number; confidenceDisplayThreshold?: number;
} = {}): Promise<{ id: string }> {
  const {
    marketCode = 'AU_EN', segment = 'smb', useCase = 'visibility',
    minimumPromptCount = 10, recommendedPromptCount = 50,
    minimumRepeatedSamples = 3, confidenceDisplayThreshold = 0.6,
  } = opts;
  const [row] = await sql<{ id: string }[]>`
    INSERT INTO sampling_policies
      (market_code, segment, use_case, minimum_prompt_count, recommended_prompt_count,
       minimum_repeated_samples, confidence_display_threshold)
    VALUES (${marketCode}, ${segment}, ${useCase}, ${minimumPromptCount}, ${recommendedPromptCount},
            ${minimumRepeatedSamples}, ${confidenceDisplayThreshold})
    RETURNING id
  `;
  return row;
}

export async function insertConfigBundle(opts: {
  marketCode?: string; locale?: string; segment?: string; bundleVersion: number;
  resolvedConfig?: unknown; configDigest?: string; isActive?: boolean;
}): Promise<{ id: string }> {
  const {
    marketCode = 'AU_EN', locale = 'en-AU', segment = 'smb', bundleVersion,
    resolvedConfig = { ok: true }, configDigest = `digest-${bundleVersion}`, isActive = false,
  } = opts;
  const [row] = await sql<{ id: string }[]>`
    INSERT INTO config_bundle_cache
      (market_code, locale, segment, bundle_version, config_digest, resolved_config, is_active)
    VALUES (${marketCode}, ${locale}, ${segment}, ${bundleVersion}, ${configDigest},
            ${sql.json(resolvedConfig as object)}, ${isActive})
    RETURNING id
  `;
  return row;
}

export async function insertProvider(opts: {
  providerKey: string; modelKey: string; marketCode?: string; locale?: string;
  supportsWebRetrieval?: boolean; supportsCitations?: boolean;
  supportsLocationContext?: boolean; supportsQueryFanOut?: boolean;
  maxFanOutSubQueries?: number; isEnabled?: boolean;
}): Promise<{ id: string }> {
  const {
    providerKey, modelKey, marketCode = 'AU_EN', locale = 'en-AU',
    supportsWebRetrieval = false, supportsCitations = false,
    supportsLocationContext = false, supportsQueryFanOut = false,
    maxFanOutSubQueries = 12, isEnabled = false,
  } = opts;
  const [row] = await sql<{ id: string }[]>`
    INSERT INTO provider_market_capabilities
      (provider_key, model_key, market_code, locale, supports_web_retrieval, supports_citations,
       supports_location_context, supports_query_fan_out, max_fan_out_sub_queries, is_enabled)
    VALUES (${providerKey}, ${modelKey}, ${marketCode}, ${locale}, ${supportsWebRetrieval},
            ${supportsCitations}, ${supportsLocationContext}, ${supportsQueryFanOut},
            ${maxFanOutSubQueries}, ${isEnabled})
    RETURNING id
  `;
  return row;
}

export async function insertMetricQualityGate(opts: {
  metricKey: string; marketCode?: string; minimumSamples: number; minimumProviderCount?: number;
}): Promise<void> {
  const { metricKey, marketCode = 'AU_EN', minimumSamples, minimumProviderCount = 2 } = opts;
  await sql`
    INSERT INTO metric_quality_gates (metric_key, market_code, minimum_samples, minimum_provider_count)
    VALUES (${metricKey}, ${marketCode}, ${minimumSamples}, ${minimumProviderCount})
  `;
}

/**
 * ADAPT-TO-REPO: QualityGateService.evaluate(auditId) compares PER-DIMENSION SAMPLE COUNTS
 * against metric_quality_gates. The LLD does not pin down which table/column holds those
 * counts (it's the audit's scoring data). Wire this helper to whatever evaluate() actually
 * reads — e.g. inserting audit_scores rows, or setting a sample_count column — so the
 * quality-gate test drives real input. Until wired, quality-gate.service.e2e.test.ts is
 * skipped via `describe.skip` with a pointer here.
 */
export async function seedAuditDimensionSamples(
  _auditId: string,
  _counts: Record<string, number>, // e.g. { frequency: 12, sentiment: 12, accuracy: 6, ... }
): Promise<void> {
  throw new Error(
    'seedAuditDimensionSamples() not wired — map it to the source QualityGateService.evaluate() reads.',
  );
}

function rand() { return Math.random().toString(36).slice(2, 8); }
