// tests/phase2/sprint1/_harness/services.ts
//
// THE SINGLE REPO-COUPLING SEAM for the service-level tests.
// The tests below are written against the method signatures in Sprint 1 prompt §6 / LLD
// 4980–5074. They do NOT assume how your services are constructed. Wire each factory to the
// repo's actual export (class, singleton, or function module) and every service test runs.
//
// Expected method shapes (from §6):
//   BudgetPolicyService:        estimate(params) -> CostEstimate; enforce(estimate, policy) -> EnforcementResult; record(auditId, actualCents) -> void
//   SamplingPolicyService:      getPolicy(market, segment, useCase); validate(sampleCount, policy); getQualityLabel(metric, sampleCount) -> QualityLabel
//   ProviderCapabilityRegistry: getEnabledProviders(market, locale); canHandle(provider, market, useCase); supportsFanOut(provider, market); getBestProvider(market, useCase, tier)
//   ConfigBundleService:        resolve(market, locale, segment); get(bundleId); invalidate(market); activate(newId)
//   QualityGateService:         evaluate(auditId) -> writes audits.quality_status
//   ObservabilityService:       emit(event)
//
// If your services take a Drizzle db handle, build one here from TEST_DATABASE_URL and pass it.

// import { drizzle } from 'drizzle-orm/postgres-js';
// import { sql as pg } from './test-db';
// const db = drizzle(pg);

// ── Wire these to the repo ──────────────────────────────────────────────────────
// import { BudgetPolicyService } from '@/lib/platform/budget-policy.service';
// export const makeBudgetPolicyService = () => new BudgetPolicyService(db);

export const makeBudgetPolicyService = () => notWired('BudgetPolicyService');
export const makeSamplingPolicyService = () => notWired('SamplingPolicyService');
export const makeProviderCapabilityRegistry = () => notWired('ProviderCapabilityRegistry');
export const makeConfigBundleService = () => notWired('ConfigBundleService');
export const makeQualityGateService = () => notWired('QualityGateService');

/** Capture-sink Observability double — assert events were emitted without a real telemetry backend. */
export function makeObservabilitySpy() {
  const events: { type: string; payload?: unknown }[] = [];
  return {
    sink: { emit: (e: { type: string; payload?: unknown }) => { events.push(e); } },
    events,
    typesEmitted: () => events.map((e) => e.type),
  };
}

function notWired(name: string): never {
  throw new Error(`${name} factory not wired in _harness/services.ts — point it at the repo export.`);
}
