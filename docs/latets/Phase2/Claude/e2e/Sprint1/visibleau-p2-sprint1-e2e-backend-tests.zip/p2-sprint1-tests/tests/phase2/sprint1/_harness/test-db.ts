// tests/phase2/sprint1/_harness/test-db.ts
//
// E2E test harness for Phase 2 Sprint 1 (Platform Foundation).
// These tests run against a REAL Postgres — they apply the Sprint 1 migration, exercise
// the platform services, and assert real DB effects (constraints, FK ON DELETE, RLS).
//
// ─────────────────────────────────────────────────────────────────────────────
// REQUIRED ENV
//   TEST_DATABASE_URL   a DEDICATED throwaway Postgres (these helpers TRUNCATE freely).
//                       MUST connect as the NON-superuser app role, or RLS is bypassed
//                       and rls-isolation.e2e.test.ts will silently pass for the wrong
//                       reason. (Postgres skips RLS for superusers and table owners with
//                       BYPASSRLS.) Mirror the role your Phase 1 RLS tests use.
//   LLM_MODE=mock       never make real LLM calls in tests (CLAUDE.md §8). The Phase 1
//                       regression test relies on this.
//
// ADAPT-TO-REPO (the only repo-coupling in the harness):
//   1. MIGRATION_GLOB   — path to the Sprint 1 migration produced by the build
//                         (db/migrations/00NN_phase2_sprint1_platform.sql). If your repo
//                         applies migrations through Drizzle's migrator, you can swap
//                         applyMigration() for `migrate(db, { migrationsFolder })`.
//   2. runRepoSeeds()   — wire to your repo's seed entrypoint so seeds.e2e.test.ts tests
//                         the REAL seed files, not a re-implementation.
// ─────────────────────────────────────────────────────────────────────────────

import postgres from 'postgres';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

const url = process.env.TEST_DATABASE_URL;
if (!url) throw new Error('TEST_DATABASE_URL is required for Phase 2 Sprint 1 E2E tests');

// Guard: refuse to run against anything that doesn't look like a throwaway DB.
if (!/test|ci|tmp|scratch/i.test(url)) {
  throw new Error(
    `Refusing to run E2E tests: TEST_DATABASE_URL ("${url}") does not look like a test DB. ` +
    `These tests TRUNCATE tables. Point at a dedicated test database.`,
  );
}

export const sql = postgres(url, { max: 5, onnotice: () => {} });

// Directory holding the Sprint 1 migration, and the filename match. Portable across Node
// versions (no experimental fs.glob). ADAPT via env if your layout differs.
const MIGRATION_DIR = process.env.SPRINT1_MIGRATION_DIR ?? 'db/migrations';
const MIGRATION_MATCH = /sprint1.*\.sql$/i;

/** Apply the Sprint 1 migration. Idempotent by design (MI-01), so safe to call twice. */
export async function applyMigration(): Promise<void> {
  const files = readdirSync(MIGRATION_DIR)
    .filter((f) => MIGRATION_MATCH.test(f))
    .sort();
  if (files.length === 0) {
    throw new Error(
      `No Sprint 1 migration matched ${MIGRATION_MATCH} in ${MIGRATION_DIR}. ` +
      `Set SPRINT1_MIGRATION_DIR, or swap this for Drizzle's migrate(db, { migrationsFolder }).`,
    );
  }
  for (const f of files) {
    const ddl = readFileSync(join(MIGRATION_DIR, f), 'utf8');
    await sql.unsafe(ddl); // multi-statement DDL via the simple query protocol (no bound params)
  }
}

/**
 * Run the repo's REAL Sprint 1 seed files (metric_quality_gates + provider_market_capabilities).
 * ADAPT: invoke your seed entrypoint. Examples:
 *   - import { seedMetricQualityGates } from '../../../../db/seed/metric-quality-gates';
 *     import { seedProviderMarketCapabilities } from '../../../../db/seed/provider-market-capabilities';
 *     await seedMetricQualityGates(); await seedProviderMarketCapabilities();
 *   - or shell out to `pnpm db:seed:phase2-sprint1`.
 * seeds.e2e.test.ts MUST call this (not a hand-rolled insert) so it tests the real seeds.
 */
export async function runRepoSeeds(): Promise<void> {
  throw new Error(
    'runRepoSeeds() is not wired. Point it at your repo seed entrypoint ' +
    '(db/seed/metric-quality-gates.ts + db/seed/provider-market-capabilities.ts).',
  );
}

const SPRINT1_TABLES = [
  'audit_cost_snapshots',
  'config_bundle_cache',
  'market_ai_budget_policies',
  'sampling_policies',
  'metric_quality_gates',
  'prompt_pack_coverage',
  'provider_market_capabilities',
] as const;

/** Truncate Sprint 1 tables + the Phase 1 rows the fixtures create. CASCADE handles FKs. */
export async function truncateAll(): Promise<void> {
  // Sprint 1 tables first (audit_cost_snapshots references audits/orgs/policies).
  await sql.unsafe(`TRUNCATE ${SPRINT1_TABLES.join(', ')} RESTART IDENTITY CASCADE;`);
  // Phase 1 rows created by fixtures. Adjust table names to your schema if they differ.
  await sql.unsafe(`TRUNCATE audits, subscriptions, organizations RESTART IDENTITY CASCADE;`);
}

/**
 * Run `fn` with the RLS org context set, transaction-locally. RLS policies on
 * audit_cost_snapshots read current_setting('app.current_org_id', true)::uuid.
 * Using a transaction + set_config(local=true) pins it to one connection — the only
 * correct way to test RLS through a pooled client.
 */
export async function withOrgContext<T>(
  orgId: string,
  fn: (tx: postgres.TransactionSql) => Promise<T>,
): Promise<T> {
  return sql.begin(async (tx) => {
    await tx`SELECT set_config('app.current_org_id', ${orgId}, true)`;
    return fn(tx);
  });
}

/** Is RLS row-security actually enabled on a table? (relrowsecurity from pg_class.) */
export async function rlsEnabled(table: string): Promise<boolean> {
  const [row] = await sql<{ relrowsecurity: boolean }[]>`
    SELECT relrowsecurity FROM pg_class WHERE relname = ${table}
  `;
  return row?.relrowsecurity ?? false;
}

export async function closeDb(): Promise<void> {
  await sql.end({ timeout: 5 });
}
