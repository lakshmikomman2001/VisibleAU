// tests/phase2/sprint1/budget-policy.service.e2e.test.ts
//
// Covers Sprint 1 §6.2 + §13. NOTE ON THE TIER RULE: the verbatim LLD caller passes the engine
// count INTO the service — `estimate({ ..., engineCount: TIER_ENGINES[tier].length })` — so the
// "read subscriptions.tier, not organizations.tier" decision happens in the CALLER (run-audit.ts),
// not inside estimate(). That behavioural proof therefore lives in phase1-unchanged.regression
// (which drives run-audit). This file tests what the SERVICE itself owns:
//   • estimate() returns a well-formed CostEstimate and scales with engineCount/promptCount.
//   • enforce() hard-stops on over-budget + hard_stop_on_budget.
//   • record() takes the actual cost as totalCostUsd (USD dollars), converts USD→AUD cents
//     (round(usd*100/0.65)), writes one snapshot, and SKIPS org.slug='sample'.

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import { sql, applyMigration, truncateAll, closeDb } from './_harness/test-db';
import {
  insertOrganization, insertSubscription, insertAudit, insertBudgetPolicy,
} from './_harness/fixtures';
import { makeBudgetPolicyService } from './_harness/services';

beforeAll(async () => { await applyMigration(); });
afterAll(async () => { await truncateAll(); await closeDb(); });
beforeEach(async () => { await truncateAll(); });

// A budget policy keyed by (market_code, segment, use_case) — global config, one per tuple.
// estimate() resolves the policy for the audit's market/segment/use_case. ADAPT: if your
// estimate() resolves a different tuple than AU_EN/smb/visibility, seed to match.
async function setupOrgWithPolicy(maxEstimatedCostCents = 100000) {
  const org = await insertOrganization({ slug: `acme-${Math.random().toString(36).slice(2, 6)}` });
  await insertSubscription({ organizationId: org.id, tier: 'growth' });
  await insertBudgetPolicy({ maxEstimatedCostCents }); // AU_EN/smb/visibility
  return org;
}

describe('estimate() — returns a well-formed CostEstimate', () => {
  it('maxAllowedCents reflects the policy ceiling and withinBudget is consistent', async () => {
    const svc = makeBudgetPolicyService();
    const org = await setupOrgWithPolicy(100000);
    const est = await svc.estimate({ brandId: 'b1', organizationId: org.id, promptCount: 50, engineCount: 4 });

    expect(est.estimatedCostCents).toBeGreaterThanOrEqual(0);
    expect(est.maxAllowedCents).toBe(100000);          // from market_ai_budget_policies.max_estimated_cost_cents
    expect(est.withinBudget).toBe(est.estimatedCostCents <= est.maxAllowedCents);
    expect(est.policyId).toBeTruthy();
  });

  it('estimatedCostCents scales up with engineCount (4 engines cost more than 2)', async () => {
    const svc = makeBudgetPolicyService();
    const org = await setupOrgWithPolicy(100000);
    const e2 = await svc.estimate({ brandId: 'b1', organizationId: org.id, promptCount: 50, engineCount: 2 });
    const e4 = await svc.estimate({ brandId: 'b1', organizationId: org.id, promptCount: 50, engineCount: 4 });
    expect(e4.estimatedCostCents).toBeGreaterThan(e2.estimatedCostCents);
  });

  it('withinBudget is FALSE when the estimate exceeds a tight policy ceiling', async () => {
    const svc = makeBudgetPolicyService();
    const org = await setupOrgWithPolicy(1); // 1 cent ceiling — any real estimate exceeds it
    const est = await svc.estimate({ brandId: 'b1', organizationId: org.id, promptCount: 50, engineCount: 4 });
    expect(est.withinBudget).toBe(false);
  });
});

describe('enforce() — hard stop', () => {
  it('returns allowed=false / reason=budget_exceeded when over budget and hard_stop=true', async () => {
    const svc = makeBudgetPolicyService();
    const overEstimate = { estimatedCostCents: 5000, maxAllowedCents: 10, withinBudget: false, policyId: 'p' };
    const result = await svc.enforce(overEstimate, { maxEstimatedCostCents: 10, hardStopOnBudget: true });
    expect(result.allowed).toBe(false);
    expect(result.reason).toBe('budget_exceeded');
    // (The actual 'Budget exceeded' THROW lives in run-audit.ts — see phase1-unchanged.regression.)
  });

  it('allows when within budget', async () => {
    const svc = makeBudgetPolicyService();
    const within = { estimatedCostCents: 5, maxAllowedCents: 500, withinBudget: true, policyId: 'p' };
    const result = await svc.enforce(within, { maxEstimatedCostCents: 500, hardStopOnBudget: true });
    expect(result.allowed).toBe(true);
  });
});

describe('record() — actual is totalCostUsd (USD), converted to AUD cents; skips sample org', () => {
  it('writes one snapshot with USD→AUD cents = round(usd * 100 / 0.65)', async () => {
    const svc = makeBudgetPolicyService();
    const org = await insertOrganization({ slug: 'paying-customer' });
    await insertSubscription({ organizationId: org.id, tier: 'growth' });
    await insertBudgetPolicy();
    const audit = await insertAudit({ organizationId: org.id, totalCostUsd: 1.30, promptsCount: 50, totalCalls: 200 });

    await svc.record(audit.id, 1.30); // 1.30 USD (NOT cents)

    const rows = await sql<{ actual_cost_cents: number; organization_id: string }[]>`
      SELECT actual_cost_cents, organization_id FROM audit_cost_snapshots WHERE audit_id = ${audit.id}`;
    expect(rows).toHaveLength(1);
    expect(rows[0].actual_cost_cents).toBe(Math.round(1.30 * 100 / 0.65)); // = 200
    expect(rows[0].organization_id).toBe(org.id);
  });

  it('does NOT write a snapshot for org.slug = "sample" (D-03/O-03)', async () => {
    const svc = makeBudgetPolicyService();
    const org = await insertOrganization({ slug: 'sample' });
    await insertSubscription({ organizationId: org.id, tier: 'free' });
    await insertBudgetPolicy();
    const audit = await insertAudit({ organizationId: org.id, totalCostUsd: 0.5 });

    await svc.record(audit.id, 0.5); // USD

    const [{ n }] = await sql<{ n: number }[]>`
      SELECT count(*)::int AS n FROM audit_cost_snapshots WHERE audit_id = ${audit.id}`;
    expect(n).toBe(0); // sample org is excluded
  });
});
