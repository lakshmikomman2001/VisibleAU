// tests/phase2/sprint1/config-bundle.service.e2e.test.ts
//
// Covers Sprint 1 §6.1 + §5.1 and the LLD activation prose (4771–4776). The invariant under
// test: AT MOST ONE active bundle per (market_code, locale, segment) — enforced by BOTH the DB
// (config_bundle_one_active partial unique index) AND the service transaction.
//
// activate(newId) contract (LLD 4771–4776): in one transaction, set the target bundle active and
// deactivate every other row for the same market+locale+segment (`... AND id != newId`). The
// version row is inserted first (deploy flow), so activate() must be able to flip an existing
// inactive bundle to active — that is exactly what these tests require.

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import { sql, applyMigration, truncateAll, closeDb } from './_harness/test-db';
import { insertConfigBundle } from './_harness/fixtures';
import { makeConfigBundleService } from './_harness/services';

const TUPLE = { marketCode: 'AU_EN', locale: 'en-AU', segment: 'smb' };

beforeAll(async () => { await applyMigration(); });
afterAll(async () => { await truncateAll(); await closeDb(); });
beforeEach(async () => { await truncateAll(); });

async function activeIdsForTuple(): Promise<string[]> {
  const rows = await sql<{ id: string }[]>`
    SELECT id FROM config_bundle_cache
    WHERE market_code = ${TUPLE.marketCode} AND locale = ${TUPLE.locale}
      AND segment = ${TUPLE.segment} AND is_active = true
  `;
  return rows.map((r) => r.id);
}

describe('config_bundle_one_active — DB-level enforcement', () => {
  it('rejects a second active bundle for the same tuple (partial unique index)', async () => {
    await insertConfigBundle({ ...TUPLE, bundleVersion: 1, isActive: true });
    await expect(
      insertConfigBundle({ ...TUPLE, bundleVersion: 2, isActive: true }),
    ).rejects.toThrow(); // partial unique index violation
  });

  it('allows many INACTIVE bundles for the same tuple', async () => {
    await insertConfigBundle({ ...TUPLE, bundleVersion: 1, isActive: false });
    await insertConfigBundle({ ...TUPLE, bundleVersion: 2, isActive: false });
    expect(await activeIdsForTuple()).toHaveLength(0);
  });
});

describe('ConfigBundleService.activate() — transactional flip', () => {
  it('leaves exactly one active row, and activating another flips the first off', async () => {
    const svc = makeConfigBundleService();
    const v1 = (await insertConfigBundle({ ...TUPLE, bundleVersion: 1, isActive: false })).id;
    const v2 = (await insertConfigBundle({ ...TUPLE, bundleVersion: 2, isActive: false })).id;

    await svc.activate(v1);
    expect(await activeIdsForTuple()).toEqual([v1]);

    await svc.activate(v2); // must deactivate v1 in the same transaction
    expect(await activeIdsForTuple()).toEqual([v2]);
  });
});

describe('ConfigBundleService.resolve() / get() — round-trip', () => {
  it('resolve() returns the single active bundle for the tuple', async () => {
    const svc = makeConfigBundleService();
    await insertConfigBundle({ ...TUPLE, bundleVersion: 1, isActive: false });
    const v2 = (await insertConfigBundle({ ...TUPLE, bundleVersion: 2, isActive: true })).id;
    const resolved = await svc.resolve(TUPLE.marketCode, TUPLE.locale, TUPLE.segment);
    expect((resolved as { id: string }).id).toBe(v2);
  });

  it('the resolved bundle carries a non-empty config_digest (the key config:diff compares on)', async () => {
    // config_digest is NOT NULL in the schema and is a stable hash of resolved_config (§6.1).
    // We assert it round-trips non-empty rather than asserting a specific hash, since the hash
    // algorithm is a service-impl detail. config:diff (config-cli.e2e.test ADAPT) exercises the
    // change-detection semantics end-to-end.
    const svc = makeConfigBundleService();
    const cfg = { prompts: ['a', 'b'], market: 'AU_EN' };
    const id = (await insertConfigBundle({ ...TUPLE, bundleVersion: 1, resolvedConfig: cfg, isActive: true })).id;
    const got = await svc.get(id);
    expect((got as { configDigest?: string }).configDigest ?? (got as { config_digest?: string }).config_digest)
      .toBeTruthy();
  });
});
