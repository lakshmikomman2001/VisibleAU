// tests/phase2/sprint1/config-cli.e2e.test.ts
//
// Covers Sprint 1 §7: the `visibleau config:validate|coverage|diff` CLI that CI runs on every
// config PR. The contract under test is the EXIT CODE — config:validate must exit non-zero when
// a market is misconfigured (so CI fails) and zero when complete.
//
// ADAPT: set CLI_CMD to how your repo invokes the CLI. Default assumes `pnpm visibleau`.

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { applyMigration, truncateAll, closeDb } from './_harness/test-db';
import {
  insertConfigBundle, insertProvider, insertBudgetPolicy, insertSamplingPolicy,
} from './_harness/fixtures';

const exec = promisify(execFile);
const CLI = (process.env.CLI_CMD ?? 'pnpm visibleau').split(' ');

async function runCli(args: string[]): Promise<{ code: number; stdout: string; stderr: string }> {
  try {
    const { stdout, stderr } = await exec(CLI[0], [...CLI.slice(1), ...args], {
      env: { ...process.env, DATABASE_URL: process.env.TEST_DATABASE_URL, LLM_MODE: 'mock' },
    });
    return { code: 0, stdout, stderr };
  } catch (e) {
    const err = e as { code?: number; stdout?: string; stderr?: string };
    return { code: err.code ?? 1, stdout: err.stdout ?? '', stderr: err.stderr ?? '' };
  }
}

beforeAll(async () => { await applyMigration(); });
afterAll(async () => { await truncateAll(); await closeDb(); });
beforeEach(async () => { await truncateAll(); });

// prompt_pack_coverage row helper (inline — small, single-use)
import { sql } from './_harness/test-db';
async function insertCoverage(status: 'complete' | 'partial' | 'missing') {
  await sql`
    INSERT INTO prompt_pack_coverage
      (market_code, locale, segment, use_case, required_template_keys, available_template_keys, coverage_ratio, coverage_status)
    VALUES ('AU_EN','en-AU','smb','visibility', ${sql.json(['a','b'])}, ${sql.json(status === 'complete' ? ['a','b'] : ['a'])},
            ${status === 'complete' ? 1.0 : 0.5}, ${status})`;
}

async function makeCompleteAUMarket() {
  await insertConfigBundle({ bundleVersion: 1, isActive: true });
  await insertProvider({ providerKey: 'openai', modelKey: 'gpt-4o', isEnabled: true, supportsWebRetrieval: true, supportsCitations: true });
  await insertBudgetPolicy();
  await insertSamplingPolicy();
  await insertCoverage('complete');
}

describe('config:validate exit codes (CI contract)', () => {
  it('exits 0 for a fully configured market', async () => {
    await makeCompleteAUMarket();
    const { code } = await runCli(['config:validate', '--market', 'AU_EN', '--locale', 'en-AU']);
    expect(code).toBe(0);
  });

  it('exits non-zero when there is no enabled provider', async () => {
    await insertConfigBundle({ bundleVersion: 1, isActive: true });
    await insertBudgetPolicy();
    await insertSamplingPolicy();
    await insertCoverage('complete');
    // no provider seeded → at least one enabled provider check fails
    const { code } = await runCli(['config:validate', '--market', 'AU_EN', '--locale', 'en-AU']);
    expect(code).not.toBe(0);
  });

  it('exits non-zero when prompt-pack coverage is not complete', async () => {
    await insertConfigBundle({ bundleVersion: 1, isActive: true });
    await insertProvider({ providerKey: 'openai', modelKey: 'gpt-4o', isEnabled: true });
    await insertBudgetPolicy();
    await insertSamplingPolicy();
    await insertCoverage('partial'); // not 'complete'
    const { code } = await runCli(['config:validate', '--market', 'AU_EN', '--locale', 'en-AU']);
    expect(code).not.toBe(0);
  });

  it('exits non-zero when budget or sampling policy rows are missing', async () => {
    await insertConfigBundle({ bundleVersion: 1, isActive: true });
    await insertProvider({ providerKey: 'openai', modelKey: 'gpt-4o', isEnabled: true });
    await insertCoverage('complete');
    // no budget/sampling policy rows
    const { code } = await runCli(['config:validate', '--market', 'AU_EN', '--locale', 'en-AU']);
    expect(code).not.toBe(0);
  });
});
