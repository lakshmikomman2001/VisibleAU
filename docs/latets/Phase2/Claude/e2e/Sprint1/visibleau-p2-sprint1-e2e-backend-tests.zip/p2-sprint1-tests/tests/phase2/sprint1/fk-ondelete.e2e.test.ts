// tests/phase2/sprint1/fk-ondelete.e2e.test.ts
//
// Behavioral proof of the two FK ON DELETE rules (v8.28, §5.1 + §13):
//   audit_cost_snapshots.audit_id        → CASCADE  (snapshot dies with the audit)
//   audit_cost_snapshots.budget_policy_id → SET NULL (snapshot is a historical fact; a
//                                            retired policy must not block the delete)
// Reversing either is a known bug, so these are guard tests.

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import { sql, applyMigration, truncateAll, withOrgContext, closeDb } from './_harness/test-db';
import { insertOrganization, insertAudit, insertBudgetPolicy } from './_harness/fixtures';

let orgId: string;
beforeAll(async () => { await applyMigration(); });
afterAll(async () => { await truncateAll(); await closeDb(); });
beforeEach(async () => { await truncateAll(); orgId = (await insertOrganization()).id; });

async function snapshotCount(): Promise<number> {
  const [{ n }] = await sql<{ n: number }[]>`SELECT count(*)::int AS n FROM audit_cost_snapshots`;
  return n;
}

it('deleting an audit CASCADE-deletes its cost snapshot', async () => {
  const auditId = (await insertAudit({ organizationId: orgId })).id;
  const policyId = (await insertBudgetPolicy()).id;
  await withOrgContext(orgId, (tx) => tx`
    INSERT INTO audit_cost_snapshots (audit_id, organization_id, market_code, locale, budget_policy_id)
    VALUES (${auditId}, ${orgId}, 'AU_EN', 'en-AU', ${policyId})`);
  expect(await snapshotCount()).toBe(1);

  await sql`DELETE FROM audits WHERE id = ${auditId}`;
  expect(await snapshotCount()).toBe(0); // cascaded away
});

it('deleting a budget policy SET NULLs the snapshot link (does not block or cascade)', async () => {
  const auditId = (await insertAudit({ organizationId: orgId })).id;
  const policyId = (await insertBudgetPolicy()).id;
  await withOrgContext(orgId, (tx) => tx`
    INSERT INTO audit_cost_snapshots (audit_id, organization_id, market_code, locale, budget_policy_id)
    VALUES (${auditId}, ${orgId}, 'AU_EN', 'en-AU', ${policyId})`);

  await expect(sql`DELETE FROM market_ai_budget_policies WHERE id = ${policyId}`).resolves.not.toThrow();

  expect(await snapshotCount()).toBe(1); // snapshot survives
  const [{ budget_policy_id }] = await sql<{ budget_policy_id: string | null }[]>`
    SELECT budget_policy_id FROM audit_cost_snapshots WHERE audit_id = ${auditId}`;
  expect(budget_policy_id).toBeNull(); // link nulled, history preserved
});
