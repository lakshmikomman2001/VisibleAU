// tests/phase2/sprint1/phase1-unchanged.regression.e2e.test.ts
//
// Covers Sprint 1 §11 (regression) + §0.4 (design boundary): the platform services WRAP the
// Phase 1 audit path; they must not change its outputs. Specifically:
//   • Phase 1 scoring is byte-identical with the services in the path (LLM_MODE=mock).
//   • Phase 1 still runs runsPerPrompt = 5 — sampling_policies.minimum_repeated_samples (=3)
//     governs Phase 2 trend aggregation ONLY and must NOT override the Phase 1 runner.
//
// This is the most repo-coupled file: it drives the real Phase 1 runner. Wire the two ADAPT
// points and remove `.skip`. Everything asserted is behavioural, not structural.

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { applyMigration, closeDb } from './_harness/test-db';

// ADAPT 1: import the Phase 1 audit entrypoints.
// import { runAudit } from '@/lib/audit/runner';
// import { refreshAudit } from '@/lib/audit/refresh-audit';

// ADAPT 2: a way to read back a completed audit's per-dimension scores.
// import { getAuditScores } from '@/lib/audit/...';

beforeAll(async () => {
  process.env.LLM_MODE = 'mock'; // never a real LLM call in tests
  await applyMigration();        // platform tables present and wired
});
afterAll(async () => { await closeDb(); });

describe.skip('Phase 1 unchanged with platform services in the path — wire ADAPT 1/2 to enable', () => {
  it('produces identical scores to the pre-Sprint-1 baseline for the same mock input', async () => {
    // 1. Run a deterministic mock audit through the real Phase 1 path (services now wired in).
    // const result = await runAudit({ brandId: FIXTURE_BRAND, /* deterministic mock seed */ });
    // await refreshAudit(result.auditId);
    // const scores = await getAuditScores(result.auditId);
    //
    // 2. Compare against the committed Phase 1 baseline (snapshot the known-good scores once,
    //    BEFORE wiring Sprint 1, and assert equality after).
    // expect(scores).toEqual(PHASE1_BASELINE_SCORES);
    expect(true).toBe(true); // placeholder until ADAPT points are wired
  });

  it('uses runsPerPrompt = 5 (sampling_policies.minimum_repeated_samples=3 does NOT override it)', async () => {
    // Seed a sampling_policies row with minimum_repeated_samples=3 for the audit's market, then
    // assert the Phase 1 runner still issued 5 runs per prompt (e.g. by counting mock LLM calls
    // or asserting the runner's configured runsPerPrompt).
    // const callCount = mockLlm.callsFor(promptId);
    // expect(callCount).toBe(5);
    expect(true).toBe(true);
  });

  it('budget hard-stop: run-audit throws "Budget exceeded" when estimate exceeds a hard-stop policy', async () => {
    // Seed a market_ai_budget_policies row with a tiny max_estimated_cost_cents + hard_stop_on_budget=true,
    // then expect runAudit() to throw before issuing LLM calls (the enforce() result becomes a throw here).
    // await expect(runAudit({ brandId: OVER_BUDGET_BRAND })).rejects.toThrow(/budget exceeded/i);
    expect(true).toBe(true);
  });

  it('engine count is sized from subscriptions.tier, NOT organizations.tier (the §0.4 rule)', async () => {
    // This is the correct home for the tier-source-of-truth proof: run-audit.ts resolves the tier
    // and passes engineCount=TIER_ENGINES[tier].length into BudgetPolicyService.estimate() (verbatim
    // LLD caller). Set the two adversarially and assert the run uses the SUBSCRIPTION tier.
    //
    // const org = await insertOrganization({ slug: 'acme', tier: 'free' });   // legacy column says free
    // await insertSubscription({ organizationId: org.id, tier: 'growth' });    // truth says growth (4 engines)
    // const result = await runAudit({ brandId, organizationId: org.id });
    // const snap = await getCostSnapshot(result.auditId);
    // expect mock LLM engines used === TIER_ENGINES['growth'].length (4), not TIER_ENGINES['free'].length (2).
    // i.e. organizations.tier='free' must NOT shrink the run to 2 engines.
    expect(true).toBe(true);
  });
});
