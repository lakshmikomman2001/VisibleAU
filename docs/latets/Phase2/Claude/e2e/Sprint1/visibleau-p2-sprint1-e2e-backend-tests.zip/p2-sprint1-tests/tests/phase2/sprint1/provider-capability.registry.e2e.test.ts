// tests/phase2/sprint1/provider-capability.registry.e2e.test.ts
//
// Covers Sprint 1 §6.4: the registry that gates every later Phase 2 provider lookup.
// The headline test is the SEED DEPENDENCY — getEnabledProviders() returns EMPTY when no
// rows are seeded, which is exactly the silent-failure mode the mandatory seed prevents (O-02).

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import { applyMigration, truncateAll, closeDb } from './_harness/test-db';
import { insertProvider } from './_harness/fixtures';
import { makeProviderCapabilityRegistry } from './_harness/services';

beforeAll(async () => { await applyMigration(); });
afterAll(async () => { await truncateAll(); await closeDb(); });
beforeEach(async () => { await truncateAll(); });

// The canonical 4-provider AU_EN matrix (LLD 4908–4916), inserted explicitly per test for control.
async function seedFourProviders() {
  await insertProvider({ providerKey: 'openai', modelKey: 'gpt-4o', supportsWebRetrieval: true, supportsCitations: true, supportsLocationContext: true, supportsQueryFanOut: true, maxFanOutSubQueries: 12, isEnabled: true });
  await insertProvider({ providerKey: 'anthropic', modelKey: 'claude-3-5-sonnet', supportsWebRetrieval: true, supportsCitations: false, supportsLocationContext: true, supportsQueryFanOut: true, maxFanOutSubQueries: 10, isEnabled: true });
  await insertProvider({ providerKey: 'google', modelKey: 'gemini-1.5-pro', supportsWebRetrieval: true, supportsCitations: true, supportsLocationContext: true, supportsQueryFanOut: true, maxFanOutSubQueries: 12, isEnabled: true });
  await insertProvider({ providerKey: 'perplexity', modelKey: 'pplx-70b-online', supportsWebRetrieval: true, supportsCitations: true, supportsLocationContext: true, supportsQueryFanOut: false, maxFanOutSubQueries: 8, isEnabled: true });
}

describe('getEnabledProviders() — seed dependency', () => {
  it('returns EMPTY when no providers are seeded (the O-02 silent-failure guard)', async () => {
    const reg = makeProviderCapabilityRegistry();
    const providers = await reg.getEnabledProviders('AU_EN', 'en-AU');
    expect(providers).toHaveLength(0);
  });

  it('returns the 4 providers once seeded', async () => {
    const reg = makeProviderCapabilityRegistry();
    await seedFourProviders();
    const providers = await reg.getEnabledProviders('AU_EN', 'en-AU');
    expect(providers).toHaveLength(4);
  });

  it('excludes providers with is_enabled=false', async () => {
    const reg = makeProviderCapabilityRegistry();
    await seedFourProviders();
    await insertProvider({ providerKey: 'disabled-co', modelKey: 'x', isEnabled: false });
    const keys = (await reg.getEnabledProviders('AU_EN', 'en-AU')).map((p) => (p as { providerKey: string }).providerKey);
    expect(keys).not.toContain('disabled-co');
    expect(keys).toHaveLength(4);
  });
});

describe('capability lookups reflect the matrix', () => {
  it('supportsFanOut is FALSE for perplexity, TRUE for openai', async () => {
    const reg = makeProviderCapabilityRegistry();
    await seedFourProviders();
    expect(await reg.supportsFanOut('perplexity', 'AU_EN')).toBe(false);
    expect(await reg.supportsFanOut('openai', 'AU_EN')).toBe(true);
  });

  it('canHandle respects market + use case', async () => {
    const reg = makeProviderCapabilityRegistry();
    await seedFourProviders();
    expect(await reg.canHandle('openai', 'AU_EN', 'visibility')).toBe(true);
    expect(await reg.canHandle('openai', 'NZ_EN', 'visibility')).toBe(false); // not seeded for NZ_EN
  });
});

describe('getBestProvider() — tier-aware', () => {
  it('a Free-tier request only returns providers within TIER_ENGINES["free"]', async () => {
    const reg = makeProviderCapabilityRegistry();
    await seedFourProviders();
    const best = await reg.getBestProvider('AU_EN', 'visibility', 'free');
    // Free tier is a 2-engine allowlist; the chosen provider must be one of the Free engines.
    // ADAPT: import TIER_ENGINES and assert membership precisely.
    // import { TIER_ENGINES } from '@/lib/llm/tier-engines';
    // expect(TIER_ENGINES['free']).toContain((best as { providerKey: string }).providerKey);
    expect(best).toBeTruthy();
  });
});
