// tests/phase2/sprint1/quality-gate.service.e2e.test.ts
//
// Covers Sprint 1 §6.6 + §5.2: QualityGateService.evaluate(auditId) writes audits.quality_status.
//   'sufficient'   = every dimension meets metric_quality_gates.minimum_samples
//   'insufficient' = critical dimensions below threshold
//   'partial'      = some meet, some below
//   'pending'      = default at row creation
//
// SKIPPED until seedAuditDimensionSamples() is wired (see _harness/fixtures.ts): the LLD does
// not pin down WHICH source evaluate() reads per-dimension sample counts from. Point the helper
// at that source (audit_scores rows / a sample_count column / etc.), then remove `.skip`.

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import { sql, applyMigration, truncateAll, closeDb } from './_harness/test-db';
import { insertOrganization, insertAudit, insertMetricQualityGate, seedAuditDimensionSamples } from './_harness/fixtures';
import { makeQualityGateService } from './_harness/services';

beforeAll(async () => { await applyMigration(); });
afterAll(async () => { await truncateAll(); await closeDb(); });
beforeEach(async () => { await truncateAll(); });

// AU_EN gates (subset) used across these cases.
async function seedGates() {
  await insertMetricQualityGate({ metricKey: 'frequency', minimumSamples: 10 });
  await insertMetricQualityGate({ metricKey: 'sentiment', minimumSamples: 10 });
  await insertMetricQualityGate({ metricKey: 'accuracy', minimumSamples: 5 });
}

async function statusOf(auditId: string): Promise<string> {
  const [{ quality_status }] = await sql<{ quality_status: string }[]>`
    SELECT quality_status FROM audits WHERE id = ${auditId}`;
  return quality_status;
}

describe.skip('QualityGateService.evaluate() — wire seedAuditDimensionSamples() to enable', () => {
  it('a freshly-created audit starts pending', async () => {
    const org = await insertOrganization();
    const audit = await insertAudit({ organizationId: org.id });
    expect(await statusOf(audit.id)).toBe('pending');
  });

  it('transitions pending → sufficient when every dimension meets its minimum', async () => {
    const svc = makeQualityGateService();
    await seedGates();
    const org = await insertOrganization();
    const audit = await insertAudit({ organizationId: org.id });
    await seedAuditDimensionSamples(audit.id, { frequency: 12, sentiment: 12, accuracy: 6 });

    await svc.evaluate(audit.id);
    expect(await statusOf(audit.id)).toBe('sufficient');
  });

  it('→ insufficient when critical dimensions are below threshold', async () => {
    const svc = makeQualityGateService();
    await seedGates();
    const org = await insertOrganization();
    const audit = await insertAudit({ organizationId: org.id });
    await seedAuditDimensionSamples(audit.id, { frequency: 2, sentiment: 1, accuracy: 1 });

    await svc.evaluate(audit.id);
    expect(await statusOf(audit.id)).toBe('insufficient');
  });

  it('→ partial when some dimensions meet and some fall short', async () => {
    const svc = makeQualityGateService();
    await seedGates();
    const org = await insertOrganization();
    const audit = await insertAudit({ organizationId: org.id });
    await seedAuditDimensionSamples(audit.id, { frequency: 12, sentiment: 12, accuracy: 1 }); // accuracy short

    await svc.evaluate(audit.id);
    expect(await statusOf(audit.id)).toBe('partial');
  });

  it('reads gates for the audit market_code only (no cross-market bleed)', async () => {
    const svc = makeQualityGateService();
    await seedGates(); // AU_EN
    await insertMetricQualityGate({ metricKey: 'frequency', marketCode: 'NZ_EN', minimumSamples: 999 });
    const org = await insertOrganization({ region: 'AU' });
    const audit = await insertAudit({ organizationId: org.id });
    await seedAuditDimensionSamples(audit.id, { frequency: 12, sentiment: 12, accuracy: 6 });

    await svc.evaluate(audit.id);
    expect(await statusOf(audit.id)).toBe('sufficient'); // NZ_EN 999 threshold must not apply
  });
});
