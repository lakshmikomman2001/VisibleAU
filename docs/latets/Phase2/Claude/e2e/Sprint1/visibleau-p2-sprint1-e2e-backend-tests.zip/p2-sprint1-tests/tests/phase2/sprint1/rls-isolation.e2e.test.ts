// tests/phase2/sprint1/rls-isolation.e2e.test.ts
//
// Covers Sprint 1 §5.4: audit_cost_snapshots is the ONE tenant table this sprint, RLS-enabled
// with USING + WITH CHECK on organization_id. Proves a tenant can neither read nor write
// another tenant's cost snapshots.
//
// PRECONDITION: TEST_DATABASE_URL must connect as the NON-superuser app role (see test-db.ts).
// If RLS appears not to filter, you are almost certainly connected as a superuser/owner that
// bypasses RLS — fix the role before trusting this file.

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import { sql, applyMigration, truncateAll, withOrgContext, rlsEnabled, closeDb } from './_harness/test-db';
import { insertOrganization, insertAudit } from './_harness/fixtures';

let orgA: string, orgB: string, auditA: string, auditB: string;

beforeAll(async () => {
  await applyMigration();
  // Sanity: if this is false the rest of the file is meaningless.
  expect(await rlsEnabled('audit_cost_snapshots')).toBe(true);
});
afterAll(async () => { await truncateAll(); await closeDb(); });

beforeEach(async () => {
  await truncateAll();
  orgA = (await insertOrganization({ slug: 'org-a' })).id;
  orgB = (await insertOrganization({ slug: 'org-b' })).id;
  auditA = (await insertAudit({ organizationId: orgA })).id;
  auditB = (await insertAudit({ organizationId: orgB })).id;

  // Seed one snapshot per org WITHOUT RLS context is not possible under the app role;
  // insert each within its own org context (WITH CHECK allows own-org writes).
  await withOrgContext(orgA, (tx) => tx`
    INSERT INTO audit_cost_snapshots (audit_id, organization_id, market_code, locale, actual_cost_cents)
    VALUES (${auditA}, ${orgA}, 'AU_EN', 'en-AU', 100)`);
  await withOrgContext(orgB, (tx) => tx`
    INSERT INTO audit_cost_snapshots (audit_id, organization_id, market_code, locale, actual_cost_cents)
    VALUES (${auditB}, ${orgB}, 'AU_EN', 'en-AU', 200)`);
});

describe('audit_cost_snapshots RLS — read isolation (USING)', () => {
  it('org A sees only its own snapshot', async () => {
    const rows = await withOrgContext(orgA, (tx) =>
      tx<{ organization_id: string }[]>`SELECT organization_id FROM audit_cost_snapshots`);
    expect(rows).toHaveLength(1);
    expect(rows[0].organization_id).toBe(orgA);
  });

  it('org B cannot see org A rows', async () => {
    const rows = await withOrgContext(orgB, (tx) =>
      tx<{ organization_id: string }[]>`SELECT organization_id FROM audit_cost_snapshots WHERE organization_id = ${orgA}`);
    expect(rows).toHaveLength(0);
  });
});

describe('audit_cost_snapshots RLS — write isolation (WITH CHECK)', () => {
  it('org A cannot insert a row for org B', async () => {
    await expect(
      withOrgContext(orgA, (tx) => tx`
        INSERT INTO audit_cost_snapshots (audit_id, organization_id, market_code, locale, actual_cost_cents)
        VALUES (${auditB}, ${orgB}, 'AU_EN', 'en-AU', 999)`),
    ).rejects.toThrow(); // WITH CHECK violation
  });

  it('org A CAN insert its own row', async () => {
    const auditA2 = (await insertAudit({ organizationId: orgA })).id;
    await expect(
      withOrgContext(orgA, (tx) => tx`
        INSERT INTO audit_cost_snapshots (audit_id, organization_id, market_code, locale, actual_cost_cents)
        VALUES (${auditA2}, ${orgA}, 'AU_EN', 'en-AU', 150)`),
    ).resolves.not.toThrow();
  });
});
