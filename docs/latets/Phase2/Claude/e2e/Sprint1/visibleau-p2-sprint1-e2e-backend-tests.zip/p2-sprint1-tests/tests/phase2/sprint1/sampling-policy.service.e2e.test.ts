// tests/phase2/sprint1/sampling-policy.service.e2e.test.ts
//
// Covers Sprint 1 §6.3: getQualityLabel + validate. The boundary that matters most is
// 'Insufficient data' below metric_quality_gates.minimum_samples (drives confidence display).
// Label thresholds above that derive from confidence_display_threshold + minimum_samples; the
// exact Confirmed/Likely/Hypothesis cutoffs are an LLD detail — the precise boundary asserted
// here is the Insufficient one. Tune the upper-tier expectations to the LLD §6.3 thresholds.

import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import { applyMigration, truncateAll, closeDb } from './_harness/test-db';
import { insertMetricQualityGate, insertSamplingPolicy } from './_harness/fixtures';
import { makeSamplingPolicyService } from './_harness/services';

beforeAll(async () => { await applyMigration(); });
afterAll(async () => { await truncateAll(); await closeDb(); });
beforeEach(async () => { await truncateAll(); });

describe('getQualityLabel()', () => {
  it("returns 'Insufficient data' below the metric's minimum_samples", async () => {
    const svc = makeSamplingPolicyService();
    await insertMetricQualityGate({ metricKey: 'frequency', minimumSamples: 10 });
    await insertSamplingPolicy({ confidenceDisplayThreshold: 0.6 });

    const label = await svc.getQualityLabel('frequency', /* sampleCount */ 9); // below 10
    expect((label as { label: string }).label).toBe('Insufficient data');
  });

  it('returns a graded label at/above minimum_samples (not Insufficient)', async () => {
    const svc = makeSamplingPolicyService();
    await insertMetricQualityGate({ metricKey: 'frequency', minimumSamples: 10 });
    await insertSamplingPolicy({ confidenceDisplayThreshold: 0.6 });

    const label = await svc.getQualityLabel('frequency', 25);
    expect(['Confirmed', 'Likely', 'Hypothesis']).toContain((label as { label: string }).label);
  });

  it('crosses exactly at the threshold (9 → Insufficient, 10 → graded)', async () => {
    const svc = makeSamplingPolicyService();
    await insertMetricQualityGate({ metricKey: 'accuracy', minimumSamples: 5 });
    await insertSamplingPolicy();
    expect((await svc.getQualityLabel('accuracy', 4) as { label: string }).label).toBe('Insufficient data');
    expect((await svc.getQualityLabel('accuracy', 5) as { label: string }).label).not.toBe('Insufficient data');
  });
});

describe('validate()', () => {
  it('flags a sample count below minimum_prompt_count as invalid', async () => {
    const svc = makeSamplingPolicyService();
    const policy = await insertSamplingPolicy({ minimumPromptCount: 10, recommendedPromptCount: 50 });
    const res = await svc.validate(8, policy);
    expect((res as { valid: boolean }).valid).toBe(false);
  });

  it('accepts a sample count at/above minimum_prompt_count', async () => {
    const svc = makeSamplingPolicyService();
    const policy = await insertSamplingPolicy({ minimumPromptCount: 10 });
    const res = await svc.validate(10, policy);
    expect((res as { valid: boolean }).valid).toBe(true);
  });
});
