// tests/phase2/sprint1/schema-and-migration.e2e.test.ts
//
// Covers Sprint 1 §5 (schema), §12 verification greps (as live assertions), and the MI-01
// idempotency requirement. DB-level only — fully runnable once TEST_DATABASE_URL is set.

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { sql, applyMigration, truncateAll, rlsEnabled, closeDb } from './_harness/test-db';

const SPRINT1_TABLES = [
  'config_bundle_cache', 'market_ai_budget_policies', 'sampling_policies',
  'metric_quality_gates', 'prompt_pack_coverage', 'provider_market_capabilities',
  'audit_cost_snapshots',
];
const CONFIG_TABLES = SPRINT1_TABLES.filter((t) => t !== 'audit_cost_snapshots');

beforeAll(async () => { await applyMigration(); });
afterAll(async () => { await truncateAll(); await closeDb(); });

async function columns(table: string) {
  return sql<{ column_name: string; data_type: string; column_default: string | null; is_nullable: string }[]>`
    SELECT column_name, data_type, column_default, is_nullable
    FROM information_schema.columns WHERE table_name = ${table}
  `;
}

describe('Sprint 1 schema — tables exist', () => {
  it('creates all 7 platform tables (§12: count = 7)', async () => {
    const rows = await sql<{ table_name: string }[]>`
      SELECT table_name FROM information_schema.tables
      WHERE table_schema = 'public' AND table_name = ANY(${SPRINT1_TABLES})
    `;
    expect(rows.map((r) => r.table_name).sort()).toEqual([...SPRINT1_TABLES].sort());
  });
});

describe('Sprint 1 schema — critical column defaults (the LLD traps)', () => {
  it('market_ai_budget_policies: max_models_per_audit default 4, max_repeated_samples default 5', async () => {
    const cols = await columns('market_ai_budget_policies');
    const byName = Object.fromEntries(cols.map((c) => [c.column_name, c]));
    expect(byName['max_models_per_audit'].column_default).toMatch(/\b4\b/);   // ceiling, NOT Free=2
    expect(byName['max_repeated_samples'].column_default).toMatch(/\b5\b/);    // Wilson CI needs ≥5
    expect(byName['hard_stop_on_budget'].column_default).toMatch(/true/i);
  });

  it('provider_market_capabilities: all four capability booleans default false', async () => {
    const cols = await columns('provider_market_capabilities');
    const byName = Object.fromEntries(cols.map((c) => [c.column_name, c]));
    for (const c of ['supports_web_retrieval', 'supports_citations', 'supports_location_context', 'supports_query_fan_out']) {
      expect(byName[c].column_default).toMatch(/false/i);
    }
    expect(byName['is_enabled'].column_default).toMatch(/false/i); // all providers start disabled
  });

  it('config_bundle_cache: is_active boolean default true, resolved_config jsonb', async () => {
    const cols = await columns('config_bundle_cache');
    const byName = Object.fromEntries(cols.map((c) => [c.column_name, c]));
    expect(byName['is_active'].column_default).toMatch(/true/i);
    expect(byName['resolved_config'].data_type).toBe('jsonb');
  });
});

describe('Sprint 1 schema — uniques & the partial active-bundle index', () => {
  it('config_bundle_one_active partial unique index exists (§12: ≥1)', async () => {
    const [row] = await sql<{ indexdef: string }[]>`
      SELECT indexdef FROM pg_indexes WHERE indexname = 'config_bundle_one_active'
    `;
    expect(row).toBeTruthy();
    expect(row.indexdef).toMatch(/WHERE.*is_active/i); // partial, only over active rows
  });

  it('config_bundle_cache has UNIQUE(market_code, locale, segment, bundle_version)', async () => {
    const rows = await sql<{ conname: string }[]>`
      SELECT conname FROM pg_constraint
      WHERE conrelid = 'config_bundle_cache'::regclass AND contype = 'u'
    `;
    expect(rows.length).toBeGreaterThanOrEqual(1);
  });
});

describe('Sprint 1 schema — audits ALTER (§5.2)', () => {
  it('adds all 4 nullable columns with quality_status default pending', async () => {
    const cols = await columns('audits');
    const byName = Object.fromEntries(cols.map((c) => [c.column_name, c]));
    for (const c of ['config_bundle_id', 'config_digest', 'estimated_cost_cents', 'quality_status']) {
      expect(byName[c], `audits.${c} missing`).toBeTruthy();
    }
    expect(byName['quality_status'].column_default).toMatch(/pending/);
    expect(byName['config_bundle_id'].is_nullable).toBe('YES'); // safe migration: nullable
  });
});

describe('Sprint 1 schema — FK ON DELETE rules (§12: the two rules)', () => {
  // confdeltype: 'c' = CASCADE, 'n' = SET NULL, 'a' = NO ACTION
  async function fkRule(constrainedTable: string, column: string) {
    const [row] = await sql<{ confdeltype: string }[]>`
      SELECT c.confdeltype
      FROM pg_constraint c
      JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = ANY(c.conkey)
      WHERE c.conrelid = ${constrainedTable}::regclass
        AND c.contype = 'f'
        AND a.attname = ${column}
    `;
    return row?.confdeltype;
  }

  it('audit_cost_snapshots.audit_id is ON DELETE CASCADE', async () => {
    expect(await fkRule('audit_cost_snapshots', 'audit_id')).toBe('c');
  });
  it('audit_cost_snapshots.budget_policy_id is ON DELETE SET NULL', async () => {
    expect(await fkRule('audit_cost_snapshots', 'budget_policy_id')).toBe('n');
  });
});

describe('Sprint 1 schema — RLS posture (§5.4)', () => {
  it('audit_cost_snapshots has RLS ENABLED (tenant data)', async () => {
    expect(await rlsEnabled('audit_cost_snapshots')).toBe(true);
  });
  it('the 6 config tables have RLS DISABLED (global seed config)', async () => {
    for (const t of CONFIG_TABLES) {
      expect(await rlsEnabled(t), `${t} should have RLS disabled`).toBe(false);
    }
  });
});

describe('Sprint 1 migration — MI-01 idempotency', () => {
  it('re-running the whole migration does not throw', async () => {
    // Every CREATE is IF NOT EXISTS and the policy is DROP-guarded, so a second apply is a no-op.
    await expect(applyMigration()).resolves.not.toThrow();
  });
});
