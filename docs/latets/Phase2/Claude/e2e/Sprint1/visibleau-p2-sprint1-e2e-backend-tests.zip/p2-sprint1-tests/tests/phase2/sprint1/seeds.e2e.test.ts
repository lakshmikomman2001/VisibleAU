// tests/phase2/sprint1/seeds.e2e.test.ts
//
// Covers Sprint 1 §5.5 (mandatory seeds) + §12 (the anthropic boolean trap).
// Calls the REAL repo seeds via runRepoSeeds() — wire that in _harness/test-db.ts first.
// The two seeds are load-bearing: without them quality_status stays 'pending' forever and
// every Phase 2 provider lookup returns empty (O-02).

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { sql, applyMigration, runRepoSeeds, truncateAll, closeDb } from './_harness/test-db';

beforeAll(async () => { await applyMigration(); await runRepoSeeds(); });
afterAll(async () => { await truncateAll(); await closeDb(); });

describe('metric_quality_gates seed (7 AU_EN rows, exact thresholds — LLD 4851–4861)', () => {
  const EXPECTED: Record<string, { min: number; providers: number }> = {
    frequency: { min: 10, providers: 2 },
    sentiment: { min: 10, providers: 2 },
    accuracy: { min: 5, providers: 2 },
    position: { min: 10, providers: 2 },
    context: { min: 10, providers: 2 },
    composite: { min: 3, providers: 2 },
    citation_source: { min: 5, providers: 2 },
  };

  it('seeds exactly the 7 expected metric keys for AU_EN', async () => {
    const rows = await sql<{ metric_key: string }[]>`
      SELECT metric_key FROM metric_quality_gates WHERE market_code = 'AU_EN'
    `;
    expect(rows.map((r) => r.metric_key).sort()).toEqual(Object.keys(EXPECTED).sort());
  });

  it('each gate has the exact minimum_samples / minimum_provider_count', async () => {
    const rows = await sql<{ metric_key: string; minimum_samples: number; minimum_provider_count: number }[]>`
      SELECT metric_key, minimum_samples, minimum_provider_count
      FROM metric_quality_gates WHERE market_code = 'AU_EN'
    `;
    for (const r of rows) {
      expect(r.minimum_samples, `${r.metric_key}.minimum_samples`).toBe(EXPECTED[r.metric_key].min);
      expect(r.minimum_provider_count, `${r.metric_key}.minimum_provider_count`).toBe(EXPECTED[r.metric_key].providers);
    }
  });
});

describe('provider_market_capabilities seed (4 AU_EN/en-AU providers — LLD 4908–4916)', () => {
  type Row = {
    provider_key: string; model_key: string; supports_web_retrieval: boolean;
    supports_citations: boolean; supports_location_context: boolean;
    supports_query_fan_out: boolean; max_fan_out_sub_queries: number; is_enabled: boolean;
  };
  async function provider(key: string): Promise<Row> {
    const [row] = await sql<Row[]>`
      SELECT * FROM provider_market_capabilities
      WHERE provider_key = ${key} AND market_code = 'AU_EN' AND locale = 'en-AU'
    `;
    return row;
  }

  it('seeds 4 providers, all enabled at seed time', async () => {
    const rows = await sql<{ provider_key: string; is_enabled: boolean }[]>`
      SELECT provider_key, is_enabled FROM provider_market_capabilities
      WHERE market_code = 'AU_EN' AND locale = 'en-AU'
    `;
    expect(rows.length).toBe(4);
    expect(rows.every((r) => r.is_enabled === true)).toBe(true);
  });

  it('openai/gpt-4o: web+citations+location+fan_out all true, max_fan_out 12', async () => {
    const r = await provider('openai');
    expect([r.supports_web_retrieval, r.supports_citations, r.supports_location_context, r.supports_query_fan_out])
      .toEqual([true, true, true, true]);
    expect(r.max_fan_out_sub_queries).toBe(12);
  });

  it('TRAP: anthropic/claude-3-5-sonnet has supports_citations = FALSE, max_fan_out 10', async () => {
    const r = await provider('anthropic');
    expect(r.supports_citations).toBe(false);          // the one boolean trap (§12)
    expect(r.supports_web_retrieval).toBe(true);
    expect(r.supports_location_context).toBe(true);
    expect(r.supports_query_fan_out).toBe(true);
    expect(r.max_fan_out_sub_queries).toBe(10);
  });

  it('google/gemini-1.5-pro: all four true, max_fan_out 12', async () => {
    const r = await provider('google');
    expect([r.supports_web_retrieval, r.supports_citations, r.supports_location_context, r.supports_query_fan_out])
      .toEqual([true, true, true, true]);
    expect(r.max_fan_out_sub_queries).toBe(12);
  });

  it('TRAP: perplexity/pplx-70b-online has supports_query_fan_out = FALSE, max_fan_out 8', async () => {
    const r = await provider('perplexity');
    expect(r.supports_query_fan_out).toBe(false);
    expect(r.supports_citations).toBe(true);
    expect(r.max_fan_out_sub_queries).toBe(8);
  });
});

describe('seeds are idempotent (ON CONFLICT DO NOTHING)', () => {
  it('re-running seeds does not duplicate rows', async () => {
    await runRepoSeeds(); // second run
    const [{ gates }] = await sql<{ gates: number }[]>`SELECT count(*)::int AS gates FROM metric_quality_gates WHERE market_code='AU_EN'`;
    const [{ provs }] = await sql<{ provs: number }[]>`SELECT count(*)::int AS provs FROM provider_market_capabilities WHERE market_code='AU_EN'`;
    expect(gates).toBe(7);
    expect(provs).toBe(4);
  });
});
