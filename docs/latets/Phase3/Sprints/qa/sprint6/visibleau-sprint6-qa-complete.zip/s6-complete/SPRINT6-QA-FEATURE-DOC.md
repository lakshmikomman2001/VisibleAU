# VisibleAU Sprint 6 — QA Feature Document for Claude Code

**Sprint:** 6 — Action Center  
**For:** Claude Code automated end-to-end validation  
**Method:** Feature-specific shell scripts (`.sh` / `.bat`) seed real data into the database, run the tests, then hard-delete all test data on exit — even if the test fails or is interrupted.

---

## Directory layout

Place the `s6-qa-scripts/` folder at the **project root** (same level as `package.json`):

```
s6-qa-scripts/
├── shared/
│   └── seed.ts                              ← CLI seed/teardown (all scripts call this)
├── unix/
│   ├── s6-f01-sidebar.sh
│   ├── s6-f02-inngest-generation.sh         ← needs Inngest server + 35s wait
│   ├── s6-f03-f04-action-center-cards.sh
│   ├── s6-f05-f06-evidence-detail.sh
│   ├── s6-f07-f08-mark-done-dismiss.sh
│   ├── s6-f09-f10-tier-gate.sh
│   ├── s6-f11-filters.sh
│   ├── s6-f12-f13-f14-security-antipattern.sh
│   ├── s6-f15-f16-schema-seed.sh
│   └── s6-run-all.sh
└── windows/
    ├── S6-F01-SIDEBAR.bat
    ├── S6-F02-INNGEST-GENERATION.bat
    ├── S6-F07-F08-MARK-DONE-DISMISS.bat
    └── S6-RUN-ALL.bat
```

---

## One-time setup

### 1. Environment file — `.env.test.local`

Create at the project root. **Use a test Supabase project, never production.**

```bash
# Application
E2E_APP_URL=http://localhost:3000

# Database — TEST project (service-role via DIRECT_URL bypasses RLS)
DATABASE_URL=postgresql://postgres.[ref]:[pass]@aws-0-ap-southeast-2.pooler.supabase.com:6543/postgres
DIRECT_URL=postgresql://postgres.[ref]:[pass]@aws-0-ap-southeast-2.pooler.supabase.com:5432/postgres

# Clerk — test-mode keys only
CLERK_SECRET_KEY=sk_test_...
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...

# User 1 — Org 1 — Starter tier (full Action Center access)
E2E_TEST_USER_1_EMAIL=e2e-s6-user-1@visibleau.test
E2E_TEST_USER_1_PASSWORD=S6TestUser1!
E2E_TEST_USER_1_CLERK_ID=user_...
E2E_TEST_ORG_1_CLERK_ID=org_...
E2E_TEST_USER_1_SESSION_ID=sess_...    # obtain from Clerk test session

# User 2 — Org 2 — Free tier (tier gate + cross-org tests)
E2E_TEST_USER_2_EMAIL=e2e-s6-user-2@visibleau.test
E2E_TEST_USER_2_PASSWORD=S6TestUser2!
E2E_TEST_USER_2_CLERK_ID=user_...
E2E_TEST_ORG_2_CLERK_ID=org_...
E2E_TEST_USER_2_SESSION_ID=sess_...
```

### 2. Database prerequisites (run once)

```bash
# Apply Sprint 6 migrations (creates action_items + recommendation_research)
pnpm drizzle-kit generate && pnpm drizzle-kit migrate

# Apply RLS if not in migration file (DH3 fix — critical)
psql "$DIRECT_URL" << 'SQL'
  ALTER TABLE action_items ENABLE ROW LEVEL SECURITY;
  CREATE POLICY "org_isolation" ON action_items
    USING (organization_id = current_setting('app.current_organization_id')::uuid);
  ALTER TABLE recommendation_research DISABLE ROW LEVEL SECURITY;
SQL

# Seed research citations (Sprint 6 DG5 fix — 11 universal keys)
pnpm seed

# Verify seed
psql "$DATABASE_URL" -c \
  "SELECT recommendation_key, COUNT(*) FROM recommendation_research GROUP BY recommendation_key ORDER BY 1;"
# Must return ≥11 rows — one per universal action type key
```

### 3. Make Unix scripts executable

```bash
chmod +x s6-qa-scripts/unix/*.sh
```

### 4. Install test dependencies

```bash
pnpm add -D @playwright/test @clerk/testing playwright
pnpm add -D vitest vite-tsconfig-paths tsx
pnpm exec playwright install --with-deps chromium
```

---

## How every script works

```
1. Load .env.test.local
2. Check prerequisites (app health endpoint, Inngest if needed)
3. Seed test data directly into DB via service-role Drizzle (bypasses RLS)
   — All records use the prefix "[S6-QA]" for identification
4. Export seed IDs as env vars for Playwright / Vitest
5. Run backend API tests (Vitest) + frontend UI tests (Playwright)
6. Run inline Node.js DB verification queries
7. EXIT trap fires: delete-org removes all test data in FK-safe order:
   action_items → citations → audits → brands → users → organizations
8. Print PASS / FAIL summary
```

**Cleanup is guaranteed.** Every script uses `trap cleanup EXIT` (Unix) or a `:cleanup` goto (Windows). Test data is deleted even on `Ctrl+C`.

**Manual cleanup** if a script is interrupted before trap fires:
```bash
# Find orphaned test data
psql "$DATABASE_URL" -c "SELECT id, name FROM organizations WHERE name LIKE '[S6-QA]%';"
# Purge all stale test orgs
npx tsx s6-qa-scripts/shared/seed.ts purge-stale
```

---

## Feature 1 — Sidebar: Action Center entry activates

**Scripts:** `unix/s6-f01-sidebar.sh` · `windows/S6-F01-SIDEBAR.bat`

**Spec source:** DI2+DI5 fix — sidebar entry was a disabled placeholder in Sprint 4; Sprint 6 activates it.

**What is tested:**
- "Action Center" label visible in the **Insights** sidebar group
- Sparkles icon (`✦`) present; **no** "Sprint 6" badge or placeholder text (DI2+DI5)
- Clicking the entry navigates to `/action-center`
- `aria-current="page"` applied to the entry when on `/action-center` (BK4)
- Active state transfers when navigating to other sidebar items (Dashboard, Brands)
- Sprint 4 sidebar items (Dashboard, Brands, Audits, Portfolio) still navigate correctly — no regressions

**Test data seeded:** org1 (starter) + user1 — no action_items needed for sidebar tests.

**Playwright spec:** `07-sidebar-navigation.spec.ts` (FE-S6-48, FE-S6-49, FE-S6-50)

**Run:**
```bash
bash s6-qa-scripts/unix/s6-f01-sidebar.sh
# Windows:
s6-qa-scripts\windows\S6-F01-SIDEBAR.bat
```

---

## Feature 2 — Recommendation generation via Inngest

**Script:** `unix/s6-f02-inngest-generation.sh` · `windows/S6-F02-INNGEST-GENERATION.bat`

**⚠️ Requires Inngest dev server:** `npx inngest-cli@latest dev` (port 8288)  
**⚠️ Takes 35 seconds** — waits for `generate-recommendations` to complete.

**Spec source:** DA3 (event name `audit/complete`), DC3 (unique constraint + onConflictDoNothing), DN1 (empty array guard), DB5 (function registered in serve()).

**What is tested:**
- Firing the `audit/complete` Inngest event (via `POST http://localhost:8288/e/test`)
- `generate-recommendations` function completes within 30s (definition of done)
- `action_items` rows written to DB with valid values:
  - `dimension` ∈ {frequency, position, sentiment, context, accuracy}
  - `confidence_label` ∈ {confirmed, likely, hypothesis}
  - `expected_impact_score` ∈ {high, medium, low}
  - `status = 'open'` for all fresh rows
- No anti-pattern `recommendationKey` values in generated rows
- **Idempotency:** replaying the same `auditId` event produces 0 new rows (`.onConflictDoNothing`)
- `recommendation_research` has ≥1 row for each of the 11 universal keys (DN5)

**Test data seeded:** org1 + brand + completed audit (low scores so all triggers fire). Inngest generates the action_items.

**Run:**
```bash
# Prerequisites in separate terminals:
LLM_MODE=mock MOCK_SCENARIO=happy_path pnpm dev    # terminal 1
npx inngest-cli@latest dev                         # terminal 2

# Then run (takes ~40s):
bash s6-qa-scripts/unix/s6-f02-inngest-generation.sh
```

---

## Feature 3 — Action Center list page

**Script:** `unix/s6-f03-f04-action-center-cards.sh` (combined with Feature 4)

**Spec source:** DC5 (URL searchParams), DJ2 (loading.tsx skeleton), DJ3 (header count queries), DK1 (pagination), DK4 (ORDER BY dimension ASC).

**What is tested:**
- `h1` reads **"Action Center"**
- Header paragraph: `"N open recommendations across M brands"` — singular/plural correct per DJ3
- Dimension sections render with `h2` headings — only non-empty dimensions appear
- Loading skeleton visible when network throttled to Slow 3G (DJ2)
- `GET /api/action-items?limit=200` response shape (DA5):
  - Has `items[]`, `total`, `page`, `totalPages` fields
  - `items[0]` has `brandName` (from JOIN), `evidenceRefs[]`, `confidenceLabel`, `expectedImpactScore`
- No 5th Dashboard KPI card for recommendations (DJ4)

**Test data seeded:** org1 + brand + audit + **7 items** across all 5 dimensions and all 3 confidence levels.

**Playwright spec:** `01-action-center-page.spec.ts` (FE-S6-01–FE-S6-08)

---

## Feature 4 — Recommendation card shape and content

**Script:** `unix/s6-f03-f04-action-center-cards.sh` (combined with Feature 3)

**Spec source:** DG2 (card elements), DG3 (confidence badge colours), DH2 (expectedImpactScore field name), DJ5 (impact line as enum copy), DI3 (no engines badge), DM4 (expectedImpactScore NOT NULL).

**What is tested:**
- **6 required elements** on every card:
  1. Impact badge: `High` (red/danger), `Medium` (amber/warning), `Low` (blue/info) — from `expectedImpactScore` mapped via `IMPACT_TONE` (DH2, DM4)
  2. Title text
  3. Impact line: one of "High impact — significant visibility lift expected" / "Medium impact — moderate visibility improvement" / "Low impact — minor or indirect benefit" (DJ5 enum copy — NOT `+3-5 visibility pts`)
  4. Citation count (static text from `evidenceRefs.length` — not interactive on list card)
  5. ConfidenceBadge: Confirmed=green, Likely=amber, Hypothesis=gray (DG3)
  6. ChevronRight — navigates to `/action-center/[item.id]`
- **NO** `engines` badge on list card (DI3 — Sprint 8 scope)
- **NO** "Mark done" or "Dismiss" buttons on list card (DG2 — live on detail page only)
- **NO** numeric confidence values anywhere (categorical labels only — sprint 6 §14)

**Playwright spec:** `02-recommendation-cards.spec.ts` (FE-S6-09–FE-S6-20)

**Run (F03+F04):**
```bash
bash s6-qa-scripts/unix/s6-f03-f04-action-center-cards.sh
```

---

## Feature 5 — Evidence link: expand/collapse

**Script:** `unix/s6-f05-f06-evidence-detail.sh` (combined with Feature 6)

**Spec source:** DF3 (EvidenceLink never specified), DH5 (evidenceRefs immutability).

**What is tested:**
- EvidenceLink expand/collapse is on the **detail page only** — list card shows static count
- Collapsed state: `"View research (N citations)"` with chevron icon (DF3)
- Expanding shows: source name, clickable link, summary text
- External links open in `target="_blank"` (new tab)
- Link URL is a real research URL (not `#` or `example.com`)
- Second click collapses the section
- `evidenceRefs = []` → **nothing rendered** (no "View research" toggle, no "0 citations")
- `evidence_refs` DB column is **unchanged** after PATCH mark-done (DH5 immutability)

**Test data seeded:**
- `item_A` — 2 evidenceRefs (Princeton GEO study + SE Ranking)
- `item_B` — `evidenceRefs = []` (empty array, forced via direct DB insert)

**Playwright spec:** `04-action-detail-page.spec.ts` (FE-S6-28–FE-S6-35)

---

## Feature 6 — ActionDetail page

**Script:** `unix/s6-f05-f06-evidence-detail.sh` (combined with Feature 5)

**Spec source:** DH1 (ActionDetailPage never specified), DM1+DM2 (Sprint 8 meta-cards absent).

**What is tested:**
- `/action-center/{uuid}` loads — server component fetches via `GET /api/action-items/[id]`
- **ConfidenceBadge** at top in correct colour
- `h1` shows the full recommendation title
- Subtitle in format `{BrandName} · {dimension}` — **lowercase** dimension value, not the label
- `"What to do"` `h2` heading and action text visible
- EvidenceLink component present when evidenceRefs non-empty
- **"Mark done"** button visible (Starter tier)
- **"Dismiss"** button visible (Starter tier)
- Breadcrumb: "Action Center" → item title
- **NO** Effort / Time-to-impact / Affected-engines meta-cards (DM1+DM2 — Sprint 8 scope)
- `/action-center/00000000-0000-0000-0000-000000000000` → Next.js 404 page (not 500)

**Run (F05+F06):**
```bash
bash s6-qa-scripts/unix/s6-f05-f06-evidence-detail.sh
```

---

## Feature 7 — Mark done flow

**Script:** `unix/s6-f07-f08-mark-done-dismiss.sh` · `windows/S6-F07-F08-MARK-DONE-DISMISS.bat`

**Spec source:** DI1 (ActionStatusButtons), DJ1 (db.update fields), DG4 (post-PATCH UX), DH1 (condition for showing buttons), DH5 (evidenceRefs immutability).

**What is tested:**
- "Mark done" button calls `PATCH /api/action-items/[id]/status` with `{ status: "done" }`
- Post-PATCH: `router.refresh()` hides buttons OR `router.push('/action-center')` removes from list (both valid — DG4/DI1)
- **DB verified:** `status="done"`, `doneAt` non-null, `updatedAt` recent, `dismissedAt=null`, `dismissedReason=null` (DJ1)
- Done item absent from `GET /api/action-items` list (DN2 — `open` + `in_progress` only)
- Navigating to `/action-center/{done-item-id}` still loads the page; buttons **hidden** (DH1 condition: `!isFree && status !== 'done' && status !== 'dismissed'`)

**Test data seeded:** 4 open items — item1/item2 for Playwright UI, item3/item4 for Vitest API tests.

**Backend spec:** `05-action-items-status.test.ts` (TC-S6-43–TC-S6-54)  
**Playwright spec:** `05-mark-done-dismiss.spec.ts` (FE-S6-36–FE-S6-40)

---

## Feature 8 — Dismiss with reason flow

**Script:** `unix/s6-f07-f08-mark-done-dismiss.sh` · `windows/S6-F07-F08-MARK-DONE-DISMISS.bat`

**Spec source:** DI1 (inline textarea for reason), DB3 (Zod refine: dismissedReason required when status=dismissed), DJ1 (db.update sets dismissedAt, dismissedReason, updatedAt).

**What is tested:**
- "Dismiss" button reveals **inline textarea** for reason (DI1)
- Submitting **without** typing a reason:
  - Button disabled until text entered, OR
  - Zod 422 / validation message displayed (DB3 refine)
  - DB status unchanged (still `open`)
- Submitting **with** a reason: PATCH succeeds
- **DB verified:** `status="dismissed"`, `dismissedReason` matches typed text, `dismissedAt` non-null, `doneAt=null`, `updatedAt` recent (DJ1)
- Dismissed item absent from default list (same `open` + `in_progress` filter)
- On PATCH error (DevTools → Request Blocking → `/api/action-items/*/status`): toast `"Failed to update — try again"` appears; status unchanged (DG4)

**Run (F07+F08):**
```bash
bash s6-qa-scripts/unix/s6-f07-f08-mark-done-dismiss.sh
# Windows:
s6-qa-scripts\windows\S6-F07-F08-MARK-DONE-DISMISS.bat
```

---

## Feature 9 — Free tier gate

**Script:** `unix/s6-f09-f10-tier-gate.sh`

**Spec source:** DD4 (isFree prop flow), DG2 (TierGate wraps body except title), DN4 (title always readable).

**What is tested:**
- Action Center page loads for Free tier user (org2)
- Card **titles** are readable — **outside** TierGate wrapper
- Card body content (impact line, citation count, confidence badge) **blurred**: `filter: blur(4px)`, `pointerEvents: none`, `userSelect: none`
- `"Upgrade to Starter to unlock"` CTA overlaid on blurred content — links to `/settings/billing`
- **NO** "Mark done" / "Dismiss" buttons anywhere (list card or detail page)
- Detail page: title readable, `"What to do"` section blurred, upgrade CTA overlaid
- EvidenceLink **NOT gated** — evidence citations expand for Free tier (EvidenceLink is outside `<TierGate>` in DH1)
- CTA navigates to `/settings/billing`
- **API returns full data for both tiers** — tier gate is UI-only, not API-level

**Test data seeded:** org1 (starter) + org2 (free) — each with brand + audit + 1 item.

**Playwright spec:** `03-tier-gate.spec.ts` (FE-S6-21–FE-S6-27)

---

## Feature 10 — Starter tier full access

**Script:** `unix/s6-f09-f10-tier-gate.sh` (combined with Feature 9)

**Spec source:** DD4, DH1.

**What is tested:**
- Action text **fully readable** — no blur, no pointer-events restriction
- `"Mark done"` button visible and clickable
- `"Dismiss"` button visible and clickable
- **NO** "Upgrade to Starter" CTA anywhere on the page

**Run (F09+F10):**
```bash
bash s6-qa-scripts/unix/s6-f09-f10-tier-gate.sh
```

---

## Feature 11 — Filters: Brand, Dimension, Confidence

**Script:** `unix/s6-f11-filters.sh`

**Spec source:** DC5 (URL searchParams — not React state), DK4 (ORDER BY).

**What is tested:**

| Filter | Param | Expected behaviour |
|---|---|---|
| Brand | `?brandId={uuid}` | Only that brand's items; other brands absent |
| Dimension | `?dimension=frequency` | Only Frequency section; other sections absent |
| Confidence | `?confidence=confirmed` | Only Confirmed cards; Likely/Hypothesis absent |
| Combined | `?brandId=X&dimension=accuracy` | Single brand + single dimension |

- Filter URL params **survive page reload** — bookmarkable per DC5
- UI filter controls push to URL on change (`router.push` with `new URLSearchParams`)
- **Browser back** preserves filter params; breadcrumb correctly drops them (breadcrumb links to `/action-center` bare)
- API assertions: exact counts verified for each filter combination

**Test data seeded:**
- brand_alpha: 2 items (`frequency/confirmed` + `accuracy/confirmed`)
- brand_beta: 1 item (`context/likely`)
- Chosen so filter assertions have clean expected counts (no ambiguity)

**Playwright spec:** `06-filters.spec.ts` (FE-S6-41–FE-S6-47)  
**Backend spec:** `03-action-items-list.test.ts` (TC-S6-21–TC-S6-35)

**Run:**
```bash
bash s6-qa-scripts/unix/s6-f11-filters.sh
```

---

## Feature 12 — Cross-org isolation (RLS)

**Script:** `unix/s6-f12-f13-f14-security-antipattern.sh`

**Spec source:** DM5 (setRlsContext on PATCH), DH3 (RLS enabled with org_isolation policy).

**What is tested:**
- User2 (org2) `GET /api/action-items/{org1-item-id}` → **404** (not 403, not data)
- User2 `PATCH /api/action-items/{org1-item-id}/status` → **404** (RLS via setRlsContext — DM5)
- User2's `GET /api/action-items?limit=200` list contains **none** of org1's items
- Navigating to `/action-center/{org1-item-id}` as User2 → **404 Not Found** page

**Test data seeded:** org1 (target) + org2 (attacker) — each with 1 item.

---

## Feature 13 — Unauthenticated access

**Script:** `unix/s6-f12-f13-f14-security-antipattern.sh` (combined with F12+F14)

**What is tested:**
- No session: `GET /action-center` → redirect to `/sign-in` (Clerk middleware)
- No session: `GET /action-center/{uuid}` → redirect to `/sign-in`
- Response is a redirect (302/307) — **not** a 404 or 500

**Playwright spec:** `09-unauthenticated.spec.ts`

---

## Feature 14 — Anti-pattern filter

**Script:** `unix/s6-f12-f13-f14-security-antipattern.sh` (combined with F12+F13)

**Spec source:** DB2 (BLOCKED_KEYS + BLOCKED_PATTERNS never written; this fix specifies them).

**What is tested:**
- **Unit tests** — `applyAntiPatternFilter` — 14 tests:
  - 12 key-block tests (one per blocked key)
  - 1 content-regex test: action text `"You should buy reviews from Trustpilot"` → blocked
  - 1 passthrough test: `wikipedia-article` → passes through unchanged
- **DB check:** None of 12 blocked `recommendationKey` values exist in `action_items`
- **Code check:** `lib/recommendations/anti-patterns.ts` has both `BLOCKED_KEYS` Set and `BLOCKED_PATTERNS` regex

12 blocked keys:
```
add-more-keywords      pay-for-ai-ads         submit-to-ai-engines
get-more-backlinks     use-ai-to-write-content update-meta-tags-for-ai
improve-seo-generic    buy-reviews             create-ai-generated-reviews
add-schema-without-entity  target-competitor-terms  run-more-audits
```

**Playwright spec:** `08-cross-org-isolation.spec.ts`

**Run (F12+F13+F14):**
```bash
bash s6-qa-scripts/unix/s6-f12-f13-f14-security-antipattern.sh
```

---

## Feature 15 — recommendation_research seed completeness

**Script:** `unix/s6-f15-f16-schema-seed.sh` (combined with Feature 16)

**Spec source:** DN5 (enrich-evidence silently returns [] if seed missing), DE5 (seed shape specified), DE4 (index on recommendationKey).

**What is tested:**
- All **11 universal keys** have ≥1 row in `recommendation_research`:

| Key | Expected confidence (display-only — DL4) |
|---|---|
| `au-local-citations` | confirmed |
| `cited-statistics` | likely |
| `comparison-article` | hypothesis |
| `expert-quotes` | likely |
| `faq-content` | likely |
| `linkedin-presence` | hypothesis |
| `medium-presence` | hypothesis |
| `press-mentions` | likely |
| `reddit-absence` | likely |
| `stale-content` | confirmed |
| `wikipedia-article` | confirmed |

- Each row has non-null `source`, non-empty `summary`, real `url` (not `#`)
- `confidence_level` column present per row (display-only metadata — DL4: NOT used at runtime)
- `recommendation_research_key_idx` index exists on `(recommendationKey)` (DE4)

**No test data seeded** — reads the existing production seed data.

**Backend spec:** `02-recommendation-research-seed.test.ts` (TC-S6-13–TC-S6-20)

---

## Feature 16 — action_items schema and RLS

**Script:** `unix/s6-f15-f16-schema-seed.sh` (combined with Feature 15)

**Spec source:** DH3 (RLS SQL), DC3 (unique index), DA2 (updatedAt), DM4 (expectedImpactScore NOT NULL).

**What is tested:**
- All **17 columns** present with correct physical snake_case names:
  `id`, `organization_id`, `brand_id`, `audit_id`, `recommendation_key`, `dimension`, `title`, `action`, `confidence_label`, `expected_impact_score`, `evidence_refs`, `status`, `dismissed_reason`, `done_at`, `dismissed_at`, `created_at`, `updated_at`
- `action_items_audit_rec_idx` unique index on `(audit_id, recommendation_key)` (DC3)
- `action_items` RLS: `rowsecurity = true` with `org_isolation` policy (DH3)
- `recommendation_research` RLS: `rowsecurity = false` (global data — DH3)
- `updatedAt` is set on every PATCH (DA2 fix — was missing from original spec)
- `expectedImpactScore` is `NOT NULL` (DM4 fix — was nullable, caused `IMPACT_TONE[null]` = undefined)

**No test data seeded** — inspects schema and RLS configuration directly.

**Backend spec:** `01-schema-constraints.test.ts` (TC-S6-01–TC-S6-12)

**Run (F15+F16):**
```bash
bash s6-qa-scripts/unix/s6-f15-f16-schema-seed.sh
```

---

## Run all features

```bash
# All features except F02 (Inngest — needs 35s wait + separate server):
bash s6-qa-scripts/unix/s6-run-all.sh

# Include F02:
bash s6-qa-scripts/unix/s6-run-all.sh --include-f02

# Windows (F01, F07+F08 only — use WSL for full suite):
s6-qa-scripts\windows\S6-RUN-ALL.bat
```

---

## Feature-to-script + spec mapping

| Feature | Script | Playwright spec | Vitest spec |
|---|---|---|---|
| F01 Sidebar | `s6-f01-sidebar.sh` | `07-sidebar-navigation.spec.ts` | — |
| F02 Inngest | `s6-f02-inngest-generation.sh` | — | `02-recommendation-research-seed.test.ts` |
| F03 List page | `s6-f03-f04-action-center-cards.sh` | `01-action-center-page.spec.ts` | `03-action-items-list.test.ts` |
| F04 Card shape | `s6-f03-f04-action-center-cards.sh` | `02-recommendation-cards.spec.ts` | — |
| F05 Evidence link | `s6-f05-f06-evidence-detail.sh` | `04-action-detail-page.spec.ts` | — |
| F06 Detail page | `s6-f05-f06-evidence-detail.sh` | `04-action-detail-page.spec.ts` | `04-action-items-detail.test.ts` |
| F07 Mark done | `s6-f07-f08-mark-done-dismiss.sh` | `05-mark-done-dismiss.spec.ts` | `05-action-items-status.test.ts` |
| F08 Dismiss | `s6-f07-f08-mark-done-dismiss.sh` | `05-mark-done-dismiss.spec.ts` | `05-action-items-status.test.ts` |
| F09 Free tier | `s6-f09-f10-tier-gate.sh` | `03-tier-gate.spec.ts` | `06-acceptance.test.ts` |
| F10 Starter tier | `s6-f09-f10-tier-gate.sh` | `03-tier-gate.spec.ts` | — |
| F11 Filters | `s6-f11-filters.sh` | `06-filters.spec.ts` | `03-action-items-list.test.ts` |
| F12 Cross-org | `s6-f12-f13-f14-security-antipattern.sh` | `08-cross-org-isolation.spec.ts` | — |
| F13 Unauthenticated | `s6-f12-f13-f14-security-antipattern.sh` | `09-unauthenticated.spec.ts` | — |
| F14 Anti-pattern | `s6-f12-f13-f14-security-antipattern.sh` | — | `anti-patterns.test.ts` |
| F15 Research seed | `s6-f15-f16-schema-seed.sh` | — | `02-recommendation-research-seed.test.ts` |
| F16 Schema + RLS | `s6-f15-f16-schema-seed.sh` | — | `01-schema-constraints.test.ts` |

---

## Sign-off checklist

| # | Feature | Script | Result |
|---|---|---|---|
| F01 | Sidebar entry activates — label, icon, no badge, active state | `s6-f01-sidebar.sh` | ☐ Pass ☐ Fail |
| F02 | Recommendation generation ≤30s, valid DB rows, idempotent | `s6-f02-inngest-generation.sh` | ☐ Pass ☐ Fail |
| F03 | Action Center list page — h1, header count, dimension groups | `s6-f03-f04-action-center-cards.sh` | ☐ Pass ☐ Fail |
| F04 | Recommendation card — 6 elements, colours, no Sprint 8 fields | `s6-f03-f04-action-center-cards.sh` | ☐ Pass ☐ Fail |
| F05 | Evidence link — expand/collapse, links, empty renders nothing, immutable | `s6-f05-f06-evidence-detail.sh` | ☐ Pass ☐ Fail |
| F06 | ActionDetail page — all 8 elements, Sprint 8 absent, 404 correct | `s6-f05-f06-evidence-detail.sh` | ☐ Pass ☐ Fail |
| F07 | Mark done — DB: status/doneAt/updatedAt, excluded from list | `s6-f07-f08-mark-done-dismiss.sh` | ☐ Pass ☐ Fail |
| F08 | Dismiss — validation enforced, DB: dismissedReason/dismissedAt | `s6-f07-f08-mark-done-dismiss.sh` | ☐ Pass ☐ Fail |
| F09 | Free tier — blur, upgrade CTA, no action buttons, evidence unblurred | `s6-f09-f10-tier-gate.sh` | ☐ Pass ☐ Fail |
| F10 | Starter tier — full content, action buttons, no CTA | `s6-f09-f10-tier-gate.sh` | ☐ Pass ☐ Fail |
| F11 | Filters — brand, dimension, confidence, persist on reload | `s6-f11-filters.sh` | ☐ Pass ☐ Fail |
| F12 | Cross-org — GET/PATCH/list all return 404 for other org's items | `s6-f12-f13-f14-security-antipattern.sh` | ☐ Pass ☐ Fail |
| F13 | Unauthenticated — /action-center and /action-center/[id] redirect | `s6-f12-f13-f14-security-antipattern.sh` | ☐ Pass ☐ Fail |
| F14 | Anti-pattern filter — 14 unit tests green, 0 blocked keys in DB | `s6-f12-f13-f14-security-antipattern.sh` | ☐ Pass ☐ Fail |
| F15 | Research seed — all 11 keys, real URLs, index exists | `s6-f15-f16-schema-seed.sh` | ☐ Pass ☐ Fail |
| F16 | Schema — 17 columns, unique index, RLS on/off correct | `s6-f15-f16-schema-seed.sh` | ☐ Pass ☐ Fail |

**Sprint 6 QA PASS** = all 16 features ☑ Pass, zero Fail.
