/**
 * shared/seed.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * CLI seed / teardown helper.  Every feature script calls this via:
 *   npx tsx shared/seed.ts <command> [args…]
 *
 * Uses a SERVICE-ROLE Drizzle connection (DIRECT_URL, bypasses RLS) so it can
 * insert / delete across all tables without needing a Clerk session.
 *
 * All test records are identified by the prefix  [S6-QA]  in their name/title.
 * If a script crashes before cleanup, you can nuke leftovers with:
 *   npx tsx shared/seed.ts purge-stale
 *
 * Commands
 * ──────────────────────────────────────────────────────────────────────────────
 * seed-org   <clerkOrgId> <name> <tier>
 *   → upserts org, prints { id }
 *
 * seed-user  <orgId> <clerkUserId> <email>
 *   → upserts user (role=owner), prints { id }
 *
 * seed-brand <orgId> [name]
 *   → inserts brand, prints { id, name }
 *
 * seed-audit <orgId> <brandId>
 *   → inserts completed audit with low scores (all thresholds trigger), prints { id }
 *
 * seed-item  <orgId> <brandId> <auditId> <key> <dim> <conf> <impact> [status]
 *   → inserts one action_item, prints { id }
 *
 * seed-suite <orgId> <brandId> <auditId>
 *   → inserts 7 items covering all 5 dimensions + all 3 confidence levels, prints { ids[] }
 *
 * delete-org <orgId>
 *   → FK-safe hard-delete of all org data, prints { deleted: orgId }
 *
 * list-items <orgId>
 *   → prints { count, items[{ id, key, status }] }
 *
 * purge-stale
 *   → deletes all orgs whose name starts with "[S6-QA]"
 * ──────────────────────────────────────────────────────────────────────────────
 */

import 'dotenv/config';
import { drizzle }         from 'drizzle-orm/postgres-js';
import postgres            from 'postgres';
import { eq, inArray, like } from 'drizzle-orm';
import * as schema         from '../../db/schema';

// ── DB client (service-role — uses DIRECT_URL to bypass RLS pooler) ────────────
const connStr = process.env.DIRECT_URL ?? process.env.DATABASE_URL!;
const pg  = postgres(connStr, { max: 1 });
const db  = drizzle(pg, { schema });

// ── Helpers ────────────────────────────────────────────────────────────────────

function out(obj: unknown) { console.log(JSON.stringify(obj)); }
function err(msg: string)  { console.error(JSON.stringify({ error: msg })); process.exit(1); }

async function seedOrg(clerkOrgId: string, name: string, tier: string) {
  const [ex] = await db.select().from(schema.organizations)
    .where(eq(schema.organizations.clerkOrgId, clerkOrgId));
  if (ex) return out({ id: ex.id, existing: true });
  const [org] = await db.insert(schema.organizations)
    .values({ clerkOrgId, name, region: 'au',
              tier: (tier as 'free' | 'starter' | 'growth' | 'agency' | 'agency_pro') })
    .returning();
  out({ id: org.id });
}

async function seedUser(orgId: string, clerkUserId: string, email: string) {
  const [ex] = await db.select().from(schema.users)
    .where(eq(schema.users.clerkUserId, clerkUserId));
  if (ex) return out({ id: ex.id, existing: true });
  const [u] = await db.insert(schema.users)
    .values({ clerkUserId, organizationId: orgId, email,
              name: '[S6-QA] Test User', role: 'owner' })
    .returning();
  out({ id: u.id });
}

async function seedBrand(orgId: string, name?: string) {
  const tag = `[S6-QA] ${name ?? 'Brand ' + Date.now()}`;
  const [b] = await db.insert(schema.brands)
    .values({ organizationId: orgId, name: tag,
              domain: `s6qa-${Date.now()}.test`, vertical: 'tradies',
              region: 'au', primaryRegions: ['NSW:Bondi'], competitors: [] })
    .returning();
  out({ id: b.id, name: b.name });
}

async function seedAudit(orgId: string, brandId: string) {
  const existing = await db.select({ id: schema.audits.id })
    .from(schema.audits).where(eq(schema.audits.brandId, brandId));
  const [a] = await db.insert(schema.audits)
    .values({
      organizationId: orgId, brandId,
      auditNumber:   existing.length + 1,
      status: 'complete', triggeredBy: 'manual',
      engines: ['chatgpt','perplexity'], promptsCount: 10,
      runsPerPrompt: 1, totalCalls: 10,
      // Low scores — all 11 universal triggers fire
      scoreFrequency:        '20.00',
      scorePosition:         '28.00',
      scoreSentimentNumeric: '38.00',
      scoreContextNumeric:   '30.00',
      scoreAccuracy:         '25.00',
      scoreComposite:        '28.20',
      totalCostUsd: '0.0150',
      metadata: { mockScenario: 'happy_path' },
    })
    .returning();
  out({ id: a.id });
}

async function seedItem(
  orgId: string, brandId: string, auditId: string,
  key: string, dim: string, conf: string, impact: string,
  status = 'open',
) {
  const [item] = await db.insert(schema.actionItems)
    .values({
      organizationId: orgId, brandId, auditId,
      recommendationKey:   key,
      dimension:           dim,
      title:  `[S6-QA] ${key.replace(/-/g, ' ')}`,
      action: `[S6-QA] Action text for ${key}. Take this step to improve GEO visibility.`,
      confidenceLabel:     conf as 'confirmed' | 'likely' | 'hypothesis',
      expectedImpactScore: impact as 'high' | 'medium' | 'low',
      evidenceRefs: [
        { source: 'Princeton GEO study (2024)',
          url:    'https://arxiv.org/abs/2404.11973',
          summary: `Research backing for ${key}: measurably improves AI citation rate.` },
        { source: 'SE Ranking AI Mode research (Dec 2025)',
          url:    'https://seranking.com/blog/ai-overviews-study/',
          summary: 'Pages updated within 2 months average 5.0 AI citations vs 3.9 for older content.' },
      ],
      status: status as 'open' | 'in_progress' | 'done' | 'dismissed',
    })
    .returning();
  out({ id: item.id });
}

async function seedSuite(orgId: string, brandId: string, auditId: string) {
  const rows = [
    // key                    dim          conf           impact
    ['wikipedia-article',  'frequency', 'confirmed',  'high'  ],
    ['reddit-absence',     'frequency', 'likely',     'medium'],
    ['medium-presence',    'frequency', 'hypothesis', 'low'   ],
    ['comparison-article', 'position',  'hypothesis', 'medium'],
    ['expert-quotes',      'accuracy',  'likely',     'medium'],
    ['faq-content',        'context',   'likely',     'medium'],
    ['stale-content',      'accuracy',  'confirmed',  'high'  ],
  ] as const;

  const ids: string[] = [];
  for (const [key, dim, conf, imp] of rows) {
    const [item] = await db.insert(schema.actionItems)
      .values({
        organizationId: orgId, brandId, auditId,
        recommendationKey: key, dimension: dim,
        title:  `[S6-QA] ${key.replace(/-/g, ' ')}`,
        action: `[S6-QA] Action text for ${key}.`,
        confidenceLabel:     conf,
        expectedImpactScore: imp,
        evidenceRefs: [
          { source: 'Princeton GEO study (2024)',
            url:    'https://arxiv.org/abs/2404.11973',
            summary: `Evidence for ${key}.` },
        ],
        status: 'open',
      })
      .returning();
    ids.push(item.id);
  }
  out({ ids });
}

async function deleteOrg(orgId: string) {
  // FK-safe order: action_items first (RESTRICT on brandId)
  await db.delete(schema.actionItems).where(eq(schema.actionItems.organizationId, orgId));
  const audits = await db.select({ id: schema.audits.id })
    .from(schema.audits).where(eq(schema.audits.organizationId, orgId));
  if (audits.length > 0) {
    await db.delete(schema.citations)
      .where(inArray(schema.citations.auditId, audits.map(a => a.id)));
  }
  await db.delete(schema.audits).where(eq(schema.audits.organizationId, orgId));
  await db.delete(schema.brands).where(eq(schema.brands.organizationId, orgId));
  await db.delete(schema.users).where(eq(schema.users.organizationId, orgId));
  await db.delete(schema.organizations).where(eq(schema.organizations.id, orgId));
  out({ deleted: orgId });
}

async function listItems(orgId: string) {
  const items = await db
    .select({ id: schema.actionItems.id,
              key: schema.actionItems.recommendationKey,
              status: schema.actionItems.status })
    .from(schema.actionItems)
    .where(eq(schema.actionItems.organizationId, orgId));
  out({ count: items.length, items });
}

async function purgeStale() {
  const stale = await db.select({ id: schema.organizations.id })
    .from(schema.organizations)
    .where(like(schema.organizations.name, '[S6-QA]%'));
  let n = 0;
  for (const { id } of stale) { await deleteOrg(id); n++; }
  out({ purged: n });
}

// ── Dispatch ───────────────────────────────────────────────────────────────────

const [,, cmd, ...args] = process.argv;
(async () => {
  try {
    switch (cmd) {
      case 'seed-org':    await seedOrg(args[0], args[1], args[2] ?? 'starter'); break;
      case 'seed-user':   await seedUser(args[0], args[1], args[2]); break;
      case 'seed-brand':  await seedBrand(args[0], args[1]); break;
      case 'seed-audit':  await seedAudit(args[0], args[1]); break;
      case 'seed-item':   await seedItem(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); break;
      case 'seed-suite':  await seedSuite(args[0], args[1], args[2]); break;
      case 'delete-org':  await deleteOrg(args[0]); break;
      case 'list-items':  await listItems(args[0]); break;
      case 'purge-stale': await purgeStale(); break;
      default: err(`Unknown command: ${cmd ?? '(none)'}`);
    }
  } finally {
    await pg.end();
  }
})();
