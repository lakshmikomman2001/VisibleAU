#!/usr/bin/env bash
# =============================================================================
# unix/s6-f01-sidebar.sh
# Feature 1 — Sidebar: Action Center entry activates (DI2+DI5 fix)
#
# What is tested
#   • "Action Center" label present in Insights sidebar group
#   • Sparkles icon shown; no "Sprint 6" badge placeholder (DI2+DI5)
#   • Clicking entry navigates to /action-center
#   • aria-current="page" set on the entry when on /action-center (BK4)
#   • Active state transfers to other sidebar items on navigation
#   • Other Sprint 4 sidebar items (Dashboard, Brands, Audits) still work
#
# Test data seeded
#   org1 (starter) + user1 — no action_items needed for sidebar tests
#
# Cleanup
#   org1 hard-deleted in EXIT trap regardless of pass / fail
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$ROOT"

# ── colour helpers ────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
pass() { echo -e "  ${GREEN}PASS${NC}  $1"; }
fail() { echo -e "  ${RED}FAIL${NC}  $1"; TEST_EXIT=1; }
info() { echo -e "  ${YELLOW}....${NC}  $1"; }

echo "════════════════════════════════════════"
echo " Sprint 6 · Feature 1 — Sidebar Navigation"
echo "════════════════════════════════════════"
echo

# ── load env ──────────────────────────────────────────────────────────────────
[[ -f .env.test.local ]] || { echo "ERROR: .env.test.local missing"; exit 1; }
set -a; source .env.test.local; set +a

TEST_EXIT=0
ORG1_ID=""

cleanup() {
  echo; echo "── cleanup ──────────────────────────────"
  [[ -n "$ORG1_ID" ]] && {
    info "Deleting org $ORG1_ID…"
    npx tsx shared/seed.ts delete-org "$ORG1_ID" >/dev/null 2>&1 && pass "org deleted" || info "delete skipped (already gone)"
  }
}
trap cleanup EXIT

# ── step 1: prerequisites ─────────────────────────────────────────────────────
echo "[1/4] Prerequisites"
curl -sf "${E2E_APP_URL}/api/health" >/dev/null 2>&1 \
  && pass "App running at ${E2E_APP_URL}" \
  || { fail "App NOT running — start with: LLM_MODE=mock MOCK_SCENARIO=happy_path pnpm dev"; exit 1; }

# ── step 2: seed ─────────────────────────────────────────────────────────────
echo
echo "[2/4] Seed test data"
ORG1_ID=$(npx tsx shared/seed.ts seed-org \
    "${E2E_TEST_ORG_1_CLERK_ID}" "[S6-QA F01] Sidebar Org" "starter" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
npx tsx shared/seed.ts seed-user "$ORG1_ID" \
    "${E2E_TEST_USER_1_CLERK_ID}" "${E2E_TEST_USER_1_EMAIL}" >/dev/null
pass "org=$ORG1_ID + user seeded"

# ── step 3: Playwright ────────────────────────────────────────────────────────
echo
echo "[3/4] Playwright — sidebar tests"
export PLAYWRIGHT_ORG_ID="$ORG1_ID"

npx playwright test \
  tests/e2e/frontend/sprint6/07-sidebar-navigation.spec.ts \
  --config tests/e2e/frontend/sprint6/playwright.config.ts \
  --reporter=list \
  || TEST_EXIT=$?

# ── step 4: result ────────────────────────────────────────────────────────────
echo
echo "[4/4] Result"
if [[ $TEST_EXIT -eq 0 ]]; then
  pass "Feature 1 PASSED — Sidebar navigation correct"
else
  fail "Feature 1 FAILED — see Playwright output above"
fi
echo
exit $TEST_EXIT
