#!/usr/bin/env bash
# =============================================================================
# unix/s6-f03-f04-action-center-cards.sh
# Feature 3 — Action Center list page (header, dimension groups, skeleton)
# Feature 4 — Recommendation card shape (6 elements, colours, no S8 fields)
#
# Feature 3 checks
#   • h1 reads "Action Center"
#   • Header paragraph: "N open recommendations across M brands" — correct plural
#   • Dimension groups render with h2 headings (only non-empty groups shown)
#   • Loading skeleton visible when network throttled (DJ2 fix)
#   • API response: correct shape (DA5), ordered by dimension ASC (DK4)
#   • GET /api/action-items?limit=200 returns paginated response (DK1)
#
# Feature 4 checks
#   • Impact badge: High=danger/red, Medium=warning/amber, Low=info/blue (DH2, DM4)
#   • Impact line text is enum-mapped — NOT "+N-M pts" narrative (DJ5)
#   • Citation count shows evidenceRefs.length (static text on list card)
#   • ConfidenceBadge: Confirmed=green, Likely=amber, Hypothesis=gray (DG3)
#   • ChevronRight navigates to /action-center/[id]
#   • NO "engines" badge on list card (DI3 — Sprint 8 scope)
#   • NO "Mark done" or "Dismiss" on list card (DG2 — lives on detail page)
#   • NO numeric confidence scores (categorical labels only)
#
# Test data seeded
#   org1 (starter) + brand + audit + 7 action_items:
#     frequency×3 (confirmed/likely/hypothesis), position×1, accuracy×2, context×1
#   Covers all 5 dimensions and all 3 confidence levels
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$ROOT"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
pass() { echo -e "  ${GREEN}PASS${NC}  $1"; }
fail() { echo -e "  ${RED}FAIL${NC}  $1"; TEST_EXIT=1; }
info() { echo -e "  ${YELLOW}....${NC}  $1"; }

echo "════════════════════════════════════════"
echo " Sprint 6 · Features 3+4 — List Page & Cards"
echo "════════════════════════════════════════"
echo

[[ -f .env.test.local ]] || { echo "ERROR: .env.test.local missing"; exit 1; }
set -a; source .env.test.local; set +a

TEST_EXIT=0
ORG1_ID=""

cleanup() {
  echo; echo "── cleanup ──────────────────────────────"
  [[ -n "$ORG1_ID" ]] && {
    info "Deleting org $ORG1_ID…"
    npx tsx shared/seed.ts delete-org "$ORG1_ID" >/dev/null 2>&1 && pass "org deleted" || info "skipped"
  }
}
trap cleanup EXIT

echo "[1/5] Prerequisites"
curl -sf "${E2E_APP_URL}/api/health" >/dev/null 2>&1 \
  && pass "App running" || { fail "App not running"; exit 1; }

echo
echo "[2/5] Seed — org + brand + audit + 7 action_items"
ORG1_ID=$(npx tsx shared/seed.ts seed-org \
    "${E2E_TEST_ORG_1_CLERK_ID}" "[S6-QA F03] Cards Org" "starter" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
npx tsx shared/seed.ts seed-user "$ORG1_ID" \
    "${E2E_TEST_USER_1_CLERK_ID}" "${E2E_TEST_USER_1_EMAIL}" >/dev/null
BRAND_ID=$(npx tsx shared/seed.ts seed-brand "$ORG1_ID" "F03 Cards Brand" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
AUDIT_ID=$(npx tsx shared/seed.ts seed-audit "$ORG1_ID" "$BRAND_ID" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")

# 7 items — all 5 dimensions, all 3 confidence levels
for args in \
  "wikipedia-article  frequency confirmed  high" \
  "reddit-absence     frequency likely     medium" \
  "medium-presence    frequency hypothesis low" \
  "comparison-article position  hypothesis medium" \
  "expert-quotes      accuracy  likely     medium" \
  "faq-content        context   likely     medium" \
  "stale-content      accuracy  confirmed  high"
do
  read -r key dim conf imp <<< "$args"
  npx tsx shared/seed.ts seed-item \
    "$ORG1_ID" "$BRAND_ID" "$AUDIT_ID" "$key" "$dim" "$conf" "$imp" >/dev/null
done
pass "7 items seeded (5 dims, 3 confidence levels)"

export PLAYWRIGHT_ORG_ID="$ORG1_ID"
export PLAYWRIGHT_BRAND_ID="$BRAND_ID"
export PLAYWRIGHT_AUDIT_ID="$AUDIT_ID"

# ── [3/5] API checks (Feature 3 — shape, ordering, pagination) ───────────────
echo
echo "[3/5] API checks — GET /api/action-items"
node -e "
require('dotenv').config({ path: '.env.test.local' });
const APP = process.env.E2E_APP_URL;
const SID = process.env.E2E_TEST_USER_1_SESSION_ID;
async function check() {
  const res = await fetch(APP + '/api/action-items?limit=200', {
    headers: { Cookie: 'sid=' + SID }
  });
  if (!res.ok) { console.error('FAIL HTTP', res.status); process.exit(1); }
  const body = await res.json();
  const checks = [
    ['has items array',   Array.isArray(body.items)],
    ['has total field',   typeof body.total === 'number'],
    ['has page field',    typeof body.page === 'number'],
    ['items non-empty',   body.items.length > 0],
    ['has brandName',     body.items.length > 0 && typeof body.items[0].brandName === 'string'],
    ['has evidenceRefs',  body.items.length > 0 && Array.isArray(body.items[0].evidenceRefs)],
  ];
  let pass = true;
  for (const [label, ok] of checks) {
    console.log('  ' + (ok ? 'PASS' : 'FAIL') + '  ' + label);
    if (!ok) pass = false;
  }
  process.exit(pass ? 0 : 1);
}
check().catch(e => { console.error('FAIL', e.message); process.exit(1); });
" || TEST_EXIT=$?

# ── [4/5] Playwright — list page + card shape tests ──────────────────────────
echo
echo "[4/5] Playwright — Feature 3 (list page) + Feature 4 (card shape)"
npx playwright test \
  tests/e2e/frontend/sprint6/01-action-center-page.spec.ts \
  tests/e2e/frontend/sprint6/02-recommendation-cards.spec.ts \
  --config tests/e2e/frontend/sprint6/playwright.config.ts \
  --reporter=list \
  || TEST_EXIT=$?

echo
echo "[5/5] Result"
if [[ $TEST_EXIT -eq 0 ]]; then pass "Features 3+4 PASSED"
else fail "Features 3+4 FAILED — see output above"; fi
echo; exit $TEST_EXIT
