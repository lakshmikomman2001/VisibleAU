#!/usr/bin/env bash
# =============================================================================
# unix/s6-f05-f06-evidence-detail.sh
# Feature 5 — Evidence link (expand/collapse, external links, immutability)
# Feature 6 — ActionDetail page (all elements, no Sprint 8, 404 for missing)
#
# Feature 5 checks
#   • EvidenceLink is on the DETAIL page only; list card shows static count (DF3)
#   • Collapsed state: "View research (N citations)" with chevron icon
#   • Expanded: source name, clickable link, summary text visible
#   • External links open in new tab (target=_blank)
#   • Link URL is a real research URL, not "#" or "example.com"
#   • Collapse restores the hidden state on second click
#   • evidenceRefs=[] → NO "View research" toggle rendered (renders nothing)
#   • evidence_refs DB column is UNCHANGED after PATCH mark-done (DH5 immutability)
#
# Feature 6 checks
#   • /action-center/{uuid} loads — server component fetches item (DH1)
#   • ConfidenceBadge visible at top in correct colour
#   • h1 shows the recommendation title
#   • Subtitle: "{BrandName} · {dimension}" — lowercase dimension, not label
#   • "What to do" h2 heading + action text visible
#   • EvidenceLink present when evidenceRefs non-empty
#   • "Mark done" button visible (Starter tier)
#   • "Dismiss" button visible (Starter tier)
#   • Breadcrumb shows "Action Center" as parent segment
#   • NO Effort / Time-to-impact / Affected-engines cards (DM1+DM2 — Sprint 8)
#   • /action-center/00000000-0000-0000-0000-000000000000 → 404 Not Found
#
# Test data seeded
#   org1 (starter) + brand + audit
#   item_A : 2 evidenceRefs (Princeton GEO + SE Ranking) — for expand/link tests
#   item_B : evidenceRefs=[] — seeded directly via Node to force empty array
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$ROOT"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
pass() { echo -e "  ${GREEN}PASS${NC}  $1"; }
fail() { echo -e "  ${RED}FAIL${NC}  $1"; TEST_EXIT=1; }
info() { echo -e "  ${YELLOW}....${NC}  $1"; }

echo "════════════════════════════════════════"
echo " Sprint 6 · Features 5+6 — Evidence & Detail"
echo "════════════════════════════════════════"
echo

[[ -f .env.test.local ]] || { echo "ERROR: .env.test.local missing"; exit 1; }
set -a; source .env.test.local; set +a

TEST_EXIT=0
ORG1_ID=""

cleanup() {
  echo; echo "── cleanup ──────────────────────────────"
  [[ -n "$ORG1_ID" ]] && {
    info "Deleting org $ORG1_ID…"
    npx tsx shared/seed.ts delete-org "$ORG1_ID" >/dev/null 2>&1 && pass "org deleted" || info "skipped"
  }
}
trap cleanup EXIT

echo "[1/5] Prerequisites"
curl -sf "${E2E_APP_URL}/api/health" >/dev/null 2>&1 \
  && pass "App running" || { fail "App not running"; exit 1; }

echo
echo "[2/5] Seed — org + 2 items (with evidence + empty evidence)"
ORG1_ID=$(npx tsx shared/seed.ts seed-org \
    "${E2E_TEST_ORG_1_CLERK_ID}" "[S6-QA F05] Detail Org" "starter" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
npx tsx shared/seed.ts seed-user "$ORG1_ID" \
    "${E2E_TEST_USER_1_CLERK_ID}" "${E2E_TEST_USER_1_EMAIL}" >/dev/null
BRAND_ID=$(npx tsx shared/seed.ts seed-brand "$ORG1_ID" "F05 Detail Brand" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
AUDIT_ID=$(npx tsx shared/seed.ts seed-audit "$ORG1_ID" "$BRAND_ID" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")

# item_A — has 2 evidenceRefs (seeded by seed-item which always inserts 2)
ITEM_A_ID=$(npx tsx shared/seed.ts seed-item \
    "$ORG1_ID" "$BRAND_ID" "$AUDIT_ID" \
    "wikipedia-article" "frequency" "confirmed" "high" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")

# item_B — evidenceRefs=[] (forced via Node inline insert)
ITEM_B_ID=$(node -e "
require('dotenv').config({ path: '.env.test.local' });
const { drizzle } = require('drizzle-orm/postgres-js');
const postgres = require('postgres');
const s = require('./db/schema');
const pg = postgres(process.env.DIRECT_URL ?? process.env.DATABASE_URL, { max:1 });
const db = drizzle(pg, { schema: s });
db.insert(s.actionItems).values({
  organizationId: '${ORG1_ID}', brandId: '${BRAND_ID}', auditId: '${AUDIT_ID}',
  recommendationKey: 'medium-presence', dimension: 'frequency',
  title: '[S6-QA] Medium presence (empty evidence)',
  action: '[S6-QA] Publish a guide on Medium.',
  confidenceLabel: 'hypothesis', expectedImpactScore: 'low',
  evidenceRefs: [], status: 'open',
}).returning().then(([r]) => { console.log(r.id); pg.end(); });
" 2>/dev/null)

pass "item_A (2 evidence refs) = $ITEM_A_ID"
pass "item_B (0 evidence refs) = $ITEM_B_ID"

export PLAYWRIGHT_ORG_ID="$ORG1_ID"
export PLAYWRIGHT_ITEM_A_ID="$ITEM_A_ID"   # with evidence
export PLAYWRIGHT_ITEM_B_ID="$ITEM_B_ID"   # empty evidence

# ── [3/5] API check: GET /api/action-items/{id} shape ────────────────────────
echo
echo "[3/5] API check — GET /api/action-items/${ITEM_A_ID}"
node -e "
require('dotenv').config({ path: '.env.test.local' });
const APP = process.env.E2E_APP_URL;
const SID = process.env.E2E_TEST_USER_1_SESSION_ID;
fetch(APP + '/api/action-items/${ITEM_A_ID}', { headers: { Cookie: 'sid=' + SID } })
  .then(r => r.json())
  .then(body => {
    const checks = [
      ['has id',            body.id === '${ITEM_A_ID}'],
      ['has title',         typeof body.title === 'string'],
      ['has action',        typeof body.action === 'string'],
      ['has brandName',     typeof body.brandName === 'string'],
      ['has dimension',     typeof body.dimension === 'string'],
      ['has confidenceLabel', typeof body.confidenceLabel === 'string'],
      ['has expectedImpactScore', typeof body.expectedImpactScore === 'string'],
      ['evidenceRefs array', Array.isArray(body.evidenceRefs)],
      ['evidenceRefs len 2', body.evidenceRefs.length === 2],
    ];
    let pass = true;
    for (const [l, ok] of checks) { console.log('  ' + (ok ? 'PASS' : 'FAIL') + '  ' + l); if (!ok) pass = false; }
    process.exit(pass ? 0 : 1);
  }).catch(e => { console.error('FAIL', e.message); process.exit(1); });
" || TEST_EXIT=$?

# ── [4/5] Playwright — Features 5+6 ─────────────────────────────────────────
echo
echo "[4/5] Playwright — Feature 5 (evidence) + Feature 6 (detail page)"
npx playwright test \
  tests/e2e/frontend/sprint6/04-action-detail-page.spec.ts \
  --config tests/e2e/frontend/sprint6/playwright.config.ts \
  --reporter=list \
  || TEST_EXIT=$?

# ── evidence immutability check (DH5) ────────────────────────────────────────
echo
echo "      [DH5] Verifying evidence_refs unchanged after PATCH mark-done…"
node -e "
require('dotenv').config({ path: '.env.test.local' });
const { drizzle } = require('drizzle-orm/postgres-js');
const postgres = require('postgres');
const s = require('./db/schema');
const { eq } = require('drizzle-orm');
const pg = postgres(process.env.DIRECT_URL ?? process.env.DATABASE_URL, { max:1 });
const db = drizzle(pg, { schema: s });
db.select({ status: s.actionItems.status, refs: s.actionItems.evidenceRefs })
  .from(s.actionItems)
  .where(eq(s.actionItems.organizationId, '${ORG1_ID}'))
  .then(rows => {
    const doneRows = rows.filter(r => r.status === 'done');
    if (doneRows.length === 0) { console.log('  ....  No done items yet (test may not have marked done)'); }
    else {
      const allHaveRefs = doneRows.every(r => Array.isArray(r.refs));
      console.log('  ' + (allHaveRefs ? 'PASS' : 'FAIL') + '  evidence_refs non-null after PATCH done');
    }
    pg.end();
  });
"

echo
echo "[5/5] Result"
if [[ $TEST_EXIT -eq 0 ]]; then pass "Features 5+6 PASSED"
else fail "Features 5+6 FAILED — see output above"; fi
echo; exit $TEST_EXIT
