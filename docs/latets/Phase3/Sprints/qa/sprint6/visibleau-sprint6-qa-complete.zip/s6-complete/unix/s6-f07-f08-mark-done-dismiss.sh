#!/usr/bin/env bash
# =============================================================================
# unix/s6-f07-f08-mark-done-dismiss.sh
# Feature 7 — Mark done (PATCH status=done, doneAt set, excluded from list)
# Feature 8 — Dismiss with reason (validation, dismissedReason, excluded)
#
# Feature 7 checks
#   • "Mark done" button on ActionDetail PATCHes {status:"done"} (DI1)
#   • Post-PATCH: router.refresh() hides buttons OR router.push removes from list (DG4)
#   • DB: status="done", doneAt=non-null, updatedAt=recent, dismissedAt=null (DJ1)
#   • Done item excluded from GET /api/action-items (open+in_progress only, DN2)
#   • /action-center/{id} still loads for done item; buttons hidden (DH1 condition)
#
# Feature 8 checks
#   • "Dismiss" → inline textarea for reason appears (DI1)
#   • Confirming WITHOUT reason: button disabled OR Zod validation error (DB3 refine)
#   • DB status unchanged after failed dismiss attempt
#   • Confirming WITH reason: PATCH succeeds
#   • DB: status="dismissed", dismissedReason=text, dismissedAt=non-null, doneAt=null (DJ1)
#   • Dismissed item excluded from default list (same filter as done)
#
# Test data seeded
#   org1 (starter) + brand + audit + 4 open items:
#     item1 — Playwright UI mark-done test
#     item2 — Playwright UI dismiss test
#     item3 — Backend Vitest PATCH done test
#     item4 — Backend Vitest PATCH dismiss test
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$ROOT"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
pass() { echo -e "  ${GREEN}PASS${NC}  $1"; }
fail() { echo -e "  ${RED}FAIL${NC}  $1"; TEST_EXIT=1; }
info() { echo -e "  ${YELLOW}....${NC}  $1"; }

echo "════════════════════════════════════════"
echo " Sprint 6 · Features 7+8 — Mark Done & Dismiss"
echo "════════════════════════════════════════"
echo

[[ -f .env.test.local ]] || { echo "ERROR: .env.test.local missing"; exit 1; }
set -a; source .env.test.local; set +a

TEST_EXIT=0
ORG1_ID=""

cleanup() {
  echo; echo "── cleanup ──────────────────────────────"
  [[ -n "$ORG1_ID" ]] && {
    info "Deleting org $ORG1_ID…"
    npx tsx shared/seed.ts delete-org "$ORG1_ID" >/dev/null 2>&1 && pass "org deleted" || info "skipped"
  }
}
trap cleanup EXIT

echo "[1/6] Prerequisites"
curl -sf "${E2E_APP_URL}/api/health" >/dev/null 2>&1 \
  && pass "App running" || { fail "App not running"; exit 1; }

echo
echo "[2/6] Seed — org + brand + audit + 4 open items"
ORG1_ID=$(npx tsx shared/seed.ts seed-org \
    "${E2E_TEST_ORG_1_CLERK_ID}" "[S6-QA F07] Status Org" "starter" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
npx tsx shared/seed.ts seed-user "$ORG1_ID" \
    "${E2E_TEST_USER_1_CLERK_ID}" "${E2E_TEST_USER_1_EMAIL}" >/dev/null
BRAND_ID=$(npx tsx shared/seed.ts seed-brand "$ORG1_ID" "F07 Status Brand" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
AUDIT_ID=$(npx tsx shared/seed.ts seed-audit "$ORG1_ID" "$BRAND_ID" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")

ITEM1_ID=$(npx tsx shared/seed.ts seed-item "$ORG1_ID" "$BRAND_ID" "$AUDIT_ID" \
    "wikipedia-article" "frequency" "confirmed" "high" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
ITEM2_ID=$(npx tsx shared/seed.ts seed-item "$ORG1_ID" "$BRAND_ID" "$AUDIT_ID" \
    "reddit-absence" "frequency" "likely" "medium" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
ITEM3_ID=$(npx tsx shared/seed.ts seed-item "$ORG1_ID" "$BRAND_ID" "$AUDIT_ID" \
    "stale-content" "accuracy" "confirmed" "high" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
ITEM4_ID=$(npx tsx shared/seed.ts seed-item "$ORG1_ID" "$BRAND_ID" "$AUDIT_ID" \
    "faq-content" "context" "likely" "medium" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")

pass "4 items seeded: done-UI=$ITEM1_ID  dismiss-UI=$ITEM2_ID  done-API=$ITEM3_ID  dismiss-API=$ITEM4_ID"

# ── [3/6] Backend PATCH API tests via Vitest ─────────────────────────────────
echo
echo "[3/6] Backend API — PATCH /api/action-items/[id]/status"
export E2E_TEST_ORG_1_ID="$ORG1_ID"
export E2E_ITEM_DONE_ID="$ITEM3_ID"
export E2E_ITEM_DISMISS_ID="$ITEM4_ID"

npx vitest run \
  tests/e2e/backend/sprint6/05-action-items-status.test.ts \
  --config tests/e2e/backend/sprint6/vitest.config.e2e.ts \
  --reporter=verbose \
  || TEST_EXIT=$?

# ── [4/6] DB verification: mark-done PATCH ───────────────────────────────────
echo
echo "[4/6] DB verification — item3 after PATCH done"
node -e "
require('dotenv').config({ path: '.env.test.local' });
const { drizzle } = require('drizzle-orm/postgres-js');
const postgres = require('postgres');
const s = require('./db/schema');
const { eq } = require('drizzle-orm');
const pg = postgres(process.env.DIRECT_URL ?? process.env.DATABASE_URL, { max:1 });
const db = drizzle(pg, { schema: s });
async function run() {
  const [r] = await db.select().from(s.actionItems).where(eq(s.actionItems.id, '${ITEM3_ID}'));
  if (!r) { console.log('  ....  item3 not found (Vitest may not have run PATCH yet)'); await pg.end(); return; }
  const checks = [
    ['status done',        r.status === 'done'],
    ['doneAt non-null',    r.doneAt !== null],
    ['updatedAt non-null', r.updatedAt !== null],
    ['dismissedAt null',   r.dismissedAt === null],
    ['dismissedReason null', r.dismissedReason === null],
  ];
  let pass = true;
  for (const [label, ok] of checks) { console.log('  ' + (ok ? 'PASS' : 'FAIL') + '  ' + label); if (!ok) pass = false; }
  await pg.end();
  process.exit(pass ? 0 : 1);
}
run().catch(e => { console.error('FAIL', e.message); process.exit(1); });
" || TEST_EXIT=$?

# ── [5/6] Playwright — Features 7+8 UI tests ─────────────────────────────────
echo
echo "[5/6] Playwright — Feature 7 (mark done) + Feature 8 (dismiss)"
export PLAYWRIGHT_ORG_ID="$ORG1_ID"
export PLAYWRIGHT_ITEM_DONE_ID="$ITEM1_ID"
export PLAYWRIGHT_ITEM_DISMISS_ID="$ITEM2_ID"

npx playwright test \
  tests/e2e/frontend/sprint6/05-mark-done-dismiss.spec.ts \
  --config tests/e2e/frontend/sprint6/playwright.config.ts \
  --reporter=list \
  || TEST_EXIT=$?

echo
echo "[6/6] Result"
if [[ $TEST_EXIT -eq 0 ]]; then pass "Features 7+8 PASSED"
else fail "Features 7+8 FAILED — see output above"; fi
echo; exit $TEST_EXIT
