#!/usr/bin/env bash
# =============================================================================
# unix/s6-f11-filters.sh
# Feature 11 — Filters: Brand, Dimension, Confidence (DC5 fix — URL searchParams)
#
# What is tested
#   • ?brandId=X    → only that brand's items; other brands absent
#   • ?dimension=X  → only that dimension's section; others absent
#   • ?confidence=X → only that confidence label's items; others absent
#   • Combined ?brandId=X&dimension=accuracy → single brand + single dimension
#   • Filter URL params survive page reload — bookmarkable (DC5)
#   • UI filter controls push to URL (?brandId / ?dimension / ?confidence)
#   • Browser back preserves URL filter params; breadcrumb drops them (correct)
#
# Test data seeded
#   org1 (starter) + 2 brands + 2 audits + 3 items:
#     brand_alpha / frequency / confirmed  (wikipedia-article)
#     brand_alpha / accuracy  / confirmed  (stale-content)
#     brand_beta  / context   / likely     (faq-content)
#   Chosen so each filter assertion has a clean expected count
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$ROOT"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
pass() { echo -e "  ${GREEN}PASS${NC}  $1"; }
fail() { echo -e "  ${RED}FAIL${NC}  $1"; TEST_EXIT=1; }
info() { echo -e "  ${YELLOW}....${NC}  $1"; }

echo "════════════════════════════════════════"
echo " Sprint 6 · Feature 11 — Filters"
echo "════════════════════════════════════════"
echo

[[ -f .env.test.local ]] || { echo "ERROR: .env.test.local missing"; exit 1; }
set -a; source .env.test.local; set +a

TEST_EXIT=0
ORG1_ID=""

cleanup() {
  echo; echo "── cleanup ──────────────────────────────"
  [[ -n "$ORG1_ID" ]] && {
    info "Deleting org $ORG1_ID…"
    npx tsx shared/seed.ts delete-org "$ORG1_ID" >/dev/null 2>&1 && pass "org deleted" || info "skipped"
  }
}
trap cleanup EXIT

echo "[1/5] Prerequisites"
curl -sf "${E2E_APP_URL}/api/health" >/dev/null 2>&1 \
  && pass "App running" || { fail "App not running"; exit 1; }

echo
echo "[2/5] Seed — 2 brands, 3 items with distinct brand/dim/confidence"
ORG1_ID=$(npx tsx shared/seed.ts seed-org \
    "${E2E_TEST_ORG_1_CLERK_ID}" "[S6-QA F11] Filter Org" "starter" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
npx tsx shared/seed.ts seed-user "$ORG1_ID" \
    "${E2E_TEST_USER_1_CLERK_ID}" "${E2E_TEST_USER_1_EMAIL}" >/dev/null

# brand Alpha — 2 items
BRAND_A_ID=$(npx tsx shared/seed.ts seed-brand "$ORG1_ID" "Alpha Brand" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
AUDIT_A_ID=$(npx tsx shared/seed.ts seed-audit "$ORG1_ID" "$BRAND_A_ID" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
npx tsx shared/seed.ts seed-item "$ORG1_ID" "$BRAND_A_ID" "$AUDIT_A_ID" \
  "wikipedia-article" "frequency" "confirmed" "high" >/dev/null
npx tsx shared/seed.ts seed-item "$ORG1_ID" "$BRAND_A_ID" "$AUDIT_A_ID" \
  "stale-content" "accuracy" "confirmed" "high" >/dev/null

# brand Beta — 1 item
BRAND_B_ID=$(npx tsx shared/seed.ts seed-brand "$ORG1_ID" "Beta Brand" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
AUDIT_B_ID=$(npx tsx shared/seed.ts seed-audit "$ORG1_ID" "$BRAND_B_ID" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
npx tsx shared/seed.ts seed-item "$ORG1_ID" "$BRAND_B_ID" "$AUDIT_B_ID" \
  "faq-content" "context" "likely" "medium" >/dev/null

pass "Alpha=$BRAND_A_ID (2 items: frequency+accuracy, both confirmed)"
pass "Beta=$BRAND_B_ID  (1 item: context, likely)"
pass "Total 3 items across 2 brands"

# ── [3/5] API filter assertions ────────────────────────────────────────────────
echo
echo "[3/5] API filter assertions"

api_count() {
  local params="$1"
  local SID="${E2E_TEST_USER_1_SESSION_ID}"
  curl -sf "${E2E_APP_URL}/api/action-items?limit=200${params:+&}${params}" \
    -H "Cookie: sid=${SID}" 2>/dev/null \
    | python3 -c "import sys,json; print(len(json.load(sys.stdin).get('items',[])))" 2>/dev/null \
    || echo "-1"
}

# Total (no filter)
TOTAL=$(api_count ""); info "Total items (no filter): $TOTAL"
[[ "$TOTAL" -eq 3 ]] && pass "Total = 3 ✓" || fail "Expected 3 total, got $TOTAL"

# Brand filter
ALPHA=$(api_count "brandId=${BRAND_A_ID}")
[[ "$ALPHA" -eq 2 ]] && pass "?brandId=Alpha → 2 items ✓" || fail "Expected 2, got $ALPHA"
BETA=$(api_count "brandId=${BRAND_B_ID}")
[[ "$BETA" -eq 1 ]]  && pass "?brandId=Beta  → 1 item  ✓" || fail "Expected 1, got $BETA"

# Dimension filter
FREQ=$(api_count "dimension=frequency")
[[ "$FREQ" -ge 1 ]]  && pass "?dimension=frequency → ${FREQ} item(s) ✓" || fail "Expected ≥1, got $FREQ"
CTX=$(api_count "dimension=context")
[[ "$CTX" -eq 1 ]]   && pass "?dimension=context → 1 item ✓"            || fail "Expected 1, got $CTX"

# Confidence filter
CONF=$(api_count "confidence=confirmed")
[[ "$CONF" -eq 2 ]] && pass "?confidence=confirmed → 2 items ✓" || fail "Expected 2, got $CONF"
LIKE=$(api_count "confidence=likely")
[[ "$LIKE" -eq 1 ]] && pass "?confidence=likely → 1 item ✓"    || fail "Expected 1, got $LIKE"

# Combined
COMBO=$(api_count "brandId=${BRAND_A_ID}&dimension=accuracy")
[[ "$COMBO" -eq 1 ]] && pass "?brandId=Alpha&dimension=accuracy → 1 item ✓" || fail "Expected 1, got $COMBO"

# ── [4/5] Playwright — filter UI tests ───────────────────────────────────────
echo
echo "[4/5] Playwright — filter controls + URL update + reload persistence"
export PLAYWRIGHT_ORG_ID="$ORG1_ID"
export PLAYWRIGHT_BRAND_A_ID="$BRAND_A_ID"
export PLAYWRIGHT_BRAND_B_ID="$BRAND_B_ID"

npx playwright test \
  tests/e2e/frontend/sprint6/06-filters.spec.ts \
  --config tests/e2e/frontend/sprint6/playwright.config.ts \
  --reporter=list \
  || TEST_EXIT=$?

echo
echo "[5/5] Result"
if [[ $TEST_EXIT -eq 0 ]]; then pass "Feature 11 PASSED"
else fail "Feature 11 FAILED — see output above"; fi
echo; exit $TEST_EXIT
