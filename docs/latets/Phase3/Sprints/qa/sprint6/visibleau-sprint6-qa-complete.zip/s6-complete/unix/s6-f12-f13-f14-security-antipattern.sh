#!/usr/bin/env bash
# =============================================================================
# unix/s6-f12-f13-f14-security-antipattern.sh
# Feature 12 — Cross-org isolation (RLS → 404 on every route)
# Feature 13 — Unauthenticated access → redirect to /sign-in
# Feature 14 — Anti-pattern filter (12 blocked keys, content regex)
#
# Feature 12 checks (DM5, DH3 — RLS + setRlsContext on PATCH)
#   • GET /api/action-items/{org1-item-id} with org2 session → 404
#   • PATCH /api/action-items/{org1-item-id}/status with org2 session → 404
#   • GET /api/action-items?limit=200 with org2 session → org1 items absent
#   • /action-center/{org1-item-id} in browser as User2 → 404 page
#
# Feature 13 checks
#   • No session: GET /action-center → redirect to /sign-in (Clerk middleware)
#   • No session: GET /action-center/{uuid} → redirect to /sign-in
#
# Feature 14 checks (DB2)
#   • None of 12 BLOCKED_KEYS appear in action_items table
#   • applyAntiPatternFilter unit test: 12 key tests + 1 regex test + 1 passthrough
#   • BLOCKED_PATTERNS regex blocks content-match variants
#
# Test data seeded
#   org1 (starter) + brand + audit + 1 item — the cross-org target
#   org2 (starter) + brand + audit + 1 item — the attacker
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$ROOT"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
pass() { echo -e "  ${GREEN}PASS${NC}  $1"; }
fail() { echo -e "  ${RED}FAIL${NC}  $1"; TEST_EXIT=1; }
info() { echo -e "  ${YELLOW}....${NC}  $1"; }

echo "════════════════════════════════════════"
echo " Sprint 6 · Features 12+13+14 — Security & Anti-pattern"
echo "════════════════════════════════════════"
echo

[[ -f .env.test.local ]] || { echo "ERROR: .env.test.local missing"; exit 1; }
set -a; source .env.test.local; set +a

TEST_EXIT=0
ORG1_ID=""
ORG2_ID=""

cleanup() {
  echo; echo "── cleanup ──────────────────────────────"
  for ID in "$ORG1_ID" "$ORG2_ID"; do
    [[ -n "$ID" ]] && {
      info "Deleting org $ID…"
      npx tsx shared/seed.ts delete-org "$ID" >/dev/null 2>&1 && pass "deleted $ID" || info "skipped"
    }
  done
}
trap cleanup EXIT

echo "[1/7] Prerequisites"
curl -sf "${E2E_APP_URL}/api/health" >/dev/null 2>&1 \
  && pass "App running" || { fail "App not running"; exit 1; }

echo
echo "[2/7] Seed — org1 (target) + org2 (attacker)"
ORG1_ID=$(npx tsx shared/seed.ts seed-org \
    "${E2E_TEST_ORG_1_CLERK_ID}" "[S6-QA F12] CrossOrg Target" "starter" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
npx tsx shared/seed.ts seed-user "$ORG1_ID" \
    "${E2E_TEST_USER_1_CLERK_ID}" "${E2E_TEST_USER_1_EMAIL}" >/dev/null
B1=$(npx tsx shared/seed.ts seed-brand "$ORG1_ID" "Target Brand" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
A1=$(npx tsx shared/seed.ts seed-audit "$ORG1_ID" "$B1" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
TARGET_ITEM=$(npx tsx shared/seed.ts seed-item \
    "$ORG1_ID" "$B1" "$A1" "wikipedia-article" "frequency" "confirmed" "high" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")

ORG2_ID=$(npx tsx shared/seed.ts seed-org \
    "${E2E_TEST_ORG_2_CLERK_ID}" "[S6-QA F12] CrossOrg Attacker" "starter" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
npx tsx shared/seed.ts seed-user "$ORG2_ID" \
    "${E2E_TEST_USER_2_CLERK_ID}" "${E2E_TEST_USER_2_EMAIL}" >/dev/null
B2=$(npx tsx shared/seed.ts seed-brand "$ORG2_ID" "Attacker Brand" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
A2=$(npx tsx shared/seed.ts seed-audit "$ORG2_ID" "$B2" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['id'])")
npx tsx shared/seed.ts seed-item \
    "$ORG2_ID" "$B2" "$A2" "faq-content" "context" "likely" "medium" >/dev/null

pass "org1 (target) = $ORG1_ID, item = $TARGET_ITEM"
pass "org2 (attacker) = $ORG2_ID"

# ── [3/7] Feature 12: Cross-org API isolation ─────────────────────────────────
echo
echo "[3/7] Feature 12 — Cross-org isolation via API"

SID2="${E2E_TEST_USER_2_SESSION_ID}"

# Org2 tries GET org1's item → 404
STATUS=$(curl -s -o /dev/null -w "%{http_code}" \
  "${E2E_APP_URL}/api/action-items/${TARGET_ITEM}" \
  -H "Cookie: sid=${SID2}")
[[ "$STATUS" == "404" ]] \
  && pass "GET cross-org item → 404 ✓" \
  || fail "GET cross-org item → $STATUS (expected 404 — RLS breach!)"

# Org2 tries PATCH org1's item → 404
STATUS=$(curl -s -o /dev/null -w "%{http_code}" -X PATCH \
  "${E2E_APP_URL}/api/action-items/${TARGET_ITEM}/status" \
  -H "Content-Type: application/json" \
  -H "Cookie: sid=${SID2}" \
  -d '{"status":"done"}')
[[ "$STATUS" == "404" ]] \
  && pass "PATCH cross-org item → 404 ✓" \
  || fail "PATCH cross-org item → $STATUS (expected 404 — RLS breach!)"

# Org2 list must not contain org1's item
LIST=$(curl -sf "${E2E_APP_URL}/api/action-items?limit=200" \
  -H "Cookie: sid=${SID2}" 2>/dev/null || echo '{"items":[]}')
if echo "$LIST" | grep -q "$TARGET_ITEM"; then
  fail "Org2 list contains org1's item (RLS data leak!)"
else
  pass "Org2 list does NOT contain org1's item ✓"
fi

# ── [4/7] Playwright — cross-org UI + unauthenticated tests ──────────────────
echo
echo "[4/7] Playwright — Feature 12 (cross-org UI) + Feature 13 (unauthenticated)"
export PLAYWRIGHT_TARGET_ITEM="$TARGET_ITEM"
export PLAYWRIGHT_ORG1_ID="$ORG1_ID"
export PLAYWRIGHT_ORG2_ID="$ORG2_ID"

npx playwright test \
  tests/e2e/frontend/sprint6/08-cross-org-isolation.spec.ts \
  tests/e2e/frontend/sprint6/09-unauthenticated.spec.ts \
  --config tests/e2e/frontend/sprint6/playwright.config.ts \
  --reporter=list \
  || TEST_EXIT=$?

# ── [5/7] Feature 14: Anti-pattern unit tests ─────────────────────────────────
echo
echo "[5/7] Feature 14 — Anti-pattern filter unit tests"
npx vitest run \
  tests/unit/recommendations/anti-patterns.test.ts \
  --reporter=verbose \
  || TEST_EXIT=$?

# ── [6/7] Feature 14: DB check — no blocked keys in action_items ─────────────
echo
echo "[6/7] Feature 14 — DB: verify 12 blocked keys absent from action_items"
node -e "
require('dotenv').config({ path: '.env.test.local' });
const { drizzle } = require('drizzle-orm/postgres-js');
const postgres = require('postgres');
const s = require('./db/schema');
const { inArray } = require('drizzle-orm');
const pg = postgres(process.env.DIRECT_URL ?? process.env.DATABASE_URL, { max:1 });
const db = drizzle(pg, { schema: s });
const BLOCKED = ['add-more-keywords','pay-for-ai-ads','submit-to-ai-engines',
  'get-more-backlinks','use-ai-to-write-content','update-meta-tags-for-ai',
  'improve-seo-generic','buy-reviews','create-ai-generated-reviews',
  'add-schema-without-entity','target-competitor-terms','run-more-audits'];
db.select({ k: s.actionItems.recommendationKey })
  .from(s.actionItems)
  .where(inArray(s.actionItems.recommendationKey, BLOCKED))
  .then(rows => {
    if (rows.length > 0) {
      console.log('  FAIL  blocked keys found in DB:', rows.map(r => r.k).join(', '));
      process.exit(1);
    } else {
      console.log('  PASS  0 blocked anti-pattern keys in action_items ✓');
    }
    pg.end();
  }).catch(e => { console.error('  FAIL', e.message); process.exit(1); });
" || TEST_EXIT=$?

echo
echo "[7/7] Result"
if [[ $TEST_EXIT -eq 0 ]]; then pass "Features 12+13+14 PASSED"
else fail "Features 12+13+14 FAILED — see output above"; fi
echo; exit $TEST_EXIT
