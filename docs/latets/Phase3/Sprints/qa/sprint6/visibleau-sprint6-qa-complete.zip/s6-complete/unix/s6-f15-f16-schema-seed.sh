#!/usr/bin/env bash
# =============================================================================
# unix/s6-f15-f16-schema-seed.sh
# Feature 15 — recommendation_research seed completeness (DN5, DE5 fixes)
# Feature 16 — action_items schema + RLS (DH3, DC3, DA2, DM4 fixes)
#
# Feature 15 checks
#   • All 11 universal recommendation keys have ≥1 row in recommendation_research
#   • Keys: au-local-citations, cited-statistics, comparison-article, expert-quotes,
#     faq-content, linkedin-presence, medium-presence, press-mentions,
#     reddit-absence, stale-content, wikipedia-article
#   • Each row has non-null source, non-empty summary, real URL (not "#")
#   • confidence_level column present (display-only metadata — DL4)
#   • recommendation_research_key_idx index exists (DE4)
#   • UI: expanding EvidenceLink on a wikipedia card shows ≥1 real citation
#
# Feature 16 checks
#   • All 17 action_items columns present with correct physical snake_case names
#   • action_items_audit_rec_idx unique index on (audit_id, recommendation_key)
#   • action_items  RLS: rowsecurity = true  (org_isolation policy)
#   • recommendation_research  RLS: rowsecurity = false (global operator data)
#   • PATCH /api/action-items/{id}/status sets updatedAt (DA2 fix: was missing)
#   • expectedImpactScore is NOT NULL (DM4 fix)
#
# Test data seeded
#   None — reads existing seed and schema directly.
#   Runs backend Vitest schema constraint + research seed tests.
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
cd "$ROOT"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
pass() { echo -e "  ${GREEN}PASS${NC}  $1"; }
fail() { echo -e "  ${RED}FAIL${NC}  $1"; TEST_EXIT=1; }
info() { echo -e "  ${YELLOW}....${NC}  $1"; }

echo "════════════════════════════════════════"
echo " Sprint 6 · Features 15+16 — Schema & Seed"
echo "════════════════════════════════════════"
echo

[[ -f .env.test.local ]] || { echo "ERROR: .env.test.local missing"; exit 1; }
set -a; source .env.test.local; set +a

TEST_EXIT=0

echo "[1/5] Prerequisites"
curl -sf "${E2E_APP_URL}/api/health" >/dev/null 2>&1 \
  && pass "App running" || { fail "App not running"; exit 1; }

# ── [2/5] Feature 15: Research seed coverage ──────────────────────────────────
echo
echo "[2/5] Feature 15 — recommendation_research seed coverage"
node -e "
require('dotenv').config({ path: '.env.test.local' });
const { drizzle } = require('drizzle-orm/postgres-js');
const postgres = require('postgres');
const s = require('./db/schema');
const { sql } = require('drizzle-orm');
const pg = postgres(process.env.DIRECT_URL ?? process.env.DATABASE_URL, { max:1 });
const db = drizzle(pg, { schema: s });

const EXPECTED = [
  'au-local-citations','cited-statistics','comparison-article','expert-quotes',
  'faq-content','linkedin-presence','medium-presence','press-mentions',
  'reddit-absence','stale-content','wikipedia-article',
];

async function run() {
  const rows = await db.execute(sql\`
    SELECT recommendation_key, COUNT(*) as n, MIN(url) as sample_url
    FROM recommendation_research
    GROUP BY recommendation_key ORDER BY recommendation_key
  \`);
  const map = {};
  for (const r of rows.rows) map[r.recommendation_key] = { n: parseInt(r.n), url: r.sample_url };

  let allPass = true;
  for (const key of EXPECTED) {
    const entry = map[key];
    if (!entry || entry.n < 1) {
      console.log('  FAIL  ' + key + ': 0 rows — run pnpm seed');
      allPass = false;
    } else if (!entry.url || entry.url === '#' || entry.url.includes('example.com')) {
      console.log('  FAIL  ' + key + ': placeholder URL (' + entry.url + ')');
      allPass = false;
    } else {
      console.log('  PASS  ' + key + ': ' + entry.n + ' row(s), URL: ' + entry.url.substring(0,40) + '…');
    }
  }
  await pg.end();
  process.exit(allPass ? 0 : 1);
}
run().catch(e => { console.error('FAIL', e.message); process.exit(1); });
" || TEST_EXIT=$?

# ── [3/5] Feature 16: Schema columns, index, RLS ─────────────────────────────
echo
echo "[3/5] Feature 16 — action_items schema, unique index, RLS"
node -e "
require('dotenv').config({ path: '.env.test.local' });
const { drizzle } = require('drizzle-orm/postgres-js');
const postgres = require('postgres');
const s = require('./db/schema');
const { sql } = require('drizzle-orm');
const pg = postgres(process.env.DIRECT_URL ?? process.env.DATABASE_URL, { max:1 });
const db = drizzle(pg, { schema: s });

const COLS = ['id','organization_id','brand_id','audit_id','recommendation_key',
  'dimension','title','action','confidence_label','expected_impact_score',
  'evidence_refs','status','dismissed_reason','done_at','dismissed_at',
  'created_at','updated_at'];

async function run() {
  let allPass = true;

  // Columns
  const colRows = await db.execute(sql\`
    SELECT column_name, is_nullable
    FROM information_schema.columns
    WHERE table_schema='public' AND table_name='action_items'
    ORDER BY ordinal_position
  \`);
  const found = colRows.rows.map(r => r.column_name);
  for (const c of COLS) {
    const ok = found.includes(c);
    console.log('  ' + (ok ? 'PASS' : 'FAIL') + '  column: ' + c);
    if (!ok) allPass = false;
  }

  // Unique index
  const idxRows = await db.execute(sql\`
    SELECT indexname FROM pg_indexes
    WHERE tablename='action_items' AND indexname='action_items_audit_rec_idx'
  \`);
  const hasIdx = idxRows.rows.length > 0;
  console.log('  ' + (hasIdx ? 'PASS' : 'FAIL') + '  unique index action_items_audit_rec_idx');
  if (!hasIdx) allPass = false;

  // RLS
  const rlsRows = await db.execute(sql\`
    SELECT tablename, rowsecurity FROM pg_tables
    WHERE tablename IN ('action_items','recommendation_research') ORDER BY tablename
  \`);
  for (const r of rlsRows.rows) {
    const expected = r.tablename === 'action_items';
    const ok = r.rowsecurity === expected;
    console.log('  ' + (ok ? 'PASS' : 'FAIL') + '  ' + r.tablename + ' RLS=' + r.rowsecurity + ' (expected ' + expected + ')');
    if (!ok) allPass = false;
  }

  // recommendation_research_key_idx (DE4 fix)
  const rIdx = await db.execute(sql\`
    SELECT indexname FROM pg_indexes WHERE tablename='recommendation_research'
    AND indexname='recommendation_research_key_idx'
  \`);
  const hasRIdx = rIdx.rows.length > 0;
  console.log('  ' + (hasRIdx ? 'PASS' : 'FAIL') + '  index recommendation_research_key_idx');
  if (!hasRIdx) allPass = false;

  await pg.end();
  process.exit(allPass ? 0 : 1);
}
run().catch(e => { console.error('FAIL', e.message); process.exit(1); });
" || TEST_EXIT=$?

# ── [4/5] Backend Vitest: schema constraints + research seed tests ────────────
echo
echo "[4/5] Backend Vitest — schema constraints + research seed"
npx vitest run \
  tests/e2e/backend/sprint6/01-schema-constraints.test.ts \
  tests/e2e/backend/sprint6/02-recommendation-research-seed.test.ts \
  --config tests/e2e/backend/sprint6/vitest.config.e2e.ts \
  --reporter=verbose \
  || TEST_EXIT=$?

echo
echo "[5/5] Result"
if [[ $TEST_EXIT -eq 0 ]]; then pass "Features 15+16 PASSED"
else fail "Features 15+16 FAILED — see output above"; fi
echo; exit $TEST_EXIT
