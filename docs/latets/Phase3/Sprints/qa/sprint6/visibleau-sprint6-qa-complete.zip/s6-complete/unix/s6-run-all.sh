#!/usr/bin/env bash
# =============================================================================
# unix/s6-run-all.sh
# Run all Sprint 6 feature scripts in sequence.
# Each script seeds its own test data and deletes it on EXIT.
# F02 (Inngest) skipped by default — needs 35s wait + Inngest server.
# Pass --include-f02 to include it.
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

INCLUDE_F02=false
for arg in "$@"; do [[ "$arg" == "--include-f02" ]] && INCLUDE_F02=true; done

echo "════════════════════════════════════════════════"
echo " VisibleAU Sprint 6 — Full E2E Suite"
echo " $(date)"
echo "════════════════════════════════════════════════"
echo

declare -a PASS_LIST
declare -a FAIL_LIST

run() {
  local script="$1" label="$2"
  echo "────────────────────────────────────────────────"
  echo " Running: $label"
  echo "────────────────────────────────────────────────"
  if bash "$SCRIPT_DIR/$script"; then
    PASS_LIST+=("$label")
  else
    FAIL_LIST+=("$label")
    echo "  ⚠  FAILED — continuing with next feature"
  fi
  echo
}

run "s6-f01-sidebar.sh"                       "F01 — Sidebar navigation"
[[ "$INCLUDE_F02" == "true" ]] && \
  run "s6-f02-inngest-generation.sh"          "F02 — Inngest generation (35s)"
run "s6-f03-f04-action-center-cards.sh"       "F03+F04 — List page & cards"
run "s6-f05-f06-evidence-detail.sh"           "F05+F06 — Evidence & detail page"
run "s6-f07-f08-mark-done-dismiss.sh"         "F07+F08 — Mark done & dismiss"
run "s6-f09-f10-tier-gate.sh"                 "F09+F10 — Tier gate"
run "s6-f11-filters.sh"                       "F11     — Filters"
run "s6-f12-f13-f14-security-antipattern.sh"  "F12+F13+F14 — Security & anti-pattern"
run "s6-f15-f16-schema-seed.sh"               "F15+F16 — Schema & seed"

echo "════════════════════════════════════════════════"
echo " RESULTS"
echo "════════════════════════════════════════════════"
echo
echo "PASSED (${#PASS_LIST[@]}):"
for f in "${PASS_LIST[@]}"; do echo "  ✅  $f"; done

if [[ ${#FAIL_LIST[@]} -gt 0 ]]; then
  echo
  echo "FAILED (${#FAIL_LIST[@]}):"
  for f in "${FAIL_LIST[@]}"; do echo "  ❌  $f"; done
  echo
  [[ "$INCLUDE_F02" == "false" ]] && echo "  ℹ   F02 (Inngest) excluded — run with --include-f02 to include"
  echo
  echo "OVERALL: ❌ FAIL"
  exit 1
else
  echo
  [[ "$INCLUDE_F02" == "false" ]] && echo "  ℹ   F02 (Inngest) excluded — run with --include-f02 to include"
  echo
  echo "OVERALL: ✅ ALL PASS"
  exit 0
fi
