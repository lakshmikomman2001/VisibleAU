@echo off
:: =============================================================================
:: windows\S6-F01-SIDEBAR.bat
:: Feature 1 — Sidebar: Action Center entry activates (DI2+DI5 fix)
:: Seeds : org1 (starter) + user1
:: Cleans: org1 hard-deleted after test
:: =============================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0\.."

echo ════════════════════════════════════════
echo  Sprint 6 ^· Feature 1 — Sidebar Navigation
echo ════════════════════════════════════════
echo.

:: load env
if not exist .env.test.local ( echo ERROR: .env.test.local missing & exit /b 1 )
for /f "usebackq tokens=1,* delims==" %%A in (".env.test.local") do (
  set "line=%%A"
  if not "!line:~0,1!"=="#" if not "!line!"=="" set "%%A=%%B"
)

set TEST_EXIT=0
set ORG1_ID=

:: [1/4] Prerequisites
echo [1/4] Prerequisites
curl -sf "%E2E_APP_URL%/api/health" >nul 2>&1
if errorlevel 1 (
  echo   FAIL  App NOT running - start: set LLM_MODE=mock ^&^& pnpm dev
  exit /b 1
)
echo   PASS  App running at %E2E_APP_URL%
echo.

:: [2/4] Seed
echo [2/4] Seed test data
for /f "delims=" %%i in ('npx tsx shared/seed.ts seed-org "%E2E_TEST_ORG_1_CLERK_ID%" "[S6-QA F01] Sidebar Org" starter 2^>nul') do set "SEED_OUT=%%i"
for /f %%i in ('powershell -nop -c "('%SEED_OUT%'|ConvertFrom-Json).id"') do set ORG1_ID=%%i
if "!ORG1_ID!"=="" ( echo   FAIL  Seed org failed & set TEST_EXIT=1 & goto :cleanup )
npx tsx shared/seed.ts seed-user "!ORG1_ID!" "%E2E_TEST_USER_1_CLERK_ID%" "%E2E_TEST_USER_1_EMAIL%" >nul 2>&1
echo   PASS  org=!ORG1_ID! + user seeded
echo.

:: [3/4] Playwright
echo [3/4] Playwright — sidebar tests
set PLAYWRIGHT_ORG_ID=!ORG1_ID!
npx playwright test tests/e2e/frontend/sprint6/07-sidebar-navigation.spec.ts ^
  --config tests/e2e/frontend/sprint6/playwright.config.ts ^
  --reporter=list
if errorlevel 1 set TEST_EXIT=1

:cleanup
echo.
echo [4/4] Cleanup
if not "!ORG1_ID!"=="" (
  npx tsx shared/seed.ts delete-org "!ORG1_ID!" >nul 2>&1
  echo   ....  org !ORG1_ID! deleted
)
echo.
echo [4/4] Result
if !TEST_EXIT! EQU 0 ( echo   PASS  Feature 1 PASSED ) else ( echo   FAIL  Feature 1 FAILED )
echo.
exit /b !TEST_EXIT!
