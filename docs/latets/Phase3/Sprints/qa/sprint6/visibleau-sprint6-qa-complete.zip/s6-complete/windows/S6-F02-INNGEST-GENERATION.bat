@echo off
:: =============================================================================
:: windows\S6-F02-INNGEST-GENERATION.bat
:: Feature 2 — Recommendation generation via Inngest
:: Requires: app running (LLM_MODE=mock) AND Inngest dev server (:8288)
:: Seeds : org + brand + completed audit; fires audit/complete event
:: Cleans: org hard-deleted after test
:: NOTE : Waits 35 seconds for Inngest function to complete.
:: =============================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0\.."

echo ════════════════════════════════════════
echo  Sprint 6 ^· Feature 2 — Inngest Generation
echo ════════════════════════════════════════
echo.

if not exist .env.test.local ( echo ERROR: .env.test.local missing & exit /b 1 )
for /f "usebackq tokens=1,* delims==" %%A in (".env.test.local") do (
  set "line=%%A"
  if not "!line:~0,1!"=="#" if not "!line!"=="" set "%%A=%%B"
)

set TEST_EXIT=0
set ORG1_ID=

:: [1/6] Prerequisites
echo [1/6] Prerequisites
curl -sf "%E2E_APP_URL%/api/health" >nul 2>&1
if errorlevel 1 ( echo   FAIL  App not running & exit /b 1 )
curl -sf "http://localhost:8288" >nul 2>&1
if errorlevel 1 ( echo   FAIL  Inngest not running - start: npx inngest-cli@latest dev & exit /b 1 )
echo   PASS  App + Inngest running
echo.

:: [2/6] Seed
echo [2/6] Seed — org + brand + audit
for /f "delims=" %%i in ('npx tsx shared/seed.ts seed-org "%E2E_TEST_ORG_1_CLERK_ID%" "[S6-QA F02] Inngest Org" starter 2^>nul') do set "R=%%i"
for /f %%i in ('powershell -nop -c "('%R%'|ConvertFrom-Json).id"') do set ORG1_ID=%%i
if "!ORG1_ID!"=="" ( echo   FAIL  Seed failed & set TEST_EXIT=1 & goto :cleanup )
npx tsx shared/seed.ts seed-user "!ORG1_ID!" "%E2E_TEST_USER_1_CLERK_ID%" "%E2E_TEST_USER_1_EMAIL%" >nul 2>&1
for /f "delims=" %%i in ('npx tsx shared/seed.ts seed-brand "!ORG1_ID!" "F02 Inngest Brand" 2^>nul') do set "R=%%i"
for /f %%i in ('powershell -nop -c "('%R%'|ConvertFrom-Json).id"') do set BRAND_ID=%%i
for /f "delims=" %%i in ('npx tsx shared/seed.ts seed-audit "!ORG1_ID!" "!BRAND_ID!" 2^>nul') do set "R=%%i"
for /f %%i in ('powershell -nop -c "('%R%'|ConvertFrom-Json).id"') do set AUDIT_ID=%%i
echo   PASS  org=!ORG1_ID! brand=!BRAND_ID! audit=!AUDIT_ID!
echo.

:: [3/6] Fire event
echo [3/6] Fire audit/complete event to Inngest
curl -sf -X POST "http://localhost:8288/e/test" ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"audit/complete\",\"data\":{\"auditId\":\"!AUDIT_ID!\"}}" >nul 2>&1
if errorlevel 1 ( echo   FAIL  Could not send event to Inngest & set TEST_EXIT=1 & goto :cleanup )
echo   PASS  Event sent
echo   ....  Waiting 35 seconds for generate-recommendations to complete...
timeout /t 35 /nobreak >nul
echo   ....  Wait complete
echo.

:: [4/6] Verify DB
echo [4/6] Verify action_items generated
for /f "delims=" %%i in ('npx tsx shared/seed.ts list-items "!ORG1_ID!" 2^>nul') do set "R=%%i"
for /f %%i in ('powershell -nop -c "('%R%'|ConvertFrom-Json).count"') do set ITEM_COUNT=%%i
if !ITEM_COUNT! LSS 1 (
  echo   FAIL  No action_items generated. Check http://localhost:8288
  set TEST_EXIT=1
  goto :cleanup
)
echo   PASS  !ITEM_COUNT! action_items generated
echo.

:: [5/6] Backend seed tests
echo [5/6] Backend Vitest — research seed coverage
npx vitest run tests/e2e/backend/sprint6/02-recommendation-research-seed.test.ts ^
  --config tests/e2e/backend/sprint6/vitest.config.e2e.ts ^
  --reporter=verbose
if errorlevel 1 set TEST_EXIT=1

:cleanup
echo.
echo Cleanup — deleting org !ORG1_ID!...
if not "!ORG1_ID!"=="" npx tsx shared/seed.ts delete-org "!ORG1_ID!" >nul 2>&1
echo   ....  done
echo.
echo [6/6] Result
if !TEST_EXIT! EQU 0 ( echo   PASS  Feature 2 PASSED ) else ( echo   FAIL  Feature 2 FAILED )
echo.
exit /b !TEST_EXIT!
