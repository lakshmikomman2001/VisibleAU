@echo off
:: =============================================================================
:: windows\S6-F07-F08-MARK-DONE-DISMISS.bat
:: Feature 7 — Mark done (PATCH status=done, doneAt set, excluded from list)
:: Feature 8 — Dismiss with reason (validation, dismissedReason, excluded)
:: Seeds : org1 (starter) + brand + audit + 4 open items
:: Cleans: org1 hard-deleted in :cleanup regardless of pass/fail
:: =============================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0\.."

echo ════════════════════════════════════════
echo  Sprint 6 ^· Features 7+8 — Mark Done and Dismiss
echo ════════════════════════════════════════
echo.

if not exist .env.test.local ( echo ERROR: .env.test.local missing & exit /b 1 )
for /f "usebackq tokens=1,* delims==" %%A in (".env.test.local") do (
  set "line=%%A"
  if not "!line:~0,1!"=="#" if not "!line!"=="" set "%%A=%%B"
)

set TEST_EXIT=0
set ORG1_ID=
set ITEM1_ID=
set ITEM2_ID=
set ITEM3_ID=
set ITEM4_ID=

:: [1/6] Prerequisites
echo [1/6] Prerequisites
curl -sf "%E2E_APP_URL%/api/health" >nul 2>&1
if errorlevel 1 ( echo   FAIL  App not running & exit /b 1 )
echo   PASS  App running
echo.

:: [2/6] Seed org + 4 items
echo [2/6] Seed — org + 4 open items
for /f "delims=" %%i in ('npx tsx shared/seed.ts seed-org "%E2E_TEST_ORG_1_CLERK_ID%" "[S6-QA F07] Status Org" starter 2^>nul') do set "R=%%i"
for /f %%i in ('powershell -nop -c "('%R%'|ConvertFrom-Json).id"') do set ORG1_ID=%%i
if "!ORG1_ID!"=="" ( echo   FAIL  Seed org failed & set TEST_EXIT=1 & goto :cleanup )

npx tsx shared/seed.ts seed-user "!ORG1_ID!" "%E2E_TEST_USER_1_CLERK_ID%" "%E2E_TEST_USER_1_EMAIL%" >nul 2>&1

for /f "delims=" %%i in ('npx tsx shared/seed.ts seed-brand "!ORG1_ID!" "F07 Status Brand" 2^>nul') do set "R=%%i"
for /f %%i in ('powershell -nop -c "('%R%'|ConvertFrom-Json).id"') do set BRAND_ID=%%i

for /f "delims=" %%i in ('npx tsx shared/seed.ts seed-audit "!ORG1_ID!" "!BRAND_ID!" 2^>nul') do set "R=%%i"
for /f %%i in ('powershell -nop -c "('%R%'|ConvertFrom-Json).id"') do set AUDIT_ID=%%i

for /f "delims=" %%i in ('npx tsx shared/seed.ts seed-item "!ORG1_ID!" "!BRAND_ID!" "!AUDIT_ID!" wikipedia-article frequency confirmed high 2^>nul') do set "R=%%i"
for /f %%i in ('powershell -nop -c "('%R%'|ConvertFrom-Json).id"') do set ITEM1_ID=%%i

for /f "delims=" %%i in ('npx tsx shared/seed.ts seed-item "!ORG1_ID!" "!BRAND_ID!" "!AUDIT_ID!" reddit-absence frequency likely medium 2^>nul') do set "R=%%i"
for /f %%i in ('powershell -nop -c "('%R%'|ConvertFrom-Json).id"') do set ITEM2_ID=%%i

for /f "delims=" %%i in ('npx tsx shared/seed.ts seed-item "!ORG1_ID!" "!BRAND_ID!" "!AUDIT_ID!" stale-content accuracy confirmed high 2^>nul') do set "R=%%i"
for /f %%i in ('powershell -nop -c "('%R%'|ConvertFrom-Json).id"') do set ITEM3_ID=%%i

for /f "delims=" %%i in ('npx tsx shared/seed.ts seed-item "!ORG1_ID!" "!BRAND_ID!" "!AUDIT_ID!" faq-content context likely medium 2^>nul') do set "R=%%i"
for /f %%i in ('powershell -nop -c "('%R%'|ConvertFrom-Json).id"') do set ITEM4_ID=%%i

echo   PASS  4 items seeded
echo.

:: [3/6] Backend Vitest API tests
echo [3/6] Backend Vitest — PATCH /api/action-items/[id]/status
set E2E_TEST_ORG_1_ID=!ORG1_ID!
set E2E_ITEM_DONE_ID=!ITEM3_ID!
set E2E_ITEM_DISMISS_ID=!ITEM4_ID!
npx vitest run tests/e2e/backend/sprint6/05-action-items-status.test.ts ^
  --config tests/e2e/backend/sprint6/vitest.config.e2e.ts ^
  --reporter=verbose
if errorlevel 1 set TEST_EXIT=1
echo.

:: [4/6] DB verification — mark-done
echo [4/6] DB verify — item3 after PATCH done
node -e "require('dotenv').config({path:'.env.test.local'});const{drizzle}=require('drizzle-orm/postgres-js');const p=require('postgres');const s=require('./db/schema');const{eq}=require('drizzle-orm');const pg=p(process.env.DIRECT_URL??process.env.DATABASE_URL,{max:1});const db=drizzle(pg,{schema:s});db.select().from(s.actionItems).where(eq(s.actionItems.id,'!ITEM3_ID!')).then(([r])=>{if(!r){console.log('  ....  item3 not found');pg.end();return;}const ok=r.status==='done'&&r.doneAt!==null&&r.dismissedAt===null;console.log('  '+(ok?'PASS':'FAIL')+'  mark-done DB state');pg.end();process.exit(ok?0:1);}).catch(e=>{console.error(e.message);process.exit(1);});" || set TEST_EXIT=1
echo.

:: [5/6] Playwright
echo [5/6] Playwright — Feature 7+8 UI tests
set PLAYWRIGHT_ORG_ID=!ORG1_ID!
set PLAYWRIGHT_ITEM_DONE_ID=!ITEM1_ID!
set PLAYWRIGHT_ITEM_DISMISS_ID=!ITEM2_ID!
npx playwright test tests/e2e/frontend/sprint6/05-mark-done-dismiss.spec.ts ^
  --config tests/e2e/frontend/sprint6/playwright.config.ts ^
  --reporter=list
if errorlevel 1 set TEST_EXIT=1

:cleanup
echo.
echo Cleanup — deleting org !ORG1_ID!...
if not "!ORG1_ID!"=="" npx tsx shared/seed.ts delete-org "!ORG1_ID!" >nul 2>&1
echo   ....  done
echo.
echo [6/6] Result
if !TEST_EXIT! EQU 0 ( echo   PASS  Features 7+8 PASSED ) else ( echo   FAIL  Features 7+8 FAILED )
echo.
exit /b !TEST_EXIT!
