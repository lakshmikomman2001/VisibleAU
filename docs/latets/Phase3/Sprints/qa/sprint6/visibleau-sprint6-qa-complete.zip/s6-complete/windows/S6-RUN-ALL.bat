@echo off
:: =============================================================================
:: windows\S6-RUN-ALL.bat
:: Run all Sprint 6 feature scripts that have .bat implementations.
:: F02 (Inngest) skipped unless you add /include-f02 as argument.
:: =============================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0\.."

set INCLUDE_F02=0
for %%a in (%*) do if /i "%%a"=="/include-f02" set INCLUDE_F02=1

echo ════════════════════════════════════════════════
echo  VisibleAU Sprint 6 — Full E2E Suite (Windows)
echo  %DATE% %TIME%
echo ════════════════════════════════════════════════
echo.

set PASS_COUNT=0
set FAIL_COUNT=0
set FAIL_NAMES=

call :run_feature windows\S6-F01-SIDEBAR.bat "F01 Sidebar"
if %INCLUDE_F02%==1 call :run_feature windows\S6-F02-INNGEST-GENERATION.bat "F02 Inngest"
call :run_feature windows\S6-F07-F08-MARK-DONE-DISMISS.bat "F07+F08 Mark Done and Dismiss"

echo.
echo ════════════════════════════════════════════════
echo  RESULTS
echo ════════════════════════════════════════════════
echo  PASSED: !PASS_COUNT!
echo  FAILED: !FAIL_COUNT!
if not "!FAIL_NAMES!"=="" echo  Failed: !FAIL_NAMES!
echo.
echo  NOTE: For full suite (all features), use WSL or Mac/Linux .sh scripts
if %INCLUDE_F02%==0 echo  NOTE: F02 excluded. Add /include-f02 to include it.
echo.
if !FAIL_COUNT! EQU 0 ( echo  OVERALL: PASS ) else ( echo  OVERALL: FAIL )
echo.
exit /b !FAIL_COUNT!

:run_feature
echo ────────────────────────────────────────────────
echo  Running: %~2
echo ────────────────────────────────────────────────
call %~1
if errorlevel 1 (
  set /a FAIL_COUNT+=1
  set "FAIL_NAMES=!FAIL_NAMES! %~2"
  echo   NOTE: %~2 FAILED — continuing
) else (
  set /a PASS_COUNT+=1
)
echo.
goto :eof
